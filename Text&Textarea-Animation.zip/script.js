// Get the elements
const editBtn = document.getElementById("edit-btn");
const textContent = document.getElementById("text-content");
const textAreaContainer = document.querySelector(".text-area");
const editableText = document.getElementById("editable-text");

// Handle the edit button click
editBtn.addEventListener("click", () => {
  // Move the text content to the textarea
  editableText.value = textContent.textContent;

  // Show the textarea with animation
  textAreaContainer.classList.add("active");
});
