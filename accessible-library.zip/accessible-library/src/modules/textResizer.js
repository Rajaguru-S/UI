export const textResizer = (() => {
  let fontSize = 100;

  const setFontSize = (percentage) => {
    document.documentElement.style.fontSize = `${percentage}%`;
  };

  return {
    increase: () => {
      fontSize = Math.min(fontSize + 10, 200);
      setFontSize(fontSize);
    },
    decrease: () => {
      fontSize = Math.max(fontSize - 10, 50);
      setFontSize(fontSize);
    },
    reset: () => {
      fontSize = 100;
      setFontSize(fontSize);
    },
  };
})();
