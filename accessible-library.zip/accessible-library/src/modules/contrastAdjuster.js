export const contrastAdjuster = (() => {
  const toggleContrast = () => {
    document.body.classList.toggle('high-contrast');
  };

  return {
    toggle: toggleContrast,
  };
})();
