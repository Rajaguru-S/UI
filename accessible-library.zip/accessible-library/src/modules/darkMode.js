export const darkMode = (() => {
  const toggleDarkMode = () => {
    document.body.classList.toggle('dark-mode');
  };

  return { toggle: toggleDarkMode };
})();
