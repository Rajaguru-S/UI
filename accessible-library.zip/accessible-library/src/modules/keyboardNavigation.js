export const keyboardNavigation = (() => {
  const enableFocusOutline = () => {
    document.body.classList.add('keyboard-navigation');
  };

  const disableFocusOutline = () => {
    document.body.classList.remove('keyboard-navigation');
  };

  const trapFocus = (container) => {
    const focusableElements = container.querySelectorAll(
      'a, button, input, textarea, select, [tabindex]:not([tabindex="-1"])'
    );
    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];

    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Tab') return;

      if (e.shiftKey && document.activeElement === firstElement) {
        e.preventDefault();
        lastElement.focus();
      } else if (!e.shiftKey && document.activeElement === lastElement) {
        e.preventDefault();
        firstElement.focus();
      }
    });
  };

  return { enableFocusOutline, disableFocusOutline, trapFocus };
})();
