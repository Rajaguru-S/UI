export const accessibilityWidget = (() => {
  const widget = document.createElement("div");
  widget.id = "accessibility-widget";
  widget.innerHTML = `
    <button id="increase-text">A+</button>
    <button id="decrease-text">A-</button>
    <button id="toggle-contrast">Contrast</button>
    <button id="toggle-dark-mode">Dark Mode</button>
  `;
  document.body.appendChild(widget);

  const setupListeners = () => {
    document
      .querySelector("#increase-text")
      .addEventListener("click", textResizer.increase);
    document
      .querySelector("#decrease-text")
      .addEventListener("click", textResizer.decrease);
    document
      .querySelector("#toggle-contrast")
      .addEventListener("click", contrastAdjuster.toggle);
    document
      .querySelector("#toggle-dark-mode")
      .addEventListener("click", darkMode.toggle);
  };

  return {
    init: () => {
      setupListeners();
    },
  };
})();
