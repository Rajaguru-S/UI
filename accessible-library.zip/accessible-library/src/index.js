// import { textResizer } from "./modules/textResizer";
// import { contrastAdjuster } from "./modules/contrastAdjuster";
// import { keyboardNavigation } from "./modules/keyboardNavigation";
// import { darkMode } from "./modules/darkMode";
// import { accessibilityWidget } from "./widgets/accessibilityWidget";

// export const AccessibleLibrary = {
//   init: () => {
//     textResizer.init();
//     contrastAdjuster.init();
//     darkMode.init();
//     accessibilityWidget.init();
//     keyboardNavigation.enableFocusOutline();
//   },
// };

import { accessibilityWidget } from "./widgets/accessibilityWidget";
import { keyboardNavigation } from "./modules/keyboardNavigation";

export const AccessibleLibrary = {
  init: () => {
    console.log("Initializing Accessible Library...");
    accessibilityWidget.init();
    keyboardNavigation.enableFocusOutline();
  },
};
