import { defineConfig } from "vite";

export default defineConfig({
  build: {
    lib: {
      entry: "src/index.js", // Entry point
      name: "AccessibleLibrary", // Global variable name
      fileName: (format) => `accessible-library.${format}.js`,
    },
  },
});
