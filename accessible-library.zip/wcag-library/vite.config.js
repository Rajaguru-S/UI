import { defineConfig } from "vite";

export default defineConfig({
  build: {
    lib: {
      entry: "src/index.js",
      name: "WCAGLibrary",
      fileName: (format) => `wcag-library.${format}.js`,
    },
    rollupOptions: {
      output: {
        assetFileNames: (assetInfo) =>
          assetInfo.name.endsWith(".css") ? "wcag-library.css" : assetInfo.name,
      },
    },
  },
});
