export function enableHighContrastMode() {
  const toggleButton = document.createElement("button");
  toggleButton.textContent = "Toggle High Contrast";
  toggleButton.id = "contrast-toggle";
  document.body.appendChild(toggleButton);

  toggleButton.addEventListener("click", () => {
    document.body.classList.toggle("high-contrast");
  });
}
