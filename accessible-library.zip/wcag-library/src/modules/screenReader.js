export function announce(message) {
  const liveRegion =
    document.getElementById("aria-live-region") || createLiveRegion();
  liveRegion.textContent = message;
}

function createLiveRegion() {
  const region = document.createElement("div");
  region.id = "aria-live-region";
  region.setAttribute("role", "alert");
  region.setAttribute("aria-live", "assertive");
  region.style.position = "absolute";
  region.style.left = "-9999px";
  document.body.appendChild(region);
  return region;
}
