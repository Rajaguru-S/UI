export function validateForm(formElement) {
  const fields = formElement.querySelectorAll("input, textarea, select");

  fields.forEach((field) => {
    field.addEventListener("invalid", () => {
      field.setAttribute("aria-invalid", "true");
    });

    field.addEventListener("input", () => {
      if (field.checkValidity()) {
        field.setAttribute("aria-invalid", "false");
      }
    });
  });
}
