export function enableFocusManagement() {
  document.addEventListener("keydown", (e) => {
    if (e.key === "Tab") {
      document.body.classList.add("focus-visible");
    }
  });

  document.addEventListener("mousedown", () => {
    document.body.classList.remove("focus-visible");
  });
}
