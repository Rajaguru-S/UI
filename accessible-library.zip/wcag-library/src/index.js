import { enableFocusManagement } from "./modules/keyboardNavigation";
import { enableHighContrastMode } from "./modules/contrastEnhancer";
import { announce } from "./modules/screenReader";
import { validateForm } from "./modules/formValidation";

import "./styles/accessibility.css";

export const WCAGLibrary = {
  init: () => {
    enableFocusManagement();
    enableHighContrastMode();
    console.log("WCAG Library Initialized");
  },
  announce,
  validateForm,
};
