# Custom slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/monarkpatel/pen/BqeYRW](https://codepen.io/monarkpatel/pen/BqeYRW).

Custom jQuery slider with play and pause funcnality.