$(document).ready(function(){
	if($('.sliderOute').length > 0){

		var max = -1;
		$(".slide").each(function() {
		    var h = $(this).height(); 
		    max = h > max ? h : max;
		});
		$('.slide').css("min-height", max);
		if($('.slide.active').length < 1){
			$('.slide:first').addClass('active');
			$('.slide:last').addClass('prev');
		}
		$('.slide.active').next().addClass('next');
		$('.slide.active').prev().addClass('prev');		
		$(document).on("click",".next", function(e){
			e.preventDefault();
			nextSlide();
		});
		$(document).on("click",".prev", function(e){
			e.preventDefault();
			var currentActive = $('.slide.active');
			if($('.slide:first').hasClass("active") || $('.slide:nth-child(2)').hasClass("active")){
				if($('.slide:nth-child(2)').hasClass("active")){
					currentActive.removeClass("active").addClass("next");
					currentActive.siblings().removeClass("next prev");
					currentActive.prev().addClass("active");
					$('.slide:last').addClass("prev");
				}else{
					currentActive.removeClass("active").addClass("next");
					$('.slide:last').removeClass("prev").addClass("active");
					$('.slide:nth-last-child(2)').addClass("prev");
				}
			}else{
				currentActive.removeClass("active").addClass("next");
				currentActive.siblings().removeClass("next prev");
				currentActive.prev().addClass("active").prev().addClass("prev");
			}
		});

		//AUTOPLAY
		var intervalId = false;
		function intervalFunction () {
			nextSlide();
		}
		$(document).on("click",".playBtn", function(e){
			e.preventDefault();
			$(this).toggleClass("play");
		    if ($(this).hasClass("play")) {
		        intervalId = setInterval(intervalFunction, 1000);
		    }else{
		    	clearInterval(intervalId);
		    }
		});
	}

	//NEXT SLIDE FUNCTION
	function nextSlide(){
		var currentActive = $('.slide.active');		
		if($('.slide:last').hasClass("active") || $('.slide:nth-last-child(2)').hasClass("active")){
			if($('.slide:nth-last-child(2)').hasClass("active")){
				currentActive.removeClass("active").addClass("prev");
				currentActive.siblings().removeClass("next prev");
				currentActive.next().addClass("active");
				$('.slide:first').addClass("next");
			}else{
				currentActive.removeClass("active").addClass("prev");
				$('.slide:first').removeClass("next").addClass("active").next().addClass("next");
				$('.slide:nth-last-child(2)').removeClass("prev")
			}
		}else{
			currentActive.removeClass("active").addClass("prev");
			currentActive.siblings().removeClass("next prev");
			currentActive.next().addClass("active").next().addClass("next");
		}
	};
});