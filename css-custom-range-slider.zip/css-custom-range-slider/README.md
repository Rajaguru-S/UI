# CSS Custom Range Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/brandonmcconnell/pen/oJBVQW](https://codepen.io/brandonmcconnell/pen/oJBVQW).

