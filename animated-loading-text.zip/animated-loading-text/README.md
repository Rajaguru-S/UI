# Animated Loading Text

A Pen created on CodePen.io. Original URL: [https://codepen.io/codypearce/pen/LYVoNGy](https://codepen.io/codypearce/pen/LYVoNGy).

Simple example of animating the text "loading" up and down like a wave