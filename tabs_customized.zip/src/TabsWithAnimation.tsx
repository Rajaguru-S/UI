import React, { useState } from 'react';
import { Tab, Tabs, Fade } from 'react-bootstrap';

interface DataItem {
  name: string;
  keywords: string[];
}

const dataResults: DataItem[] = [
  {
    name: 'Title 1',
    keywords: ['Keyword 1', 'Keyword 2', 'Keyword 3']
  },
  {
    name: 'Title 2',
    keywords: ['Keyword 1', 'Keyword 2', 'Keyword 3']
  },
  {
    name: 'Title 3',
    keywords: ['Keyword 1', 'Keyword 2', 'Keyword 3']
  }
];

const TabsWithAnimation: React.FC = () => {
  const [activeKey, setActiveKey] = useState<string>(dataResults[0].name);

  return (
    <Tabs
      id="custom-tabs"
      activeKey={activeKey}
      onSelect={(k) => k && setActiveKey(k)}
      className="mb-3"
      transition={false}
      justify
    >
      {dataResults.map((item) => (
        <Tab
          key={item.name}
          eventKey={item.name}
          title={item.name}
        >
          <Fade in={activeKey === item.name}>
            <div className="p-3">
              <h5>{item.name} Keywords</h5>
              <ul>
                {item.keywords.map((keyword, index) => (
                  <li key={index}>{keyword}</li>
                ))}
              </ul>
            </div>
          </Fade>
        </Tab>
      ))}
    </Tabs>
  );
};

export default TabsWithAnimation;
