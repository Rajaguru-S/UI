import React, { useState, useEffect, useRef } from 'react';
import { Tab, Tabs, Fade, Form } from 'react-bootstrap';

interface DataItem {
  name: string;
  keywords: string[];
}

const dataResults: DataItem[] = [
  {
    name: 'Title 1',
    keywords: ['Keyword 1', 'Keyword 2', 'Keyword 3'],
  },
  {
    name: 'Title 2',
    keywords: ['Keyword 1', 'Keyword 2', 'Keyword 3'],
  },
  {
    name: 'Title 3',
    keywords: ['Keyword 1', 'Keyword 2', 'Keyword 3'],
  },
];

const TabsWithCheckboxes: React.FC = () => {
  const [activeKey, setActiveKey] = useState<string>(dataResults[0].name);

  // Check state: { 'Title 1': { checked: boolean[], allChecked: boolean, indeterminate: boolean } }
  const [checkedState, setCheckedState] = useState<Record<string, boolean[]>>(
    () => {
      const initialState: Record<string, boolean[]> = {};
      dataResults.forEach((item) => {
        initialState[item.name] = Array(item.keywords.length).fill(false);
      });
      return initialState;
    }
  );

  const tabRefs = useRef<Record<string, HTMLInputElement | null>>({});

  useEffect(() => {
    // Update indeterminate state of checkboxes
    dataResults.forEach((item) => {
      const keywordChecks = checkedState[item.name];
      const checkbox = tabRefs.current[item.name];
      if (checkbox) {
        const allChecked = keywordChecks.every(Boolean);
        const someChecked = keywordChecks.some(Boolean);
        checkbox.indeterminate = !allChecked && someChecked;
      }
    });
  }, [checkedState]);

  const handleNameCheck = (name: string, isChecked: boolean) => {
    setCheckedState((prev) => ({
      ...prev,
      [name]: prev[name].map(() => isChecked),
    }));
  };

  const handleKeywordCheck = (
    name: string,
    index: number,
    isChecked: boolean
  ) => {
    setCheckedState((prev) => ({
      ...prev,
      [name]: prev[name].map((val, i) => (i === index ? isChecked : val)),
    }));
  };

  return (
    <Tabs
      id="custom-tabs"
      activeKey={activeKey}
      onSelect={(k) => k && setActiveKey(k)}
      className="mb-3"
      transition={false}
      justify
    >
      {dataResults.map((item) => {
        const allChecked = checkedState[item.name].every(Boolean);

        return (
          <Tab
            key={item.name}
            eventKey={item.name}
            title={
              <div className="d-flex align-items-center">
                <Form.Check
                  className="me-2"
                  checked={allChecked}
                  onChange={(e) => handleNameCheck(item.name, e.target.checked)}
                  ref={(el) => (tabRefs.current[item.name] = el)}
                />
                <span>{item.name}</span>
              </div>
            }
          >
            <Fade in={activeKey === item.name}>
              <div className="p-3">
                <h5>{item.name} Keywords</h5>
                <ul className="list-unstyled">
                  {item.keywords.map((keyword, index) => (
                    <li key={index}>
                      <Form.Check
                        type="checkbox"
                        label={keyword}
                        checked={checkedState[item.name][index]}
                        onChange={(e) =>
                          handleKeywordCheck(item.name, index, e.target.checked)
                        }
                      />
                    </li>
                  ))}
                </ul>
              </div>
            </Fade>
          </Tab>
        );
      })}
    </Tabs>
  );
};

export default TabsWithCheckboxes;
