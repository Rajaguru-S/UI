import { useState } from 'react';
import reactLogo from './assets/react.svg';
import viteLogo from '/vite.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import TabsWithAnimation from './TabsWithAnimation';
import TabsWithCheckboxes from './TabsWithCheckboxes';

const App: React.FC = () => {
  return (
    <div className="container mt-5">
      <h2>Animated Tabs Example</h2>
      <TabsWithAnimation />
      <TabsWithCheckboxes />
    </div>
  );
};

export default App;
