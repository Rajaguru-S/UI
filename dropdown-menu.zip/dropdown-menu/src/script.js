$('.menu').on('click', function () {
  $('.list').toggleClass('hidden');
});