# Card design

A Pen created on CodePen.io. Original URL: [https://codepen.io/abottega/pen/mBpawZ](https://codepen.io/abottega/pen/mBpawZ).

Inspired by:
https://www.invisionapp.com/new-features