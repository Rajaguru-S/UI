let timer;
let countdown = 60; // Set the countdown duration in seconds

function startResendTimer() {
    // Disable the button during the countdown
    document.getElementById('resendBtn').disabled = true;

    // Start the countdown
    timer = setInterval(updateTimer, 1000);
}

function updateTimer() {
    const timerElement = document.getElementById('timer');
    
    if (countdown > 0) {
        timerElement.textContent = `Resend in ${countdown} seconds`;
        countdown--;
    } else {
        // Enable the button when the countdown reaches zero
        document.getElementById('resendBtn').disabled = false;
        timerElement.textContent = '';
        
        // Reset countdown for the next attempt
        countdown = 60;
        
        // Stop the timer
        clearInterval(timer);
    }
}
