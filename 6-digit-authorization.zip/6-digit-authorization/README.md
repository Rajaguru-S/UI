# 6 Digit Authorization

A Pen created on CodePen.io. Original URL: [https://codepen.io/DVELOPR/pen/Npdwmd](https://codepen.io/DVELOPR/pen/Npdwmd).

