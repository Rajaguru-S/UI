import React, { useState, useEffect, useRef } from 'react';

interface ModalProps {
  children: React.ReactNode;
  onClose: () => void;
  title?: string;
  initialWidth?: number;
  initialHeight?: number;
}

interface Position {
  x: number;
  y: number;
}

interface Size {
  width: number;
  height: number;
}

const CustomModal: React.FC<ModalProps> = ({
  children,
  onClose,
  title = 'Modal',
  initialWidth = 400,
  initialHeight = 300,
}) => {
  const [position, setPosition] = useState<Position>({ x: 0, y: 0 });
  const [size, setSize] = useState<Size>({
    width: initialWidth,
    height: initialHeight,
  });
  const [isMaximized, setIsMaximized] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [zIndex, setZIndex] = useState(1000);
  const [preMinimizePosition, setPreMinimizePosition] = useState<Position>({
    x: 0,
    y: 0,
  });
  const [preMinimizeSize, setPreMinimizeSize] = useState<Size>({
    width: initialWidth,
    height: initialHeight,
  });
  const [preMaximizePosition, setPreMaximizePosition] = useState<Position>({
    x: 0,
    y: 0,
  });
  const [preMaximizeSize, setPreMaximizeSize] = useState<Size>({
    width: initialWidth,
    height: initialHeight,
  });

  const modalRef = useRef<HTMLDivElement>(null);
  const dragStartPos = useRef<Position>({ x: 0, y: 0 });
  const resizeStartPos = useRef<Position>({ x: 0, y: 0 });
  const resizeStartSize = useRef<Size>({ width: 0, height: 0 });

  // Prevent body scroll when modal is mounted
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = '';
    };
  }, []);

  // Handle text selection prevention during drag/resize
  useEffect(() => {
    if (isDragging || isResizing) {
      document.body.style.userSelect = 'none';
      document.body.style.webkitUserSelect = 'none';
    } else {
      document.body.style.userSelect = '';
      document.body.style.webkitUserSelect = '';
    }
  }, [isDragging, isResizing]);

  // Window resize handler for minimized modal
  useEffect(() => {
    const handleResize = () => {
      if (isMinimized) {
        const newX = window.innerWidth - 200;
        const newY = window.innerHeight - 40;
        setPosition({ x: newX, y: newY });
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [isMinimized]);

  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging && !isResizing) return;

    // Prevent default to avoid text selection
    e.preventDefault();

    if (isDragging) {
      const newPos = isMinimized
        ? {
            x: e.clientX - dragStartPos.current.x,
            y: window.innerHeight - 40,
          }
        : {
            x: e.clientX - dragStartPos.current.x,
            y: e.clientY - dragStartPos.current.y,
          };

      setPosition(newPos);
    }

    if (isResizing) {
      const newWidth =
        resizeStartSize.current.width + (e.clientX - resizeStartPos.current.x);
      const newHeight =
        resizeStartSize.current.height + (e.clientY - resizeStartPos.current.y);
      setSize({
        width: Math.max(300, newWidth),
        height: Math.max(200, newHeight),
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setIsResizing(false);
  };

  useEffect(() => {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, isResizing]);

  const handleMouseDown = (e: React.MouseEvent) => {
    // Check if the target is the header or a button
    const target = e.target as HTMLElement;
    if (target.tagName === 'BUTTON') return;

    setZIndex(zIndex + 1);
    if (modalRef.current) {
      const rect = modalRef.current.getBoundingClientRect();
      dragStartPos.current = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      };
    }
    setIsDragging(true);
  };

  const handleResizeMouseDown = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault(); // Prevent text selection
    resizeStartPos.current = { x: e.clientX, y: e.clientY };
    resizeStartSize.current = { ...size };
    setIsResizing(true);
  };

  const toggleMaximize = () => {
    if (!isMaximized) {
      setPreMaximizePosition(position);
      setPreMaximizeSize(size);
      setPosition({ x: 0, y: 0 });
      setSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    } else {
      setPosition(preMaximizePosition);
      setSize(preMaximizeSize);
    }
    setIsMaximized(!isMaximized);
  };

  const toggleMinimize = () => {
    if (!isMinimized) {
      setPreMinimizePosition(position);
      setPreMinimizeSize(size);
      setPosition({
        x: window.innerWidth - 200,
        y: window.innerHeight - 40,
      });
      setSize({ width: 200, height: 40 });
    } else {
      setPosition(preMinimizePosition);
      setSize(preMinimizeSize);
    }
    setIsMinimized(!isMinimized);
  };

  const modalStyle: React.CSSProperties = {
    position: 'absolute',
    left: position.x,
    top: position.y,
    width: size.width,
    height: size.height,
    zIndex,
    backgroundColor: 'white',
    border: '1px solid #ccc',
    borderRadius: '4px',
    boxShadow: '0 2px 10px rgba(0,0,0,0.2)',
    overflow: 'hidden',
    transition: isDragging || isResizing ? 'none' : 'all 0.3s ease',
  };

  return (
    <div
      ref={modalRef}
      style={modalStyle}
      onMouseDown={() => setZIndex(zIndex + 1)}
    >
      <div
        style={{
          padding: '8px',
          cursor: 'move',
          backgroundColor: '#f0f0f0',
          borderBottom: '1px solid #ddd',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          height: '40px',
          userSelect: 'none', // Prevent text selection in header
        }}
        onMouseDown={handleMouseDown}
      >
        <div>{title}</div>
        <div
          style={{ display: 'flex', gap: '8px' }}
          onClick={(e) => e.stopPropagation()} // Prevent drag when clicking buttons
        >
          <button onClick={toggleMinimize}>{isMinimized ? '🗖' : '🗕'}</button>
          <button onClick={toggleMaximize}>{isMaximized ? '🗗' : '🗖'}</button>
          <button onClick={onClose}>🗙</button>
        </div>
      </div>

      {!isMinimized && (
        <div
          style={{
            height: 'calc(100% - 40px)',
            padding: '16px',
            overflow: 'auto',
            userSelect: isDragging || isResizing ? 'none' : 'auto', // Only allow selection when not dragging
          }}
        >
          {children}
        </div>
      )}

      {!isMinimized && !isMaximized && (
        <div
          style={{
            position: 'absolute',
            right: 0,
            bottom: 0,
            width: '16px',
            height: '16px',
            cursor: 'se-resize',
            backgroundColor: '#f0f0f0',
            borderTop: '1px solid #ddd',
            borderLeft: '1px solid #ddd',
            userSelect: 'none', // Prevent text selection on resize handle
          }}
          onMouseDown={handleResizeMouseDown}
        />
      )}
    </div>
  );
};

export default CustomModal;
