# Tooltip animation

A Pen created on CodePen.

Original URL: [https://codepen.io/milanraring/pen/JjoamZx](https://codepen.io/milanraring/pen/JjoamZx).

Simple Tooltip animation