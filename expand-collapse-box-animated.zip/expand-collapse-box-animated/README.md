# Expand/Collapse Box Animated

A Pen created on CodePen.io. Original URL: [https://codepen.io/nicolewynn/pen/JaoJVY](https://codepen.io/nicolewynn/pen/JaoJVY).

