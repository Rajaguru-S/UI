$( ".js-expand" ).click(function() {
  $( ".js-expand" ).toggleClass('is-expanded');
  $( ".figcaption" ).toggleClass('is-expanded');
});