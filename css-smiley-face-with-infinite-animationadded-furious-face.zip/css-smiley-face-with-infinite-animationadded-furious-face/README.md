# CSS Smiley Face with Infinite Animation - Added Furious Face

A Pen created on CodePen.io. Original URL: [https://codepen.io/joekuan/pen/jwyzeP](https://codepen.io/joekuan/pen/jwyzeP).

