// src/App.tsx
import React from "react";
import SpellCheckEditor from "./components/SpellCheckEditor";

function App() {
  return (
    <div className="App">
      <h3>Spell Checker</h3>
      <SpellCheckEditor />
    </div>
  );
}

export default App;
