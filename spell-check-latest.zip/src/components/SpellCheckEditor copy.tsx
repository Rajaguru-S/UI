import React, { useEffect, useRef, useState } from "react";
import Typo from "typo-js";
import { loadDictionary } from "../utils/loadTypo";
import "./SpellCheckEditor.css";

const SpellCheckEditor: React.FC = () => {
  const editorRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const contextMenuRef = useRef<HTMLUListElement>(null);

  const [typo, setTypo] = useState<Typo | null>(null);
  const [customWords, setCustomWords] = useState<Set<string>>(new Set());

  const [menuVisible, setMenuVisible] = useState(false);
  const [menuPosition, setMenuPosition] = useState({ x: 0, y: 0 });
  const [menuSuggestions, setMenuSuggestions] = useState<string[]>([]);
  const [selectedWord, setSelectedWord] = useState<string | null>(null);

  useEffect(() => {
    loadDictionary().then(setTypo);
  }, []);

  // Close menu on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const menuEl = contextMenuRef.current;
      const editorEl = editorRef.current;

      if (
        menuEl &&
        !menuEl.contains(event.target as Node) &&
        editorEl &&
        !editorEl.contains(event.target as Node)
      ) {
        setMenuVisible(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const checkSpelling = () => {
    if (!typo || !editorRef.current) return;

    const text = editorRef.current.innerText;
    const words = text.split(/\s+/);

    const newHTML = words
      .map((word) => {
        const clean = word.replace(/[^\w']/g, ""); // Clean punctuation
        if (clean && !typo.check(clean) && !customWords.has(clean)) {
          return `<span class="misspelled">${word}</span>`;
        } else {
          return word; // No misspelling highlight for custom words
        }
      })
      .join(" ");

    editorRef.current.innerHTML = newHTML;
    placeCaretAtEnd(editorRef.current);
  };

  const placeCaretAtEnd = (el: HTMLElement) => {
    const range = document.createRange();
    const sel = window.getSelection();
    range.selectNodeContents(el);
    range.collapse(false);
    sel?.removeAllRanges();
    sel?.addRange(range);
  };

  const handleContextMenu = (e: React.MouseEvent<HTMLDivElement>) => {
    e.preventDefault();
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return;

    const range = selection.getRangeAt(0);
    const node = range.startContainer.parentElement;

    if (node && node.classList.contains("misspelled")) {
      const word = node.textContent || "";
      setSelectedWord(word);

      const suggestions = typo?.suggest(word) || [];

      const containerRect = containerRef.current?.getBoundingClientRect();
      const x = e.clientX - (containerRect?.left || 0);
      const y = e.clientY - (containerRect?.top || 0);

      setMenuSuggestions(suggestions);
      setMenuPosition({ x, y });
      setMenuVisible(true);
    } else {
      setMenuVisible(false);
    }
  };

  const replaceWord = (replacement: string) => {
    if (!editorRef.current || !selectedWord) return;
    const html = editorRef.current.innerHTML;
    const regex = new RegExp(
      `(<span class="misspelled">)${selectedWord}(</span>)`,
      "g"
    );
    const newHTML = html.replace(regex, replacement);
    editorRef.current.innerHTML = newHTML;
    setMenuVisible(false);
    checkSpelling();
  };

  const addToDictionary = () => {
    if (!selectedWord) return;
    setCustomWords(new Set([...customWords, selectedWord]));
    setMenuVisible(false);

    // Update the content and remove the "misspelled" class from added words
    if (editorRef.current) {
      const html = editorRef.current.innerHTML;

      // Use regex to replace the selected word, removing the misspelled class
      const updatedHTML = html.replace(
        new RegExp(
          `(<span class="misspelled">)(${selectedWord})(</span>)`,
          "g"
        ),
        (match, p1, p2, p3) => p2 // Replace with the word itself (without the "misspelled" class)
      );
      editorRef.current.innerHTML = updatedHTML;

      // Recheck spelling right after updating content
      checkSpelling(); // Recheck to ensure the word doesn't show up as misspelled again
    }
  };

  return (
    <div className="editor-wrapper" ref={containerRef}>
      <div
        ref={editorRef}
        contentEditable
        className="editor"
        onInput={checkSpelling}
        onContextMenu={handleContextMenu}
        suppressContentEditableWarning
      ></div>

      {menuVisible && (
        <ul
          ref={contextMenuRef}
          className="context-menu"
          style={{ top: menuPosition.y, left: menuPosition.x }}
        >
          {menuSuggestions.length > 0 ? (
            menuSuggestions.map((s, idx) => (
              <li key={idx} onClick={() => replaceWord(s)}>
                {s}
              </li>
            ))
          ) : (
            <li className="no-suggestions">No suggestions</li>
          )}
          <li onClick={addToDictionary}>Add to dictionary</li>
        </ul>
      )}
    </div>
  );
};

export default SpellCheckEditor;
