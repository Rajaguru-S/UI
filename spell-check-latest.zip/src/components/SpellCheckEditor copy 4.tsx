import React, { useEffect, useRef, useState } from "react";
import Typo from "typo-js";
import { loadDictionary } from "../utils/loadTypo";
import "./SpellCheckEditor.css";

const SpellCheckEditor: React.FC = () => {
  const editorRef = useRef<HTMLTextAreaElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const contextMenuRef = useRef<HTMLUListElement>(null);
  const [typo, setTypo] = useState<Typo | null>(null);
  const [customWords, setCustomWords] = useState<Set<string>>(new Set());
  const [menuVisible, setMenuVisible] = useState(false);
  const [menuPosition, setMenuPosition] = useState({ x: 0, y: 0 });
  const [menuSuggestions, setMenuSuggestions] = useState<string[]>([]);
  const [selectedWord, setSelectedWord] = useState<string | null>(null);
  const [savedText, setSavedText] = useState<string>("");
  const [textValue, setTextValue] = useState<string>("");

  useEffect(() => {
    loadDictionary().then(setTypo);
  }, []);

  // Close menu on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        contextMenuRef.current &&
        !contextMenuRef.current.contains(event.target as Node)
      ) {
        setMenuVisible(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const checkSpellingFromTextarea = (
    e: React.ChangeEvent<HTMLTextAreaElement>
  ) => {
    const newText = e.target.value;
    setTextValue(newText);
  };

  const handleContextMenuFromTextarea = (
    e: React.MouseEvent<HTMLTextAreaElement>
  ) => {
    e.preventDefault();
    const textarea = editorRef.current;
    if (!textarea || !typo) return;

    const cursorIndex = textarea.selectionStart;
    const words = textValue.split(/\s+/);
    let start = 0;
    let wordUnderCursor = "";

    for (let word of words) {
      const end = start + word.length;
      if (cursorIndex >= start && cursorIndex <= end) {
        wordUnderCursor = word;
        break;
      }
      start = end + 1;
    }

    if (
      wordUnderCursor &&
      !typo.check(wordUnderCursor) &&
      !customWords.has(wordUnderCursor)
    ) {
      setSelectedWord(wordUnderCursor);
      setMenuSuggestions(typo.suggest(wordUnderCursor) || []);

      const containerRect = containerRef.current?.getBoundingClientRect();
      const x = e.clientX - (containerRect?.left || 0);
      const y = e.clientY - (containerRect?.top || 0);

      setMenuPosition({ x, y });
      setMenuVisible(true);
    } else {
      setMenuVisible(false);
    }
  };

  const replaceWord = (replacement: string) => {
    if (!selectedWord) return;

    const updatedText = textValue.replace(
      new RegExp(`\\b${selectedWord}\\b`, "g"),
      replacement
    );

    setTextValue(updatedText);
    setMenuVisible(false);
  };

  const addToDictionary = () => {
    if (!selectedWord) return;
    setCustomWords(new Set([...customWords, selectedWord]));
    setMenuVisible(false);
  };

  const handleSave = () => {
    setSavedText(textValue);
  };

  const handleCopy = () => {
    if (savedText) {
      navigator.clipboard.writeText(savedText).then(() => {
        alert("Text copied to clipboard!");
      });
    }
  };

  const handleCopyEditorText = () => {
    navigator.clipboard.writeText(textValue).then(() => {
      alert("Editor text copied to clipboard!");
    });
  };

  const handlePaste = async () => {
    const clipboardText = await navigator.clipboard.readText();
    const updated = textValue + clipboardText;
    setTextValue(updated);
  };

  const handleClear = () => {
    setTextValue("");
    setSavedText("");
    setMenuVisible(false);
  };

  const handleSelectAll = () => {
    editorRef.current?.select();
  };

  return (
    <div className="editor-wrapper" ref={containerRef}>
      <textarea
        ref={editorRef}
        className="editor"
        spellCheck={false}
        value={textValue}
        onChange={checkSpellingFromTextarea}
        onContextMenu={handleContextMenuFromTextarea}
      />

      {menuVisible && (
        <ul
          ref={contextMenuRef}
          className="context-menu"
          style={{ top: menuPosition.y, left: menuPosition.x }}
        >
          {menuSuggestions.length > 0 ? (
            menuSuggestions.map((s, idx) => (
              <li key={idx} onClick={() => replaceWord(s)}>
                {s}
              </li>
            ))
          ) : (
            <li className="no-suggestions">No suggestions</li>
          )}
          <li onClick={addToDictionary}>Add to dictionary</li>
        </ul>
      )}

      <div className="button-container">
        <button onClick={handleSave} className="save-button">
          Save
        </button>
        <button onClick={handlePaste} className="paste-button">
          Paste
        </button>
        <button onClick={handleClear} className="clear-button">
          Clear
        </button>
        <button onClick={handleCopyEditorText} className="copy-button">
          Copy
        </button>
        <button onClick={handleSelectAll} className="select-all-button">
          Select All
        </button>
      </div>

      {savedText && (
        <div className="saved-text-container">
          <h3>Saved Text:</h3>
          <p>{savedText}</p>
          <button onClick={handleCopy} className="copy-button">
            Copy Text
          </button>
        </div>
      )}
    </div>
  );
};

export default SpellCheckEditor;
