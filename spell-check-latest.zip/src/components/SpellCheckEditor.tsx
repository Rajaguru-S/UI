import React, { useEffect, useRef, useState } from "react";
import Typo from "typo-js";
import { loadDictionary } from "../utils/loadTypo";
import "./SpellCheckEditor.css";

const SpellCheckEditor: React.FC = () => {
  const editorRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const contextMenuRef = useRef<HTMLUListElement>(null);
  const [typo, setTypo] = useState<Typo | null>(null);
  const [customWords, setCustomWords] = useState<Set<string>>(new Set());
  const [menuVisible, setMenuVisible] = useState(false);
  const [menuPosition, setMenuPosition] = useState({ x: 0, y: 0 });
  const [menuSuggestions, setMenuSuggestions] = useState<string[]>([]);
  const [selectedWord, setSelectedWord] = useState<string | null>(null);
  const [savedText, setSavedText] = useState<string>("");

  useEffect(() => {
    loadDictionary().then(setTypo);
  }, []);

  useEffect(() => {
    const defaultText = "This is a defalt text with a mispelled word.";
    if (editorRef.current) {
      editorRef.current.innerText = defaultText;
      checkSpelling();
    }
  }, [typo]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        contextMenuRef.current &&
        !contextMenuRef.current.contains(event.target as Node)
      ) {
        setMenuVisible(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const getCaretCharacterOffset = (element: HTMLElement): number => {
    let caretOffset = 0;
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const preCaretRange = range.cloneRange();
      preCaretRange.selectNodeContents(element);
      preCaretRange.setEnd(range.endContainer, range.endOffset);
      caretOffset = preCaretRange.toString().length;
    }
    return caretOffset;
  };

  const setCaretCharacterOffset = (element: HTMLElement, offset: number) => {
    const selection = window.getSelection();
    const range = document.createRange();

    let currentNode: Node | null = element;
    let currentOffset = 0;

    const nodeIterator = document.createNodeIterator(
      element,
      NodeFilter.SHOW_TEXT,
      null
    );
    while ((currentNode = nodeIterator.nextNode())) {
      const textLength = currentNode.textContent?.length ?? 0;
      if (currentOffset + textLength >= offset) {
        const relativeOffset = offset - currentOffset;
        range.setStart(currentNode, relativeOffset);
        range.collapse(true);
        selection?.removeAllRanges();
        selection?.addRange(range);
        return;
      }
      currentOffset += textLength;
    }
  };

  const checkSpelling = () => {
    if (!typo || !editorRef.current) return;

    const el = editorRef.current;
    const caretOffset = getCaretCharacterOffset(el);

    const text = el.innerText;
    const words = text.split(/\s+/);

    const newHTML = words
      .map((word) => {
        const clean = word.replace(/[^\w']/g, "");
        if (clean && !typo.check(clean) && !customWords.has(clean)) {
          return `<span class="misspelled">${word}</span>`;
        } else {
          return word;
        }
      })
      .join(" ");

    el.innerHTML = newHTML;
    setCaretCharacterOffset(el, caretOffset);
  };

  const handleContextMenu = (e: React.MouseEvent<HTMLDivElement>) => {
    e.preventDefault();
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return;

    const range = selection.getRangeAt(0);
    const node = range.startContainer.parentElement;

    if (node && node.classList.contains("misspelled")) {
      const word = node.textContent || "";
      setSelectedWord(word);
      const suggestions = typo?.suggest(word) || [];

      const containerRect = containerRef.current?.getBoundingClientRect();
      const x = e.clientX - (containerRect?.left || 0);
      const y = e.clientY - (containerRect?.top || 0);

      setMenuSuggestions(suggestions);
      setMenuPosition({ x, y });
      setMenuVisible(true);
    } else {
      setMenuVisible(false);
    }
  };

  const replaceWord = (replacement: string) => {
    if (!editorRef.current || !selectedWord) return;
    const html = editorRef.current.innerHTML;
    const regex = new RegExp(
      `(<span class="misspelled">)${selectedWord}(</span>)`,
      "g"
    );
    const newHTML = html.replace(regex, replacement);
    editorRef.current.innerHTML = newHTML;
    setMenuVisible(false);
    checkSpelling();
  };

  const addToDictionary = () => {
    if (!selectedWord) return;
    setCustomWords(new Set([...customWords, selectedWord]));
    setMenuVisible(false);

    if (editorRef.current) {
      const html = editorRef.current.innerHTML;
      const updatedHTML = html.replace(
        new RegExp(
          `(<span class="misspelled">)(${selectedWord})(</span>)`,
          "g"
        ),
        (_, __, word) => word
      );
      editorRef.current.innerHTML = updatedHTML;
    }

    checkSpelling();
  };

  const handleSave = () => {
    if (editorRef.current) {
      setSavedText(editorRef.current.innerText);
    }
  };

  const handleCopyEditorText = () => {
    if (editorRef.current) {
      navigator.clipboard.writeText(editorRef.current.innerText).then(() => {
        alert("Editor text copied to clipboard!");
      });
    }
  };

  const handlePaste = async () => {
    if (editorRef.current) {
      const clipboardText = await navigator.clipboard.readText();
      const currentText = editorRef.current.innerText;
      editorRef.current.innerText = currentText + clipboardText;
      checkSpelling();
    }
  };

  const handleClear = () => {
    if (editorRef.current) {
      editorRef.current.innerHTML = "<br>";
      setSavedText("");
      setMenuVisible(false);
      editorRef.current.focus();
    }
  };

  const handleSelectAll = () => {
    if (!editorRef.current) return;
    const range = document.createRange();
    range.selectNodeContents(editorRef.current);
    const sel = window.getSelection();
    sel?.removeAllRanges();
    sel?.addRange(range);
  };

  return (
    <div className="editor-wrapper" ref={containerRef}>
      <div
        ref={editorRef}
        contentEditable
        spellCheck={false}
        className="editor"
        data-placeholder="Start typing..."
        onInput={checkSpelling}
        onContextMenu={handleContextMenu}
        suppressContentEditableWarning
      ></div>

      {menuVisible && (
        <ul
          ref={contextMenuRef}
          className="context-menu"
          style={{ top: menuPosition.y, left: menuPosition.x }}
        >
          {menuSuggestions.length > 0 ? (
            menuSuggestions.map((s, idx) => (
              <li key={idx} onClick={() => replaceWord(s)}>
                {s}
              </li>
            ))
          ) : (
            <li className="no-suggestions">No suggestions</li>
          )}
          <li onClick={addToDictionary}>Add to dictionary</li>
        </ul>
      )}

      <div className="button-container">
        <button onClick={handleSave}>Save</button>
        <button onClick={handlePaste}>Paste</button>
        <button onClick={handleClear}>Clear</button>
        <button onClick={handleCopyEditorText}>Copy</button>
        <button onClick={handleSelectAll}>Select All</button>
      </div>

      {savedText && (
        <div className="saved-text-container">
          <h3>Saved Text:</h3>
          <p>{savedText}</p>
        </div>
      )}
    </div>
  );
};

export default SpellCheckEditor;
