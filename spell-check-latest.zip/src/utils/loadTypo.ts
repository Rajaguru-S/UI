// src/utils/loadTypo.ts
import Typo from "typo-js";

export const loadDictionary = async (): Promise<Typo> => {
  const [affData, dicData] = await Promise.all([
    fetch("/dictionaries/en_US/en_US.aff").then((res) => res.text()),
    fetch("/dictionaries/en_US/en_US.dic").then((res) => res.text()),
  ]);
  return new Typo("en_US", affData, dicData, { platform: "any" });
};
