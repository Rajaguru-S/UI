# Fixed header and footer on scrolling table w/Accordion Separators

A Pen created on CodePen.io. Original URL: [https://codepen.io/stevegmag/pen/OKPwxo](https://codepen.io/stevegmag/pen/OKPwxo).

Completely fluid width and height fixed header and footer with a little help from JS.