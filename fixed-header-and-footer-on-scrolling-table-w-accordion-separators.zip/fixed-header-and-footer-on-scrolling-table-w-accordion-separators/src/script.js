// requires jquery library
jQuery(document).ready(function() {
   jQuery(".main-table")
    .clone(true)
    .appendTo('#table-scroll')
    .addClass('clone');
    
  jQuery(".accordion")
    .each(  function() {
      $(this).click(  function(evt) {
        evt.preventDefault();
        daGrp = $(this).attr("aria-target");
        console.log(daGrp);
        trgt = 'tr[aria-data="'+daGrp+'"';
      jQuery(trgt).toggle();
      });
    }); 
 });