export interface CodeEditRule {
  id: string;
  procedureCode: string;
  diagnosisCode: string;
  message: string;
}
