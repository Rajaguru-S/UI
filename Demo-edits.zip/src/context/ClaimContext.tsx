import React, { createContext, useContext, useState } from "react";

interface ClaimData {
  procedureCodes: string;
  diagnosisCodes: string;
  modifiers: string;
  errors: string[];
}

const ClaimContext = createContext<{
  claimData: ClaimData;
  setClaimData: React.Dispatch<React.SetStateAction<ClaimData>>;
}>({
  claimData: {
    procedureCodes: "",
    diagnosisCodes: "",
    modifiers: "",
    errors: [],
  },
  setClaimData: () => {},
});

export const ClaimProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [claimData, setClaimData] = useState<ClaimData>({
    procedureCodes: "",
    diagnosisCodes: "",
    modifiers: "",
    errors: [],
  });

  return (
    <ClaimContext.Provider value={{ claimData, setClaimData }}>
      {children}
    </ClaimContext.Provider>
  );
};

export const useClaimContext = () => useContext(ClaimContext);
