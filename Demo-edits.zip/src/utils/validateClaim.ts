export function validateClaim(data: {
  procedureCodes: string;
  diagnosisCodes: string;
  modifiers: string;
}): string[] {
  const errors: string[] = [];

  if (data.procedureCodes.includes("99213") && !data.modifiers.includes("25")) {
    errors.push("Procedure 99213 requires modifier 25.");
  }

  if (
    data.procedureCodes.includes("11055") &&
    !data.diagnosisCodes.includes("L84")
  ) {
    errors.push("11055 is not valid without L84 diagnosis.");
  }

  return errors;
}
