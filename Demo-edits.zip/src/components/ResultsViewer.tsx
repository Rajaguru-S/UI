import React from "react";
import { useClaimContext } from "../context/ClaimContext";

const ResultsViewer: React.FC = () => {
  const { claimData } = useClaimContext();

  return (
    <div>
      <h2>Validation Results</h2>
      {claimData.errors.length > 0 ? (
        <ul>
          {claimData.errors.map((error, index) => (
            <li key={index}>{error}</li>
          ))}
        </ul>
      ) : (
        <p>No errors found.</p>
      )}
    </div>
  );
};

export default ResultsViewer;
