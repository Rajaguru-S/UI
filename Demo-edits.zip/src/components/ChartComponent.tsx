import React from "react";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(BarElement, CategoryScale, LinearScale, Tooltip, Legend);

const ChartComponent: React.FC<{
  claimStats: { valid: number; invalid: number };
}> = ({ claimStats }) => {
  const data = {
    labels: ["Valid Claims", "Invalid Claims"],
    datasets: [
      {
        label: "Claims Count",
        data: [claimStats.valid, claimStats.invalid],
        backgroundColor: ["#198754", "#dc3545"],
      },
    ],
  };

  return (
    <div className="mb-5">
      <h4>📊 Claim Summary</h4>
      <Bar data={data} />
    </div>
  );
};

export default ChartComponent;
