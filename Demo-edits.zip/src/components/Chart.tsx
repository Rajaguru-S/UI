import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const data = [
  { name: "Jan", accepted: 4000, rejected: 2400 },
  { name: "Feb", accepted: 3000, rejected: 1398 },
  { name: "Mar", accepted: 2000, rejected: 9800 },
  { name: "Apr", accepted: 2780, rejected: 3908 },
  { name: "May", accepted: 1890, rejected: 4800 },
  { name: "Jun", accepted: 2390, rejected: 3800 },
  { name: "Jul", accepted: 3490, rejected: 4300 },
];

const Chart: React.FC = () => (
  <>
    <h4 className="mb-4">📊 Overall Claim Summary</h4>
    <ResponsiveContainer width="100%" height={400}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="accepted" stroke="#8884d8" />
        <Line type="monotone" dataKey="rejected" stroke="#82ca9d" />
      </LineChart>
    </ResponsiveContainer>
  </>
);

export default Chart;
