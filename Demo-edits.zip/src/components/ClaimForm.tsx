import React, { useState } from "react";
import { validateClaim } from "../utils/validateClaim";

const procedureCodes = [
  { code: "99213", description: "Office Visit - Level 3" },
  { code: "11055", description: "Removal of Corns/Callosities" },
  { code: "99214", description: "Office Visit - Level 4" },
];

const diagnosisCodes = [
  { code: "E11.9", description: "Type 2 Diabetes Mellitus" },
  { code: "L84", description: "Corns and Callosities" },
  { code: "M54.5", description: "Low Back Pain" },
];

const modifiers = [
  { code: "25", description: "Significant E/M" },
  { code: "59", description: "Distinct Procedural Service" },
];

interface ClaimFormProps {
  onSingleClaimSubmit: (claim: any) => void;
}

const ClaimForm: React.FC<ClaimFormProps> = ({ onSingleClaimSubmit }) => {
  const [formData, setFormData] = useState({
    procedureCodes: "",
    diagnosisCodes: "",
    modifiers: "",
  });
  const [errors, setErrors] = useState<string[]>([]);

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validateClaim(formData);
    setErrors(validationErrors);
    onSingleClaimSubmit({ ...formData, errors: validationErrors });
  };

  return (
    <div className="mb-5">
      <h4>📝 Submit Single Claim</h4>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Procedure Code</label>
          <select
            className="form-select"
            name="procedureCodes"
            value={formData.procedureCodes}
            onChange={handleChange}
            required
          >
            <option value="">Select</option>
            {procedureCodes.map((p) => (
              <option key={p.code} value={p.code}>
                {p.code} - {p.description}
              </option>
            ))}
          </select>
        </div>
        <div className="mb-3">
          <label className="form-label">Diagnosis Code</label>
          <select
            className="form-select"
            name="diagnosisCodes"
            value={formData.diagnosisCodes}
            onChange={handleChange}
            required
          >
            <option value="">Select</option>
            {diagnosisCodes.map((d) => (
              <option key={d.code} value={d.code}>
                {d.code} - {d.description}
              </option>
            ))}
          </select>
        </div>
        <div className="mb-3">
          <label className="form-label">Modifier</label>
          <select
            className="form-select"
            name="modifiers"
            value={formData.modifiers}
            onChange={handleChange}
          >
            <option value="">None</option>
            {modifiers.map((m) => (
              <option key={m.code} value={m.code}>
                {m.code} - {m.description}
              </option>
            ))}
          </select>
        </div>
        <button type="submit" className="btn btn-success w-100">
          Submit Claim
        </button>
      </form>

      {errors.length > 0 && (
        <div className="alert alert-danger mt-3">
          <strong>Validation Errors:</strong>
          <ul>
            {errors.map((err, i) => (
              <li key={i}>{err}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default ClaimForm;
