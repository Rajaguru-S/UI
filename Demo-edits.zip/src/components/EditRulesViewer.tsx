import React from "react";
import { useClaimContext } from "../context/ClaimContext";

const EditRulesViewer: React.FC = () => {
  const { claimData } = useClaimContext();

  return (
    <div>
      <h2>Applied Code Edits</h2>
      <ul>
        {claimData.errors.map((error, index) => (
          <li key={index}>{error}</li>
        ))}
      </ul>
    </div>
  );
};

export default EditRulesViewer;
