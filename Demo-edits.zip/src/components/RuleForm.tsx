import React from 'react';
import { CodeEditRule } from '../types';

interface RuleFormProps {
  rule: CodeEditRule;
  onChange: (rule: CodeEditRule) => void;
  onDelete: () => void;
}

const RuleForm: React.FC<RuleFormProps> = ({ rule, onChange, onDelete }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    onChange({ ...rule, [name]: value });
  };

  return (
    <div className="border p-3 mb-3 rounded">
      <div className="row mb-2">
        <div className="col">
          <input
            className="form-control"
            name="procedureCode"
            placeholder="Procedure Code"
            value={rule.procedureCode}
            onChange={handleChange}
          />
        </div>
        <div className="col">
          <input
            className="form-control"
            name="diagnosisCode"
            placeholder="Required Diagnosis Code"
            value={rule.diagnosisCode}
            onChange={handleChange}
          />
        </div>
        <div className="col">
          <input
            className="form-control"
            name="message"
            placeholder="Validation Message"
            value={rule.message}
            onChange={handleChange}
          />
        </div>
        <div className="col-auto">
          <button className="btn btn-danger" onClick={onDelete}>Delete</button>
        </div>
      </div>
    </div>
  );
};

export default RuleForm;
