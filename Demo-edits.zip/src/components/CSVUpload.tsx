import React, { useState } from "react";
import Papa from "papaparse";
import { validateClaim } from "../utils/validateClaim";

interface CSVClaim {
  procedureCodes: string;
  diagnosisCodes: string;
  modifiers: string;
}

interface ClaimWithErrors extends CSVClaim {
  errors: string[];
}

interface CSVUploadProps {
  onClaimsParsed: (claims: ClaimWithErrors[]) => void;
}

const CSVUpload: React.FC<CSVUploadProps> = ({ onClaimsParsed }) => {
  const [file, setFile] = useState<File | null>(null);
  const [errorClaims, setErrorClaims] = useState<ClaimWithErrors[]>([]);
  const [successMessage, setSuccessMessage] = useState<string>("");

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setSuccessMessage("");
      setErrorClaims([]);
    }
  };

  const handleFileUpload = () => {
    if (!file) return;

    Papa.parse(file, {
      complete: (result: any) => {
        const rows = result.data as CSVClaim[];
        const claims: ClaimWithErrors[] = [];

        rows.forEach((claim) => {
          const errors = validateClaim(claim);
          claims.push({ ...claim, errors });
        });

        const invalidClaims = claims.filter((c) => c.errors.length > 0);
        setErrorClaims(invalidClaims);

        if (invalidClaims.length === 0) {
          setSuccessMessage("✅ All claims are valid!");
        }

        onClaimsParsed(claims);
      },
      header: true,
      skipEmptyLines: true,
    });
  };

  return (
    <div className="mb-5">
      <h4>📥 Upload Claims via CSV</h4>
      <input
        type="file"
        accept=".csv"
        className="form-control mb-2"
        onChange={handleFileChange}
      />
      <button className="btn btn-primary w-100" onClick={handleFileUpload}>
        Upload & Validate
      </button>

      {successMessage && (
        <div className="alert alert-success mt-3">{successMessage}</div>
      )}

      {errorClaims.length > 0 && (
        <div className="alert alert-danger mt-3">
          <h5>Validation Errors</h5>
          <div style={{ maxHeight: "250px", overflowY: "auto" }}>
            {errorClaims.map((claim, idx) => (
              <div key={idx} className="border-top pt-2 mt-2">
                <p>
                  <strong>Claim #{idx + 1}</strong>
                </p>
                <p>
                  Proc: {claim.procedureCodes}, Dx: {claim.diagnosisCodes}, Mod:{" "}
                  {claim.modifiers || "(none)"}
                </p>
                <ul>
                  {claim.errors.map((err, i) => (
                    <li key={i}>{err}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default CSVUpload;
