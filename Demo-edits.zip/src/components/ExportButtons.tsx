import React from "react";
import { saveAs } from "file-saver";
import jsPDF from "jspdf";

interface ExportButtonsProps {
  claims: any[];
}

const ExportButtons: React.FC<ExportButtonsProps> = ({ claims }) => {
  const handleCSV = () => {
    const headers = ["Procedure", "Diagnosis", "Modifiers", "Errors"];
    const rows = claims.map((c) => [
      c.procedureCodes,
      c.diagnosisCodes,
      c.modifiers,
      c.errors.join("; "),
    ]);
    const csvContent = [
      headers.join(","),
      ...rows.map((r) => r.join(",")),
    ].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, "claims.csv");
  };

  const handlePDF = () => {
    const doc = new jsPDF();
    doc.text("Claim Report", 10, 10);
    claims.forEach((c, i) => {
      const y = 20 + i * 20;
      doc.text(
        `${i + 1}. ${c.procedureCodes}, ${c.diagnosisCodes}, ${c.modifiers}`,
        10,
        y
      );
      if (c.errors.length > 0) {
        doc.text(`Errors: ${c.errors.join("; ")}`, 10, y + 7);
      }
    });
    doc.save("claims.pdf");
  };

  return (
    <div className="mb-5">
      <h4>📤 Export Claims</h4>
      <div className="d-flex gap-2">
        <button className="btn btn-outline-primary" onClick={handleCSV}>
          Export CSV
        </button>
        <button className="btn btn-outline-danger" onClick={handlePDF}>
          Export PDF
        </button>
      </div>
    </div>
  );
};

export default ExportButtons;
