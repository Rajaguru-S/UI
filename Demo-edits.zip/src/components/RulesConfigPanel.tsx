import React, { useState } from "react";
//import { v4 as uuidv4 } from "uuid";
import { CodeEditRule } from "../types";
import RuleForm from "./RuleForm";

const RulesConfigPanel: React.FC = () => {
  const [rules, setRules] = useState<CodeEditRule[]>([]);

  const addRule = () => {
    setRules([
      ...rules,
      { id: "1", procedureCode: "", diagnosisCode: "", message: "" },
    ]);
  };

  const updateRule = (index: number, newRule: CodeEditRule) => {
    const updated = [...rules];
    updated[index] = newRule;
    setRules(updated);
  };

  const deleteRule = (index: number) => {
    setRules(rules.filter((_, i) => i !== index));
  };

  const saveRules = () => {
    // Save to API or localStorage in real use
    console.log("Saved Rules:", rules);
    alert("Rules saved (see console)");
  };

  return (
    <div className="container mt-4">
      <h3>⚙️ Code Edit Rules Configuration</h3>
      <button className="btn btn-outline-primary mb-3" onClick={addRule}>
        ➕ Add Rule
      </button>
      {rules.map((rule, idx) => (
        <RuleForm
          key={rule.id}
          rule={rule}
          onChange={(updated) => updateRule(idx, updated)}
          onDelete={() => deleteRule(idx)}
        />
      ))}
      <button className="btn btn-success" onClick={saveRules}>
        💾 Save Rules
      </button>
    </div>
  );
};

export default RulesConfigPanel;
