import React, { useState } from "react";
import { validateClaim } from "../utils/validateClaim";

interface Claim {
  procedureCodes: string;
  diagnosisCodes: string;
  modifiers: string[]; // modifiers is an array of strings
  errors: string[]; // errors is an array of strings
}

const procedureCodes = [
  { code: "99213", description: "Office Visit - Level 3" },
  { code: "11055", description: "Removal of Corns/Callosities" },
  { code: "99214", description: "Office Visit - Level 4" },
];

const diagnosisCodes = [
  { code: "E11.9", description: "Type 2 Diabetes Mellitus" },
  { code: "L84", description: "Corns and Callosities" },
  { code: "M54.5", description: "Low Back Pain" },
];

const modifiers = [
  { code: "25", description: "Significant E/M" },
  { code: "59", description: "Distinct Procedural Service" },
];

const MultiClaimForm: React.FC = () => {
  const [claims, setClaims] = useState<Claim[]>([
    { procedureCodes: "", diagnosisCodes: "", modifiers: [], errors: [] },
  ]);
  const [submitted, setSubmitted] = useState(false);

  // Updating handleChange to ensure proper type handling for `name`
  const handleChange = (
    index: number,
    name: keyof Claim,
    value: string | string[]
  ) => {
    const newClaims = [...claims];

    // Use type guard to handle the modifiers field specifically
    if (name === "modifiers") {
      // Handle modifiers as an array (multiple selections)
      newClaims[index][name] = Array.isArray(value) ? value : [value];
    } else if (name === "procedureCodes" || name === "diagnosisCodes") {
      // For other fields (procedureCodes, diagnosisCodes), handle as string
      newClaims[index][name] = value as string;
    }

    setClaims(newClaims);
  };

  const handleAdd = () => {
    setClaims([
      ...claims,
      { procedureCodes: "", diagnosisCodes: "", modifiers: [], errors: [] },
    ]);
  };

  const handleRemove = (index: number) => {
    const newClaims = claims.filter((_, i) => i !== index);
    setClaims(newClaims);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validatedClaims = claims.map((claim: any) => ({
      ...claim,
      errors: validateClaim(claim),
    }));
    setClaims(validatedClaims);
    setSubmitted(true);
  };

  return (
    <div className="container mb-5">
      <h4>📥 Submit Multiple Claims</h4>
      <form onSubmit={handleSubmit}>
        {claims.map((claim, index) => (
          <div key={index} className="border p-3 mb-3 rounded">
            <div className="row">
              <div className="col-md-4 mb-2">
                <label className="form-label">Procedure Code</label>
                <select
                  className="form-select"
                  value={claim.procedureCodes}
                  onChange={(e) =>
                    handleChange(index, "procedureCodes", e.target.value)
                  }
                  required
                >
                  <option value="">Select</option>
                  {procedureCodes.map((p) => (
                    <option key={p.code} value={p.code}>
                      {p.code} - {p.description}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-md-4 mb-2">
                <label className="form-label">Diagnosis Code</label>
                <select
                  className="form-select"
                  value={claim.diagnosisCodes}
                  onChange={(e) =>
                    handleChange(index, "diagnosisCodes", e.target.value)
                  }
                  required
                >
                  <option value="">Select</option>
                  {diagnosisCodes.map((d) => (
                    <option key={d.code} value={d.code}>
                      {d.code} - {d.description}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-md-3 mb-2">
                <label className="form-label">Modifier</label>
                <select
                  className="form-select"
                  value={claim.modifiers}
                  onChange={(e) =>
                    handleChange(
                      index,
                      "modifiers",
                      Array.from(
                        e.target.selectedOptions,
                        (option) => option.value
                      )
                    )
                  }
                  multiple
                >
                  <option value="">None</option>
                  {modifiers.map((m) => (
                    <option key={m.code} value={m.code}>
                      {m.code} - {m.description}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-md-1 d-flex align-items-end">
                <button
                  type="button"
                  className="btn btn-outline-danger btn-sm"
                  onClick={() => handleRemove(index)}
                  disabled={claims.length === 1}
                >
                  ✕
                </button>
              </div>
            </div>

            {submitted && claim.errors.length > 0 && (
              <div className="alert alert-danger mt-2">
                <ul className="mb-0">
                  {claim.errors.map((err, i) => (
                    <li key={i}>{err}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}

        <div className="d-flex justify-content-between">
          <button
            type="button"
            className="btn btn-outline-secondary"
            onClick={handleAdd}
          >
            ➕ Add Claim
          </button>
          <button type="submit" className="btn btn-success">
            ✅ Submit All
          </button>
        </div>
      </form>
    </div>
  );
};

export default MultiClaimForm;
