import React, { useState } from "react";
import { ClaimProvider } from "./context/ClaimContext";
import ClaimForm from "./components/ClaimForm";
import CSVUpload from "./components/CSVUpload";
import ChartComponent from "./components/ChartComponent";
import ExportButtons from "./components/ExportButtons";
import MultiClaimForm from "./components/MultiClaimForm";
import Chart from "./components/Chart";
import RulesConfigPanel from "./components/RulesConfigPanel";

const App: React.FC = () => {
  const [claims, setClaims] = useState<any[]>([]);

  const handleClaimsUpdate = (newClaims: any[]) => {
    setClaims(newClaims);
  };

  const handleSingleClaimSubmit = (claim: any) => {
    setClaims((prev) => [...prev, claim]);
  };

  const valid = claims.filter((c) => c.errors?.length === 0).length;
  const invalid = claims.length - valid;

  return (
    <ClaimProvider>
      <div className="container my-4">
        <h1 className="mb-4">🏥 Healthcare Claim Submission</h1>
        <CSVUpload onClaimsParsed={handleClaimsUpdate} />
        <ClaimForm onSingleClaimSubmit={handleSingleClaimSubmit} />
        {/* <MultiClaimForm /> */}
        <ChartComponent claimStats={{ valid, invalid }} />

        <Chart />
        {/* <h1 className="text-center mt-3">Admin Portal: Code Edit Rules</h1>
        <RulesConfigPanel /> */}
        <ExportButtons claims={claims} />
      </div>
    </ClaimProvider>
  );
};

export default App;
