declare module "papaparse" {
  const Papa: any;
  export = Papa;
}
