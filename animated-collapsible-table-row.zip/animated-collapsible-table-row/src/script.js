$("tr.collapse").find("span#collapse").click(function() {
  $(this).parents("tr.collapse").toggleClass("active"); 
  
  if ($(this).text() == "Open")
       $(this).text("Close")
    else
       $(this).text("Open");

});
