# animated collapsible table-row

A Pen created on CodePen.io. Original URL: [https://codepen.io/urgenism/pen/yKmaqM](https://codepen.io/urgenism/pen/yKmaqM).

