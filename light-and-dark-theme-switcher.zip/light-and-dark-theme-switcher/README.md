# Light and Dark theme switcher

A Pen created on CodePen.io. Original URL: [https://codepen.io/haxzie/pen/xxKNEGM](https://codepen.io/haxzie/pen/xxKNEGM).

