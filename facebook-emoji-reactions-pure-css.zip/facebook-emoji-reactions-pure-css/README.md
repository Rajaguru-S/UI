# Facebook Emoji Reactions | Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/AshBardhan/pen/dNKwXz](https://codepen.io/AshBardhan/pen/dNKwXz).

Inspiration Source : http://iconstore-1.ambercreativelab.netdna-cdn.com/wp-content/uploads/2015/12/fb-emoji-featured.png