# Table with fixed header, footer and left column using position:sticky 

A Pen created on CodePen.io. Original URL: [https://codepen.io/paulobrien/pen/LBrMxa](https://codepen.io/paulobrien/pen/LBrMxa).

A simple way to have fixed headers and footers on long scrollable tables without JS and without harming older browsers.

