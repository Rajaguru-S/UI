import { useState, useRef, useEffect } from 'react';
import '@pdfjs/pdfjs-viewer-element/lib/components/pdfjs-viewer-element.css';
import '@pdfjs/pdfjs-viewer-element';

const PdfViewerWithContextMenu = () => {
  const [selectedText, setSelectedText] = useState('');
  const [menuPosition, setMenuPosition] = useState({ x: 0, y: 0, visible: false });
  const [savedTexts, setSavedTexts] = useState([]);
  const viewerRef = useRef(null);

  useEffect(() => {
    const viewer = viewerRef.current;
    
    const handleTextSelect = () => {
      const selection = window.getSelection();
      if (selection.toString().trim()) {
        setSelectedText(selection.toString());
      }
    };

    const handleContextMenu = (e) => {
      const selection = window.getSelection().toString().trim();
      if (selection) {
        e.preventDefault();
        setMenuPosition({
          x: e.clientX,
          y: e.clientY,
          visible: true
        });
      }
    };

    // Add event listeners
    viewer.addEventListener('mouseup', handleTextSelect);
    viewer.addEventListener('contextmenu', handleContextMenu);

    // Set PDF file source
    viewer.src = '/sample.pdf';

    return () => {
      viewer.removeEventListener('mouseup', handleTextSelect);
      viewer.removeEventListener('contextmenu', handleContextMenu);
    };
  }, []);

  // Close menu when clicking outside
  useEffect(() => {
    const closeMenu = () => setMenuPosition(pos => ({ ...pos, visible: false }));
    window.addEventListener('click', closeMenu);
    return () => window.removeEventListener('click', closeMenu);
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedText);
    setMenuPosition({ ...menuPosition, visible: false });
  };

  const handleSaveToState = () => {
    setSavedTexts(prev => [...prev, selectedText]);
    setMenuPosition({ ...menuPosition, visible: false });
  };

  return (
    <div style={{ position: 'relative' }}>
      <pdfjs-viewer 
        ref={viewerRef}
        style={{ height: '90vh', width: '100%' }}
        page="1"
        spread="false"
      ></pdfjs-viewer>

      {/* Custom Context Menu */}
      {menuPosition.visible && (
        <div 
          style={{
            position: 'fixed',
            left: menuPosition.x,
            top: menuPosition.y,
            backgroundColor: 'white',
            border: '1px solid #ccc',
            boxShadow: '2px 2px 5px rgba(0,0,0,0.2)',
            zIndex: 1000
          }}
        >
          <button
            onClick={handleCopy}
            style={{
              display: 'block',
              width: '100%',
              padding: '8px 16px',
              border: 'none',
              background: 'none',
              textAlign: 'left',
              cursor: 'pointer'
            }}
          >
            Copy
          </button>
          <button
            onClick={handleSaveToState}
            style={{
              display: 'block',
              width: '100%',
              padding: '8px 16px',
              border: 'none',
              background: 'none',
              textAlign: 'left',
              cursor: 'pointer',
              borderTop: '1px solid #eee'
            }}
          >
            Save to State
          </button>
        </div>
      )}

      <div style={{ padding: '20px' }}>
        <h3>Selected Text: {selectedText}</h3>
        <h4>Saved Texts:</h4>
        <ul>
          {savedTexts.map((text, index) => (
            <li key={index}>{text}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default PdfViewerWithContextMenu;