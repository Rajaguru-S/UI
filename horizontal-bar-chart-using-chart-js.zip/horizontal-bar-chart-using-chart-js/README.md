# Horizontal bar chart using Chart JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/tomfarrell/pen/JpxGNm](https://codepen.io/tomfarrell/pen/JpxGNm).

