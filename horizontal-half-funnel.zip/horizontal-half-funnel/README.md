# Horizontal Half Funnel

A Pen created on CodePen.io. Original URL: [https://codepen.io/krishna22/pen/YmJZBe](https://codepen.io/krishna22/pen/YmJZBe).

Horizontal half funnel graph using HTML canvas.