import { Task } from '../types/task';
import { AppSettings, DEFAULT_SETTINGS } from '../types/settings';
import { v4 as uuidv4 } from 'uuid';
import { generateSampleTasks } from '../utils/seedData';

const TASKS_KEY = 'wtb_tasks';
const SETTINGS_KEY = 'wtb_settings';

export const storageService = {
  getSettings: (): AppSettings => {
    try {
      const data = localStorage.getItem(SETTINGS_KEY);
      if (data) {
        const parsed = JSON.parse(data) as AppSettings;
        // Merge with defaults to ensure all keys (like newly added 'owners') exist
        const merged = {
          ...DEFAULT_SETTINGS,
          ...parsed,
          fieldOptions: {
            ...DEFAULT_SETTINGS.fieldOptions,
            ...(parsed.fieldOptions || {})
          }
        };
        return merged;
      }
      storageService.saveSettings(DEFAULT_SETTINGS);
      return DEFAULT_SETTINGS;
    } catch (e) {
      console.error('Failed to load settings', e);
      return DEFAULT_SETTINGS;
    }
  },

  saveSettings: (settings: AppSettings): void => {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save settings', e);
    }
  },

  getTasks: (): Task[] => {
    try {
      const data = localStorage.getItem(TASKS_KEY);
      if (data) {
        const tasks = JSON.parse(data);
        // Migration: convert old ownerId (string) → ownerIds (string[])
        let needsSave = false;
        const migrated = tasks.map((t: any) => {
          if (t.ownerId && !t.ownerIds) {
            needsSave = true;
            return { ...t, ownerIds: [t.ownerId], ownerId: undefined };
          }
          if (!t.ownerIds) {
            needsSave = true;
            return { ...t, ownerIds: [] };
          }
          return t;
        });
        if (needsSave) {
          storageService.saveTasks(migrated);
        }
        return migrated;
      }
      // If no tasks, generate seed data and save it
      const seedData = generateSampleTasks();
      storageService.saveTasks(seedData);
      return seedData;
    } catch (e) {
      console.error('Failed to load tasks', e);
      return [];
    }
  },

  saveTasks: (tasks: Task[]): void => {
    try {
      localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
    } catch (e) {
      console.error('Failed to save tasks', e);
    }
  },

  addTask: (task: Omit<Task, 'id' | 'taskNumber' | 'createdAt' | 'updatedAt'>): Task => {
    const tasks = storageService.getTasks();
    
    // Generate Task Number based on max current
    let maxId = 1000;
    tasks.forEach(t => {
      const num = parseInt(t.taskNumber.replace('TASK-', ''), 10);
      if (!isNaN(num) && num > maxId) {
        maxId = num;
      }
    });
    
    const newTask: Task = {
      ...task,
      id: uuidv4(),
      taskNumber: `TASK-${maxId + 1}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      activities: [{
        id: uuidv4(),
        date: new Date().toISOString(),
        description: 'Task created'
      }]
    };
    
    tasks.push(newTask);
    storageService.saveTasks(tasks);
    return newTask;
  },

  updateTask: (updatedTask: Task): void => {
    const tasks = storageService.getTasks();
    const index = tasks.findIndex(t => t.id === updatedTask.id);
    if (index !== -1) {
      updatedTask.updatedAt = new Date().toISOString();
      tasks[index] = updatedTask;
      storageService.saveTasks(tasks);
    }
  },

  deleteTask: (id: string): void => {
    const tasks = storageService.getTasks();
    const updatedTasks = tasks.filter(t => t.id !== id);
    storageService.saveTasks(updatedTasks);
  },

  clearData: (): void => {
    localStorage.removeItem(TASKS_KEY);
    localStorage.removeItem(SETTINGS_KEY);
  },

  exportData: (): string => {
    const data = {
      tasks: storageService.getTasks(),
      settings: localStorage.getItem(SETTINGS_KEY) ? JSON.parse(localStorage.getItem(SETTINGS_KEY)!) : {}
    };
    return JSON.stringify(data, null, 2);
  },

  importData: (jsonData: string): boolean => {
    try {
      const data = JSON.parse(jsonData);
      if (data.tasks && Array.isArray(data.tasks)) {
        storageService.saveTasks(data.tasks);
        if (data.settings) {
          localStorage.setItem(SETTINGS_KEY, JSON.stringify(data.settings));
        }
        return true;
      }
      return false;
    } catch (e) {
      console.error('Failed to import data', e);
      return false;
    }
  }
};
