import { Task, TaskCategory, WorkType, Priority, TaskStatus, DeliveryEnvironment, DeliveryHealth } from '../types/task';
import { v4 as uuidv4 } from 'uuid';
import { addDays, subDays, format } from 'date-fns';

const USERS = ['Raj', 'Kumar', 'Sarah', 'Alex', 'Priya', 'Michael'];
const CATEGORIES: TaskCategory[] = ['Development', 'Enhancement', 'Bug', 'Support', 'Configuration', 'Analysis', 'Release'];
const WORK_TYPES: WorkType[] = ['Product Backlog', 'Bug', 'Enhancement', 'Support'];
const PRIORITIES: Priority[] = ['Critical', 'High', 'Medium', 'Low'];
const STATUSES: TaskStatus[] = ['NEW', 'READY FOR WORK', 'DEV IN PROGRESS', 'READY FOR QA', 'QA IN PROGRESS', 'READY FOR ACCEPTANCE', 'READY FOR UAT', 'UAT RELEASED', 'READY FOR RELEASE', 'DONE'];

function randomItem<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomDate(start: Date, end: Date): string {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime())).toISOString();
}

export function generateSampleTasks(): Task[] {
  const tasks: Task[] = [];
  const now = new Date();
  const currentMonth = format(now, 'MMMM yyyy'); // e.g. "August 2026"

  const sampleNames = [
    'Implement Provider Validation',
    'Claim rule update',
    'Database Migration Script',
    'Fix memory leak in Dashboard',
    'User Shadowing for Finance Team',
    'SSO Integration for Vendor Portal',
    'Update API Documentation',
    'Configure Production Servers',
    'Fix responsive layout in Settings',
    'Optimize Search Queries',
    'Implement Password Reset Flow',
    'Audit Security Logs',
    'Prepare Release Notes',
    'Resolve UAT Feedback from HR',
    'Upgrade React to v19',
    'Implement 2FA Support',
    'Data export tool implementation',
    'Update legal disclaimers',
    'Refactor routing system',
    'Update dependency versions',
    'Fix login timeout issue',
    'Redesign navigation sidebar',
    'Implement dark mode',
    'Automate daily reporting',
    'Fix caching invalidation'
  ];

  sampleNames.forEach((name, idx) => {
    const status = randomItem(STATUSES);
    const uatHandover = addDays(now, Math.floor(Math.random() * 10) - 2).toISOString();
    const targetProd = addDays(now, Math.floor(Math.random() * 20) + 2).toISOString();
    
    // Some are overdue
    const isOverdue = Math.random() > 0.8 && status !== 'DONE';
    const pastProd = isOverdue ? subDays(now, 5).toISOString() : targetProd;

    const task: Task = {
      id: uuidv4(),
      taskNumber: `TASK-${1000 + idx + 1}`,
      taskDate: new Date().toISOString(),
      month: currentMonth,
      name,
      category: randomItem(CATEGORIES),
      workType: randomItem(WORK_TYPES),
      ownerIds: Array.from({ length: Math.floor(Math.random() * 3) + 1 }, () => randomItem(USERS)).filter((v, i, a) => a.indexOf(v) === i),
      priority: randomItem(PRIORITIES),
      status,
      comments: 'Sample task generated automatically.',
      environment: 'UAT + Production',
      uatHandoverDate: uatHandover,
      targetProdDate: pastProd,
      health: 'On Track', // will be recalculated dynamically later or handled by utils
      progress: Math.floor(Math.random() * 100),
      createdAt: subDays(now, Math.floor(Math.random() * 10)).toISOString(),
      updatedAt: subDays(now, Math.floor(Math.random() * 2)).toISOString(),
      activities: [{
        id: uuidv4(),
        date: subDays(now, 10).toISOString(),
        description: 'Task created'
      }]
    };

    if (Math.random() > 0.8) {
      task.isBlocked = true;
      task.blockerComment = 'Waiting for API access approval';
      task.health = 'Blocked';
    } else if (isOverdue) {
      task.health = 'At Risk';
    } else if (status === 'DONE') {
      task.health = 'Completed';
      task.progress = 100;
    }

    tasks.push(task);
  });

  return tasks;
}
