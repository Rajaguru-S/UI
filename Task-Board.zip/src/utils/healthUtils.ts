import { Task, DeliveryHealth } from '../types/task';

export function calculateTaskHealth(task: Partial<Task>): DeliveryHealth {
  if (task.status === 'DONE') {
    return 'Completed';
  }
  
  if (task.isBlocked) {
    return 'Blocked';
  }
  
  // Spill over check: If we have a spillOverProdDate or the task explicitly marked spill-over, 
  // or if target month is different from current month (this requires knowing "current month", 
  // but let's just use spillOverProdDate existence for now)
  if (task.spillOverProdDate) {
    return 'Spill Over';
  }
  
  // At risk check: 
  if (task.targetProdDate) {
    const targetDate = new Date(task.targetProdDate);
    const today = new Date();
    // Overdue or within 2 days of production but not yet in UAT/Release
    if (targetDate < today && task.status !== 'READY FOR RELEASE') {
      return 'At Risk';
    }
  }

  // On track
  return 'On Track';
}
