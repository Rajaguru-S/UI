import React, { createContext, useContext, useState, useEffect, ReactNode, useMemo } from 'react';
import { AppSettings, FieldOptions, DEFAULT_SETTINGS } from '../types/settings';
import { storageService } from '../services/storageService';

interface SettingsContextType {
  settings: AppSettings;
  updateFieldOptions: (fieldName: keyof FieldOptions, options: string[]) => void;
  refreshSettings: () => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);

  const refreshSettings = () => {
    setSettings(storageService.getSettings());
  };

  useEffect(() => {
    refreshSettings();
  }, []);

  const updateFieldOptions = (fieldName: keyof FieldOptions, options: string[]) => {
    const updatedSettings = {
      ...settings,
      fieldOptions: {
        ...settings.fieldOptions,
        [fieldName]: options,
      }
    };
    storageService.saveSettings(updatedSettings);
    setSettings(updatedSettings);
  };

  const value = useMemo(() => ({
    settings,
    updateFieldOptions,
    refreshSettings
  }), [settings]);

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}
