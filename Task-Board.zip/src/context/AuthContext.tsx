import { createContext, useContext, useState, ReactNode, useCallback } from 'react';

export interface AuthUser {
  name: string;
  email: string;
  initials: string;
  role: string;
}

interface AuthContextValue {
  user: AuthUser | null;
  isAuthenticated: boolean;
  signIn: (email: string, password: string) => boolean;
  signOut: () => void;
  updateProfile: (name: string, newPassword?: string) => void;
}

const STORAGE_KEY = 'wtb_auth_user';
const USERS_DB_KEY = 'wtb_auth_db';

const MOCK_USERS: Array<{ email: string; password: string; user: AuthUser }> = [
  {
    email: 'pm@enterprise.com',
    password: 'password123',
    user: { name: 'Project Manager', email: 'pm@enterprise.com', initials: 'PM', role: 'Project Manager' },
  },
  {
    email: 'dev@enterprise.com',
    password: 'password123',
    user: { name: 'Dev Lead', email: 'dev@enterprise.com', initials: 'DL', role: 'Developer' },
  },
  {
    email: 'admin@enterprise.com',
    password: 'admin123',
    user: { name: 'Admin User', email: 'admin@enterprise.com', initials: 'AU', role: 'Administrator' },
  },
];

const AuthContext = createContext<AuthContextValue | null>(null);

function loadUser(): AuthUser | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as AuthUser) : null;
  } catch {
    return null;
  }
}

function loadUsersDb(): Array<{ email: string; password: string; user: AuthUser }> {
  try {
    const raw = localStorage.getItem(USERS_DB_KEY);
    if (raw) return JSON.parse(raw);
    localStorage.setItem(USERS_DB_KEY, JSON.stringify(MOCK_USERS));
    return MOCK_USERS;
  } catch {
    return MOCK_USERS;
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(loadUser);
  const [usersDb, setUsersDb] = useState(loadUsersDb);

  const signIn = useCallback((email: string, password: string): boolean => {
    const db = loadUsersDb();
    const match = db.find(
      (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );
    if (match) {
      setUser(match.user);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(match.user));
      return true;
    }
    return false;
  }, []);

  const signOut = useCallback(() => {
    setUser(null);
    localStorage.removeItem(STORAGE_KEY);
  }, []);

  const updateProfile = useCallback((name: string, newPassword?: string) => {
    if (!user) return;
    
    // Update local state user
    const initials = name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() || 'U';
    const updatedUser = { ...user, name, initials };
    
    // Update DB
    const db = loadUsersDb();
    const index = db.findIndex(u => u.email === user.email);
    if (index !== -1) {
      db[index].user = updatedUser;
      if (newPassword) {
        db[index].password = newPassword;
      }
      localStorage.setItem(USERS_DB_KEY, JSON.stringify(db));
      setUsersDb(db);
    }

    // Update active user session
    setUser(updatedUser);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedUser));
  }, [user]);

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, signIn, signOut, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
