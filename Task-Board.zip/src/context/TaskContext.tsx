import React, { createContext, useContext, useState, useEffect, ReactNode, useMemo } from 'react';
import { Task, TaskStatus } from '../types/task';
import { storageService } from '../services/storageService';
import { calculateTaskHealth } from '../utils/healthUtils';

interface TaskContextType {
  tasks: Task[];
  refreshTasks: () => void;
  addTask: (task: Omit<Task, 'id' | 'taskNumber' | 'createdAt' | 'updatedAt'>) => void;
  updateTask: (task: Task) => void;
  deleteTask: (id: string) => void;
  moveTask: (id: string, newStatus: TaskStatus) => void;
}

const TaskContext = createContext<TaskContextType | undefined>(undefined);

export function TaskProvider({ children }: { children: ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>([]);

  const refreshTasks = () => {
    setTasks(storageService.getTasks());
  };

  useEffect(() => {
    refreshTasks();
  }, []);

  const addTask = (task: Omit<Task, 'id' | 'taskNumber' | 'createdAt' | 'updatedAt'>) => {
    task.health = calculateTaskHealth(task);
    storageService.addTask(task);
    refreshTasks();
  };

  const updateTask = (task: Task) => {
    task.health = calculateTaskHealth(task);
    storageService.updateTask(task);
    refreshTasks();
  };

  const deleteTask = (id: string) => {
    storageService.deleteTask(id);
    refreshTasks();
  };

  const moveTask = (id: string, newStatus: TaskStatus) => {
    const task = tasks.find(t => t.id === id);
    if (task) {
      const updatedTask = { 
        ...task, 
        status: newStatus,
        activities: [
          ...(task.activities || []),
          {
            id: Date.now().toString(),
            date: new Date().toISOString(),
            description: `Moved to ${newStatus}`
          }
        ]
      };
      updatedTask.health = calculateTaskHealth(updatedTask);
      storageService.updateTask(updatedTask);
      refreshTasks();
    }
  };

  const value = useMemo(() => ({
    tasks,
    refreshTasks,
    addTask,
    updateTask,
    deleteTask,
    moveTask
  }), [tasks]);

  return (
    <TaskContext.Provider value={value}>
      {children}
    </TaskContext.Provider>
  );
}

export function useTasks() {
  const context = useContext(TaskContext);
  if (context === undefined) {
    throw new Error('useTasks must be used within a TaskProvider');
  }
  return context;
}
