import React, { createContext, useContext, useState, ReactNode, useMemo } from 'react';

export interface FilterState {
  search: string;
  month: string; // 'August 2026' or 'All'
  ownerIds: string | 'All';
  priority: string | 'All';
  health: string | 'All';
  category: string | 'All';
  status: string | 'All';
}

interface FilterContextType {
  filters: FilterState;
  setFilter: (key: keyof FilterState, value: string) => void;
  resetFilters: () => void;
}

const FilterContext = createContext<FilterContextType | undefined>(undefined);

export function FilterProvider({ children }: { children: ReactNode }) {
  const currentMonthStr = 'August 2026'; // Defaulting to the requested month
  
  const defaultFilters: FilterState = {
    search: '',
    month: currentMonthStr,
    ownerIds: 'All',
    priority: 'All',
    health: 'All',
    category: 'All',
    status: 'All',
  };

  const [filters, setFilters] = useState<FilterState>(defaultFilters);

  const setFilter = (key: keyof FilterState, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const resetFilters = () => {
    setFilters(defaultFilters);
  };

  const value = useMemo(() => ({
    filters,
    setFilter,
    resetFilters
  }), [filters]);

  return (
    <FilterContext.Provider value={value}>
      {children}
    </FilterContext.Provider>
  );
}

export function useTaskFilters() {
  const context = useContext(FilterContext);
  if (context === undefined) {
    throw new Error('useTaskFilters must be used within a FilterProvider');
  }
  return context;
}
