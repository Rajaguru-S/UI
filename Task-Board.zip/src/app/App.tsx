import { BrowserRouter } from 'react-router';
import { AppProviders } from './providers';
import { AppRoutes } from './routes';
import 'bootstrap-icons/font/bootstrap-icons.css';
import '../styles/main.scss';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

export function App() {
  return (
    <AppProviders>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AppProviders>
  );
}
