import { ReactNode } from 'react';
import { AuthProvider } from '../context/AuthContext';
import { TaskProvider } from '../context/TaskContext';
import { FilterProvider } from '../context/FilterContext';
import { SettingsProvider } from '../context/SettingsContext';

export function AppProviders({ children }: { children: ReactNode }) {
  return (
    <AuthProvider>
      <SettingsProvider>
        <TaskProvider>
          <FilterProvider>
            {children}
          </FilterProvider>
        </TaskProvider>
      </SettingsProvider>
    </AuthProvider>
  );
}
