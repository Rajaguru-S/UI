import { Routes, Route, Navigate } from 'react-router';
import { AppLayout } from '../components/layout/AppLayout';
import { ProtectedRoute } from '../components/auth/ProtectedRoute';

import { SignIn } from '../features/auth/components/SignIn';
import { SignOut } from '../features/auth/components/SignOut';
import { Dashboard } from '../features/dashboard/components/Dashboard';
import { Workboard } from '../features/workboard/components/Workboard';
import { DeliveryTracker } from '../features/tracker/components/DeliveryTracker';
import { Settings } from '../features/settings/components/Settings';
import { Profile } from '../features/settings/components/Profile';

export function AppRoutes() {
  return (
    <Routes>
      {/* Public routes */}
      <Route path="/sign-in" element={<SignIn />} />
      <Route path="/sign-out" element={<SignOut />} />

      {/* Protected routes */}
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <AppLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="workboard" element={<Workboard />} />
        <Route path="tracker" element={<DeliveryTracker />} />
        <Route path="settings" element={<Settings />} />
        <Route path="profile" element={<Profile />} />
      </Route>

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

