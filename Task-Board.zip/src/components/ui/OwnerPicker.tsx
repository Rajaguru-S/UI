import React, { useState, useRef, useEffect } from 'react';
import { useSettings } from '../../context/SettingsContext';

// Deterministic vibrant color from owner name
function hashColor(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  const hue = Math.abs(hash) % 360;
  return `hsl(${hue}, 70%, 48%)`;
}

const ALL_OWNERS = ['Raj', 'Kumar', 'Sarah', 'Alex', 'Priya', 'Michael'];

interface OwnerPickerProps {
  value: string[];
  onChange: (owners: string[]) => void;
}

export function OwnerPicker({ value = [], onChange }: OwnerPickerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const { settings } = useSettings();

  // Close dropdown on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const toggleOwner = (owner: string) => {
    if (value.includes(owner)) {
      onChange(value.filter(o => o !== owner));
    } else {
      onChange([...value, owner]);
    }
  };

  const removeOwner = (owner: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onChange(value.filter(o => o !== owner));
  };

  const getColor = (name: string) => hashColor(name);

  return (
    <div className="owner-picker" ref={containerRef}>
      <div
        className={`owner-picker__control ${isOpen ? 'owner-picker__control--focused' : ''}`}
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="owner-picker__chips">
          {value.length === 0 && (
            <span className="owner-picker__placeholder">Select owners…</span>
          )}
          {value.map(owner => (
            <span
              key={owner}
              className="owner-chip"
              style={{ '--chip-color': getColor(owner) } as React.CSSProperties}
            >
              <span className="owner-chip__avatar" style={{ background: getColor(owner) }}>
                {owner.substring(0, 2).toUpperCase()}
              </span>
              <span className="owner-chip__name">{owner}</span>
              <button
                type="button"
                className="owner-chip__remove"
                onClick={(e) => removeOwner(owner, e)}
                aria-label={`Remove ${owner}`}
              >
                <i className="bi bi-x" />
              </button>
            </span>
          ))}
        </div>
        <div className="owner-picker__indicator">
          <i className={`bi bi-chevron-${isOpen ? 'up' : 'down'}`} />
        </div>
      </div>

      {isOpen && (
        <div className="owner-picker__dropdown">
          {(settings?.fieldOptions?.owners || ALL_OWNERS).map(owner => {
            const selected = value.includes(owner);
            return (
              <div
                key={owner}
                className={`owner-option ${selected ? 'owner-option--selected' : ''}`}
                onClick={() => toggleOwner(owner)}
              >
                <span className="owner-option__avatar" style={{ background: getColor(owner) }}>
                  {owner.substring(0, 2).toUpperCase()}
                </span>
                <span className="owner-option__name">{owner}</span>
                <span className="owner-option__check">
                  {selected && <i className="bi bi-check-lg" />}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export { hashColor, ALL_OWNERS };

