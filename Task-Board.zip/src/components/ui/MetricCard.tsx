interface MetricCardProps {
  title: string;
  value: number | string;
  icon: string;
  accentClass?: string; // e.g. 'metric-card--success'
  iconBg: string;       // inline background color
  iconColor: string;    // inline icon color
}

export function MetricCard({ title, value, icon, accentClass = '', iconBg, iconColor }: MetricCardProps) {
  return (
    <div className={`metric-card card-hover ${accentClass}`}>
      <div className="d-flex align-items-start justify-content-between gap-2">
        <div>
          <div className="metric-label">{title}</div>
          <div className="metric-value">{value}</div>
        </div>
        <div
          className="metric-icon flex-shrink-0"
          style={{ background: iconBg }}
        >
          <i className={`bi ${icon}`} style={{ color: iconColor }} />
        </div>
      </div>
    </div>
  );
}
