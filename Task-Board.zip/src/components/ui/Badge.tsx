import React, { ReactNode } from 'react';

type BadgeVariant = 'primary' | 'secondary' | 'success' | 'danger' | 'warning' | 'info' | 'light' | 'dark';

interface BadgeProps {
  children: ReactNode;
  variant?: BadgeVariant;
  className?: string;
  pill?: boolean;
}

export function Badge({ children, variant = 'primary', className = '', pill = false }: BadgeProps) {
  return (
    <span className={`badge bg-${variant} ${pill ? 'rounded-pill' : ''} ${className}`}>
      {children}
    </span>
  );
}
