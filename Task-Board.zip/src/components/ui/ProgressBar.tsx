import React from 'react';

interface ProgressBarProps {
  progress: number;
  variant?: 'primary' | 'success' | 'warning' | 'danger' | 'info';
  height?: string;
  className?: string;
  showLabel?: boolean;
}

export function ProgressBar({ progress, variant = 'primary', height = '8px', className = '', showLabel = false }: ProgressBarProps) {
  const safeProgress = Math.max(0, Math.min(100, progress));
  
  return (
    <div className={`progress-wrapper ${className}`}>
      {showLabel && (
        <div className="d-flex justify-content-between mb-1" style={{ fontSize: '12px' }}>
          <span>Progress</span>
          <span className="fw-medium">{Math.round(safeProgress)}%</span>
        </div>
      )}
      <div className="progress" style={{ height }}>
        <div 
          className={`progress-bar bg-${variant}`} 
          role="progressbar" 
          style={{ width: `${safeProgress}%` }} 
          aria-valuenow={safeProgress} 
          aria-valuemin={0} 
          aria-valuemax={100}
        ></div>
      </div>
    </div>
  );
}
