import { Outlet, NavLink, useNavigate } from 'react-router';
import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';

export function AppLayout() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();
  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  return (
    <div className="app-container d-flex">
      {/* Sidebar */}
      <aside className={`app-sidebar ${isSidebarOpen ? 'show' : ''}`}>
        <div className="sidebar-brand">
          <div className="brand-icon">
            <i className="bi bi-grid-3x3-gap-fill"></i>
          </div>
          <span className="brand-text">Task Board</span>
          <button 
            className="sidebar-close-btn d-md-none ms-auto" 
            onClick={toggleSidebar}
            aria-label="Close navigation"
          >
            <i className="bi bi-x-lg"></i>
          </button>
        </div>

        <div className="sidebar-section-label">Main</div>

        <nav className="sidebar-nav">
          <NavLink to="/dashboard" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
            <i className="bi bi-speedometer2"></i>
            <span>Dashboard</span>
          </NavLink>
          <NavLink to="/workboard" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
            <i className="bi bi-kanban"></i>
            <span>Workboard</span>
          </NavLink>
          <NavLink to="/tracker" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
            <i className="bi bi-table"></i>
            <span>Delivery Tracker</span>
          </NavLink>

          <div className="sidebar-section-label">Manage</div>

          <NavLink to="/settings" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
            <i className="bi bi-gear"></i>
            <span>Settings</span>
          </NavLink>
        </nav>
      </aside>

      {/* Main Content Area */}
      <div className="app-main">
        {/* Header */}
        <header className="app-header">
          <div className="d-flex align-items-center gap-3">
            <button 
              className="btn-icon d-md-none" 
              onClick={toggleSidebar}
              aria-label="Open navigation"
            >
              <i className="bi bi-list fs-5"></i>
            </button>
            <h1 className="header-title d-none d-sm-block">Task Delivery Management</h1>
          </div>

          <div className="header-actions">
          

            <button 
              className="user-menu-btn" 
              type="button" 
              data-bs-toggle="dropdown" 
              aria-expanded="false"
              aria-label="User menu"
            >
              <div className="avatar avatar--sm" style={{ background: '#1e40af' }}>{user?.initials ?? 'U'}</div>
              <span className="d-none d-lg-inline fw-medium" style={{ fontSize: '0.8125rem' }}>
                {user?.name ?? 'User'}
              </span>
              <i className="bi bi-chevron-down" style={{ fontSize: '10px' }}></i>
            </button>
            <ul className="dropdown-menu dropdown-menu-end shadow-lg border-0 mt-1" style={{ minWidth: '180px' }}>
              <li className="px-3 py-2 border-bottom">
                <div className="fw-semibold" style={{ fontSize: '0.8125rem' }}>{user?.name}</div>
                <div className="text-muted" style={{ fontSize: '0.75rem' }}>{user?.email}</div>
              </li>
              <li><button className="dropdown-item py-2 border-0 bg-transparent" onClick={() => navigate('/profile')}><i className="bi bi-person me-2"></i>Profile</button></li>
              <li><button className="dropdown-item py-2 border-0 bg-transparent" onClick={() => navigate('/settings')}><i className="bi bi-gear me-2"></i>Settings</button></li>
              <li><hr className="dropdown-divider" /></li>
              <li>
                <button
                  className="dropdown-item py-2 text-danger w-100 text-start border-0 bg-transparent"
                  onClick={() => navigate('/sign-out')}
                >
                  <i className="bi bi-box-arrow-right me-2"></i>Sign out
                </button>
              </li>
            </ul>
          </div>
        </header>

        {/* Scrollable Content */}
        <main className="app-content">
          <Outlet />
        </main>
      </div>

      {/* Mobile sidebar overlay */}
      {isSidebarOpen && (
        <div 
          className="drawer-backdrop d-md-none" 
          onClick={toggleSidebar} 
          aria-hidden="true"
        ></div>
      )}
    </div>
  );
}
