import { useState } from 'react';
import {
  DndContext,
  DragOverlay,
  closestCorners,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragStartEvent,
  DragEndEvent
} from '@dnd-kit/core';
import { sortableKeyboardCoordinates } from '@dnd-kit/sortable';
import { useTasks } from '../../../context/TaskContext';
import { useTaskFilters } from '../../../context/FilterContext';
import { useSettings } from '../../../context/SettingsContext';
import { Task, TaskStatus } from '../../../types/task';
import { KanbanColumn } from './KanbanColumn';
import { TaskCard } from './TaskCard';
import { TaskDetailsDrawer } from '../../tasks/components/TaskDetailsDrawer';

const STATUSES: TaskStatus[] = [
  'NEW', 'READY FOR WORK', 'DEV IN PROGRESS', 'READY FOR QA',
  'QA IN PROGRESS', 'READY FOR ACCEPTANCE', 'READY FOR UAT',
  'UAT RELEASED', 'READY FOR RELEASE', 'DONE'
];

export function Workboard() {
  const { tasks, moveTask } = useTasks();
  const { settings } = useSettings();
  const { filters, setFilter } = useTaskFilters();
  const [activeTask, setActiveTask] = useState<Task | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isNewDrawerOpen, setIsNewDrawerOpen] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  // Apply filters
  let filteredTasks = tasks;
  if (filters.month !== 'All') filteredTasks = filteredTasks.filter(t => t.month === filters.month);
  if (filters.ownerIds !== 'All') filteredTasks = filteredTasks.filter(t => t.ownerIds?.includes(filters.ownerIds));
  if (filters.priority !== 'All') filteredTasks = filteredTasks.filter(t => t.priority === filters.priority);
  if (filters.health !== 'All') filteredTasks = filteredTasks.filter(t => t.health === filters.health);
  if (filters.category !== 'All') filteredTasks = filteredTasks.filter(t => t.category === filters.category);
  if (filters.search) {
    const s = filters.search.toLowerCase();
    filteredTasks = filteredTasks.filter(t =>
      t.name.toLowerCase().includes(s) ||
      t.taskNumber.toLowerCase().includes(s) ||
      (t.ownerIds || []).some(o => o.toLowerCase().includes(s)) ||
      (t.comments || '').toLowerCase().includes(s)
    );
  }

  const uniqueOwners = [...new Set(tasks.flatMap(t => t.ownerIds || []))].sort();

  const activeFilterCount = [
    filters.ownerIds !== 'All',
    filters.priority !== 'All',
    filters.health !== 'All',
    filters.month !== 'All',
  ].filter(Boolean).length;

  const clearFilters = () => {
    setFilter('search', '');
    setFilter('ownerIds', 'All');
    setFilter('priority', 'All');
    setFilter('health', 'All');
    setFilter('month', 'All');
  };

  const handleTaskClick = (task: Task) => {
    setSelectedTask(task);
    setIsDrawerOpen(true);
  };

  const handleDragStart = (event: DragStartEvent) => {
    const task = filteredTasks.find(t => t.id === event.active.id);
    if (task) setActiveTask(task);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over) { setActiveTask(null); return; }

    const activeId = active.id as string;
    const overId = over.id;

    if (STATUSES.includes(overId as TaskStatus)) {
      moveTask(activeId, overId as TaskStatus);
    } else {
      const overTask = tasks.find(t => t.id === overId);
      if (overTask && overTask.status !== activeTask?.status) {
        moveTask(activeId, overTask.status);
      }
    }
    setActiveTask(null);
  };

  return (
    <div className="workboard-container fade-in">
      {/* Header */}
      <div className="page-header">
        <div className="page-header__text">
          <h1 className="page-header__title">Workboard</h1>
          <p className="page-header__subtitle">Drag tasks across workflow stages</p>
        </div>

        <div className="page-header__controls">
          {/* Search */}
          <div className="filter-search">
            <i className="bi bi-search filter-search__icon" />
            <input
              className="filter-search__input"
              type="text"
              placeholder="Search tasks…"
              value={filters.search}
              onChange={(e) => setFilter('search', e.target.value)}
              aria-label="Search tasks"
            />
          </div>

          <div className="filter-divider" />

          {/* Month */}
          <select
            className="filter-select"
            value={filters.month}
            onChange={(e) => setFilter('month', e.target.value)}
            aria-label="Filter by month"
          >
            <option value="All">All Months</option>
            {settings.fieldOptions.targetMonth.map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>

          {/* Owner */}
          <select
            className="filter-select"
            value={filters.ownerIds}
            onChange={(e) => setFilter('ownerIds', e.target.value)}
            aria-label="Filter by owner"
          >
            <option value="All">All Owners</option>
            {uniqueOwners.map(o => <option key={o} value={o}>{o}</option>)}
          </select>

          {/* Priority */}
          <select
            className="filter-select"
            value={filters.priority}
            onChange={(e) => setFilter('priority', e.target.value)}
            aria-label="Filter by priority"
          >
            <option value="All">All Priorities</option>
            <option value="Critical">Critical</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>

          {/* Health */}
          <select
            className="filter-select"
            value={filters.health}
            onChange={(e) => setFilter('health', e.target.value)}
            aria-label="Filter by health"
          >
            <option value="All">All Health</option>
            <option value="On Track">On Track</option>
            <option value="At Risk">At Risk</option>
            <option value="Blocked">Blocked</option>
            <option value="Completed">Completed</option>
            <option value="Spill Over">Spill Over</option>
          </select>

          {(filters.search || activeFilterCount > 0) && (
            <button className="btn-clear-filters" onClick={clearFilters} aria-label="Clear all filters">
              <i className="bi bi-x-circle" />
              Clear
              {activeFilterCount > 0 && <span className="filter-count">{activeFilterCount}</span>}
            </button>
          )}

          <div className="filter-divider" />

          <button
            className="btn btn-primary d-flex align-items-center gap-2"
            onClick={() => setIsNewDrawerOpen(true)}
            aria-label="Add new task"
          >
            <i className="bi bi-plus-lg" />
            <span>Add Task</span>
          </button>
        </div>
      </div>


      {/* Kanban Board */}
      <div className="kanban-board-wrapper">
        <DndContext
          sensors={sensors}
          collisionDetection={closestCorners}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
        >
          <div className="kanban-board">
            {STATUSES.map(status => (
              <KanbanColumn
                key={status}
                status={status}
                tasks={filteredTasks.filter(t => t.status === status)}
                onTaskClick={handleTaskClick}
              />
            ))}
          </div>

          <DragOverlay>
            {activeTask ? <TaskCard task={activeTask} onClick={() => {}} /> : null}
          </DragOverlay>
        </DndContext>
      </div>

      {/* Task detail drawer */}
      <TaskDetailsDrawer
        isOpen={isDrawerOpen}
        onClose={() => { setIsDrawerOpen(false); setSelectedTask(null); }}
        task={selectedTask}
        isNew={false}
      />

      {/* New task drawer */}
      <TaskDetailsDrawer
        isOpen={isNewDrawerOpen}
        onClose={() => setIsNewDrawerOpen(false)}
        task={null}
        isNew={true}
      />
    </div>
  );
}
