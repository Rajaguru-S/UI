import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Task } from '../../../types/task';
import { hashColor } from '../../../components/ui/OwnerPicker';
import { format } from 'date-fns';

interface TaskCardProps {
  task: Task;
  onClick: (task: Task) => void;
}

const PRIORITY_COLORS: Record<string, string> = {
  Critical: '#dc2626',
  High: '#d97706',
  Medium: '#0891b2',
  Low: '#94a3b8',
};

const HEALTH_MAP: Record<string, { color: string; bg: string }> = {
  'On Track':   { color: '#059669', bg: '#ecfdf5' },
  'At Risk':    { color: '#d97706', bg: '#fffbeb' },
  'Blocked':    { color: '#dc2626', bg: '#fef2f2' },
  'Completed':  { color: '#1e40af', bg: '#eff6ff' },
  'Spill Over': { color: '#64748b', bg: '#f1f5f9' },
};

export function TaskCard({ task, onClick }: TaskCardProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: task.id, data: { type: 'Task', task } });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.45 : 1,
  };

  const healthInfo = HEALTH_MAP[task.health] || HEALTH_MAP['On Track'];
  const priorityColor = PRIORITY_COLORS[task.priority] || PRIORITY_COLORS.Low;

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`task-card ${isDragging ? 'dragging' : ''}`}
      onClick={() => onClick(task)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => { if (e.key === 'Enter') onClick(task); }}
      aria-label={`Task ${task.taskNumber}: ${task.name}`}
    >
      {/* Priority left-border */}
      <div style={{ position: 'absolute', top: 0, left: 0, bottom: 0, width: 4, background: priorityColor }} />

      <div className="task-card-body">
        {/* Header: ID + drag handle */}
        <div className="task-card-header">
          <span className="task-card-id">{task.taskNumber}</span>
          <div
            {...attributes}
            {...listeners}
            className="drag-handle"
            onClick={(e) => e.stopPropagation()}
            aria-label="Drag to reorder"
          >
            <i className="bi bi-grip-vertical"></i>
          </div>
        </div>

        {/* Title */}
        <h3 className="task-card-title">{task.name}</h3>

        {/* Badges row */}
        <div className="task-card-badges">
          <span
            className="custom-badge"
            style={{ background: healthInfo.bg, color: healthInfo.color }}
          >
            <span className="status-dot" style={{ background: healthInfo.color, width: 6, height: 6, borderRadius: '50%' }}></span>
            {task.health}
          </span>
          <span className="custom-badge custom-badge--muted">{task.category}</span>
        </div>

        {/* Footer: owner + date */}
        <div className="task-card-meta">
          <div className="owner-avatar-stack">
            {(task.ownerIds || []).slice(0, 3).map((owner, idx) => (
              <div key={idx} className="stack-avatar" title={owner} style={{ background: hashColor(owner) }}>
                {owner.substring(0, 2).toUpperCase()}
              </div>
            ))}
            {(task.ownerIds?.length || 0) > 3 && (
              <div className="stack-avatar stack-avatar--overflow">
                +{(task.ownerIds?.length || 0) - 3}
              </div>
            )}
            {(task.ownerIds?.length || 0) === 1 && (
              <span className="stack-names">{task.ownerIds![0]}</span>
            )}
          </div>
          {task.targetProdDate && (
            <div className="meta-date" title="Target Production">
              <i className="bi bi-calendar-event"></i>
              {format(new Date(task.targetProdDate), 'dd MMM')}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
