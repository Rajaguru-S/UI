import { useDroppable } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { Task, TaskStatus } from '../../../types/task';
import { TaskCard } from './TaskCard';

interface KanbanColumnProps {
  status: TaskStatus;
  tasks: Task[];
  onTaskClick: (task: Task) => void;
}

export function KanbanColumn({ status, tasks, onTaskClick }: KanbanColumnProps) {
  const { setNodeRef, isOver } = useDroppable({
    id: status,
    data: { type: 'Column', status }
  });

  return (
    <div className="kanban-column" role="region" aria-label={`${status} column, ${tasks.length} tasks`}>
      <div className="kanban-column-header">
        <span className="column-title">{status}</span>
        <span className="column-count">{tasks.length}</span>
      </div>

      <div
        ref={setNodeRef}
        className={`kanban-column-body ${isOver ? 'drag-over' : ''}`}
      >
        <SortableContext items={tasks.map(t => t.id)} strategy={verticalListSortingStrategy}>
          {tasks.map(task => (
            <TaskCard key={task.id} task={task} onClick={onTaskClick} />
          ))}
        </SortableContext>

        {tasks.length === 0 && (
          <div className="empty-state" style={{ padding: '24px 8px' }}>
            <i className="bi bi-inbox" style={{ fontSize: '1.5rem' }}></i>
            <span style={{ fontSize: '0.75rem' }}>No tasks</span>
          </div>
        )}
      </div>
    </div>
  );
}
