import { useNavigate } from 'react-router';
import { useAuth } from '../../../context/AuthContext';
import { useState } from 'react';

export function SignOut() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const handleSignOut = async () => {
    setLoading(true);
    await new Promise((r) => setTimeout(r, 800));
    signOut();
    navigate('/sign-in', { replace: true });
  };

  const handleCancel = () => {
    navigate(-1);
  };

  return (
    <div className="auth-page auth-page--centered">
      <div className="auth-bg-decoration" aria-hidden="true">
        <div className="auth-bg-orb auth-bg-orb--1" />
        <div className="auth-bg-orb auth-bg-orb--2" />
      </div>

      <div className="signout-card">
        <div className="signout-icon-wrapper">
          <div className="signout-icon">
            <i className="bi bi-box-arrow-right" />
          </div>
        </div>

        <h2 className="signout-title">Sign Out</h2>

        {user && (
          <div className="signout-user-info">
            <div
              className="avatar"
              style={{
                background: '#1e40af',
                width: 44,
                height: 44,
                fontSize: '0.9375rem',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#fff',
                fontWeight: 700,
                flexShrink: 0,
              }}
            >
              {user.initials}
            </div>
            <div>
              <div className="signout-user-name">{user.name}</div>
              <div className="signout-user-email">{user.email}</div>
            </div>
          </div>
        )}

        <p className="signout-message">
          Are you sure you want to sign out? You'll be redirected to the sign-in page.
        </p>

        <div className="signout-actions">
          <button
            className="auth-submit-btn auth-submit-btn--danger"
            onClick={handleSignOut}
            disabled={loading}
          >
            {loading ? (
              <>
                <span className="auth-spinner" aria-hidden="true" />
                Signing out…
              </>
            ) : (
              <>
                <i className="bi bi-box-arrow-right" />
                Yes, sign me out
              </>
            )}
          </button>
          <button
            className="signout-cancel-btn"
            onClick={handleCancel}
            disabled={loading}
          >
            <i className="bi bi-arrow-left" />
            Go back
          </button>
        </div>
      </div>
    </div>
  );
}
