import { useState, useId } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../../../context/AuthContext';

export function SignIn() {
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const emailId = useId();
  const passwordId = useId();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    // Simulate async check
    await new Promise((r) => setTimeout(r, 600));
    const ok = signIn(email, password);
    setLoading(false);
    if (ok) {
      navigate('/dashboard', { replace: true });
    } else {
      setError('Invalid email or password. Please try again.');
    }
  };

  const fillDemo = (e: React.MouseEvent, demoEmail: string, demoPass: string) => {
    e.preventDefault();
    setEmail(demoEmail);
    setPassword(demoPass);
    setError('');
  };

  return (
    <div className="auth-page">
      {/* Background decoration */}
      <div className="auth-bg-decoration" aria-hidden="true">
        <div className="auth-bg-orb auth-bg-orb--1" />
        <div className="auth-bg-orb auth-bg-orb--2" />
        <div className="auth-bg-orb auth-bg-orb--3" />
      </div>

      <div className="auth-layout">
        {/* Left branding panel */}
        <div className="auth-branding">
          <div className="auth-brand-content">
            <div className="auth-logo">
              <i className="bi bi-grid-3x3-gap-fill" />
            </div>
            <h1 className="auth-brand-title">Task Delivery<br />Management</h1>
            <p className="auth-brand-subtitle">
              Enterprise-grade project tracking for delivery teams. Streamline sprints, milestones, and workboard management in one place.
            </p>
            <ul className="auth-feature-list">
              <li><i className="bi bi-check-circle-fill" /> Real-time Kanban Workboard</li>
              <li><i className="bi bi-check-circle-fill" /> Delivery Health Analytics</li>
              <li><i className="bi bi-check-circle-fill" /> Multi-owner Task Management</li>
              <li><i className="bi bi-check-circle-fill" /> Export &amp; Import Capabilities</li>
            </ul>
          </div>
        </div>

        {/* Right sign-in panel */}
        <div className="auth-form-panel">
          <div className="auth-form-card">
            <div className="auth-form-header">
              <h2 className="auth-form-title">Welcome back</h2>
              <p className="auth-form-subtitle">Sign in to your workspace to continue</p>
            </div>

            {error && (
              <div className="auth-error" role="alert">
                <i className="bi bi-exclamation-circle-fill" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} noValidate>
              <div className="auth-field">
                <label htmlFor={emailId} className="auth-label">Email address</label>
                <div className="auth-input-wrapper">
                  <i className="bi bi-envelope auth-input-icon" />
                  <input
                    id={emailId}
                    type="email"
                    className="auth-input"
                    placeholder="you@enterprise.com"
                    value={email}
                    onChange={(e) => { setEmail(e.target.value); setError(''); }}
                    autoComplete="email"
                    required
                    disabled={loading}
                  />
                </div>
              </div>

              <div className="auth-field">
                <div className="auth-label-row">
                  <label htmlFor={passwordId} className="auth-label">Password</label>
                </div>
                <div className="auth-input-wrapper">
                  <i className="bi bi-lock auth-input-icon" />
                  <input
                    id={passwordId}
                    type={showPassword ? 'text' : 'password'}
                    className="auth-input auth-input--has-right"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => { setPassword(e.target.value); setError(''); }}
                    autoComplete="current-password"
                    required
                    disabled={loading}
                  />
                  <button
                    type="button"
                    className="auth-input-toggle"
                    onClick={() => setShowPassword((v) => !v)}
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    tabIndex={-1}
                  >
                    <i className={`bi ${showPassword ? 'bi-eye-slash' : 'bi-eye'}`} />
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className={`auth-submit-btn ${loading ? 'loading' : ''}`}
                disabled={loading || !email || !password}
              >
                {loading ? (
                  <>
                    <span className="auth-spinner" aria-hidden="true" />
                    Signing in…
                  </>
                ) : (
                  <>
                    <i className="bi bi-box-arrow-in-right" />
                    Sign In
                  </>
                )}
              </button>
            </form>

          </div>
        </div>
      </div>
    </div>
  );
}
