import React, { useState } from 'react';
import { useSettings } from '../../../context/SettingsContext';
import { FieldOptions } from '../../../types/settings';

const FIELD_LABELS: Record<keyof FieldOptions, string> = {
  enablement: 'Enablement',
  category: 'Category',
  workType: 'Work Type',
  priority: 'Priority',
  environment: 'Environment',
  targetMonth: 'Target Month',
  owners: 'Owners',
};

const FIELD_ICONS: Record<keyof FieldOptions, string> = {
  enablement: 'bi-toggles',
  category: 'bi-tag-fill',
  workType: 'bi-briefcase-fill',
  priority: 'bi-flag-fill',
  environment: 'bi-server',
  targetMonth: 'bi-calendar3',
  owners: 'bi-people-fill',
};

const FIELD_COLORS: Record<keyof FieldOptions, string> = {
  enablement: '#6366f1',
  category: '#0891b2',
  workType: '#f59e0b',
  priority: '#ef4444',
  environment: '#10b981',
  targetMonth: '#8b5cf6',
  owners: '#ec4899',
};

export function FieldConfigurator() {
  const { settings, updateFieldOptions } = useSettings();
  const [activeField, setActiveField] = useState<keyof FieldOptions>('enablement');
  const [newValue, setNewValue] = useState('');
  const [removingOption, setRemovingOption] = useState<string | null>(null);

  const currentOptions = settings.fieldOptions[activeField] ?? [];

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newValue.trim();
    if (!trimmed) return;
    if (currentOptions.includes(trimmed)) {
      setNewValue('');
      return;
    }
    updateFieldOptions(activeField, [...currentOptions, trimmed]);
    setNewValue('');
  };

  const handleRemove = (optionToRemove: string) => {
    setRemovingOption(optionToRemove);
    setTimeout(() => {
      updateFieldOptions(activeField, currentOptions.filter(opt => opt !== optionToRemove));
      setRemovingOption(null);
    }, 200);
  };

  const activeColor = FIELD_COLORS[activeField];

  return (
    <div className="settings-card settings-card--field-config">
      <div className="settings-card__header">
        <span className="settings-card__header-icon settings-card__header-icon--purple">
          <i className="bi bi-sliders2" />
        </span>
        <div>
          <h2 className="settings-card__title">Field Configuration</h2>
          <p className="settings-card__desc">Customize dropdown options for the task form.</p>
        </div>
      </div>

      <div className="settings-card__body">
        <div className="field-config-layout">
          {/* Sidebar field list */}
          <nav className="field-config-nav">
            {(Object.keys(FIELD_LABELS) as Array<keyof FieldOptions>).map(field => (
              <button
                key={field}
                className={`field-nav-item ${activeField === field ? 'field-nav-item--active' : ''}`}
                style={activeField === field ? { '--field-color': FIELD_COLORS[field] } as React.CSSProperties : {}}
                onClick={() => setActiveField(field)}
                id={`field-nav-${field}`}
              >
                <i className={`bi ${FIELD_ICONS[field]} field-nav-item__icon`} />
                <span>{FIELD_LABELS[field]}</span>
                <span className="field-nav-item__count">
                  {(settings.fieldOptions[field] ?? []).length}
                </span>
              </button>
            ))}
          </nav>

          {/* Option manager panel */}
          <div className="field-config-panel">
            <div className="field-config-panel__header" style={{ '--field-color': activeColor } as React.CSSProperties}>
              <i className={`bi ${FIELD_ICONS[activeField]}`} />
              <span>{FIELD_LABELS[activeField]}</span>
              <span className="field-config-panel__count">{currentOptions.length} options</span>
            </div>

            <form onSubmit={handleAdd} className="field-config-add-form">
              <div className="field-config-add-form__input-wrap">
                <i className="bi bi-plus-circle field-config-add-form__icon" />
                <input
                  type="text"
                  className="field-config-add-form__input"
                  placeholder={`Add to ${FIELD_LABELS[activeField]}…`}
                  value={newValue}
                  onChange={(e) => setNewValue(e.target.value)}
                  id={`add-option-input-${activeField}`}
                />
              </div>
              <button
                type="submit"
                className="settings-btn settings-btn--primary"
                disabled={!newValue.trim()}
                id={`add-option-btn-${activeField}`}
              >
                <i className="bi bi-plus-lg" /> Add
              </button>
            </form>

            <div className="field-config-options">
              {currentOptions.length === 0 ? (
                <div className="field-config-empty">
                  <i className="bi bi-inbox field-config-empty__icon" />
                  <p>No options yet. Add one above.</p>
                </div>
              ) : (
                currentOptions.map((option, idx) => (
                  <div
                    key={option}
                    className={`field-option-item ${removingOption === option ? 'field-option-item--removing' : ''}`}
                    style={{ animationDelay: `${idx * 30}ms` } as React.CSSProperties}
                  >
                    <span
                      className="field-option-item__dot"
                      style={{ background: activeColor }}
                    />
                    <span className="field-option-item__label">{option}</span>
                    <button
                      className="field-option-item__remove"
                      onClick={() => handleRemove(option)}
                      title={`Remove "${option}"`}
                      id={`remove-option-${activeField}-${option}`}
                    >
                      <i className="bi bi-x-lg" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
