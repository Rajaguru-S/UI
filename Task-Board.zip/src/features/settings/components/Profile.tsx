import { useState } from 'react';
import { useAuth } from '../../../context/AuthContext';
import { Card } from '../../../components/ui/Card';

export function Profile() {
  const { user, updateProfile } = useAuth();
  
  const [name, setName] = useState(user?.name || '');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg('');
    setErrorMsg('');

    if (!name.trim()) {
      setErrorMsg('Name cannot be empty.');
      return;
    }

    if (password && password !== confirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }

    updateProfile(name, password || undefined);
    
    setSuccessMsg('Profile updated successfully.');
    setPassword('');
    setConfirmPassword('');
    
    // Auto-hide success message after 3 seconds
    setTimeout(() => {
      setSuccessMsg('');
    }, 3000);
  };

  return (
    <div className="profile-page fade-in">
      <div className="page-header">
        <div className="page-header__text">
          <h1 className="page-header__title">
            <i className="bi bi-person-circle" />
            My Profile
          </h1>
          <p className="page-header__subtitle">Manage your personal information and password.</p>
        </div>
      </div>

      <div className="profile-content">
        <Card title="Profile Details" icon="bi-person-vcard" variant="primary">
          <form onSubmit={handleSubmit} className="profile-form">
            
            {successMsg && (
              <div className="alert alert-success d-flex align-items-center" role="alert">
                <i className="bi bi-check-circle-fill me-2"></i>
                <div>{successMsg}</div>
              </div>
            )}
            
            {errorMsg && (
              <div className="alert alert-danger d-flex align-items-center" role="alert">
                <i className="bi bi-exclamation-triangle-fill me-2"></i>
                <div>{errorMsg}</div>
              </div>
            )}

            <div className="form-group mb-4">
              <label className="form-label fw-semibold text-secondary small text-uppercase">Email Address</label>
              <input 
                type="email" 
                className="form-control bg-light" 
                value={user?.email || ''} 
                disabled 
                readOnly 
              />
              <div className="form-text text-muted mt-1" style={{ fontSize: '12px' }}>
                Email cannot be changed.
              </div>
            </div>

            <div className="form-group mb-4">
              <label className="form-label fw-semibold text-secondary small text-uppercase">Full Name</label>
              <input 
                type="text" 
                className="form-control" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Jane Doe"
                required
              />
            </div>

            <hr className="my-4" />
            <h6 className="mb-3 fw-bold">Change Password</h6>
            <p className="text-muted small mb-4">Leave blank if you don't want to change your password.</p>

            <div className="form-group mb-4">
              <label className="form-label fw-semibold text-secondary small text-uppercase">New Password</label>
              <input 
                type="password" 
                className="form-control" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter new password"
              />
            </div>

            <div className="form-group mb-4">
              <label className="form-label fw-semibold text-secondary small text-uppercase">Confirm New Password</label>
              <input 
                type="password" 
                className="form-control" 
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm new password"
              />
            </div>

            <div className="d-flex justify-content-end mt-2">
              <button type="submit" className="btn btn-primary d-flex align-items-center gap-2 px-4">
                <i className="bi bi-save" /> Save Changes
              </button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}
