import React, { useRef, useState } from 'react';
import { storageService } from '../../../services/storageService';
import { useTasks } from '../../../context/TaskContext';
import { FieldConfigurator } from './FieldConfigurator';

export function Settings() {
  const { refreshTasks } = useTasks();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<'success' | 'error'>('success');

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleExport = () => {
    const data = storageService.exportData();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `workboard-export-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Data exported successfully!', 'success');
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = storageService.importData(content);
      if (success) {
        refreshTasks();
        showToast('Data imported successfully!', 'success');
      } else {
        showToast('Failed to import. Invalid file format.', 'error');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleReset = () => {
    if (window.confirm('Are you sure you want to clear all data? This cannot be undone.')) {
      storageService.clearData();
      refreshTasks();
      showToast('All data has been cleared.', 'success');
    }
  };

  return (
    <div className="settings-page fade-in">
      {/* Page Header */}
      <div className="page-header">
        <div className="page-header__text">
          <h1 className="page-header__title">
            <i className="bi bi-gear-fill" />
            Settings
          </h1>
          <p className="page-header__subtitle">Manage your application preferences, field options, and data.</p>
        </div>
      </div>

      <div className="settings-grid">
        {/* Data Management Card */}
        <div className="settings-card">
          <div className="settings-card__header">
            <span className="settings-card__header-icon settings-card__header-icon--blue">
              <i className="bi bi-database-fill" />
            </span>
            <div>
              <h2 className="settings-card__title">Data Management</h2>
              <p className="settings-card__desc">Export, import, or reset your workspace data.</p>
            </div>
          </div>

          <div className="settings-card__body">
            {/* Export */}
            <div className="settings-action-row">
              <div className="settings-action-row__icon settings-action-row__icon--blue">
                <i className="bi bi-cloud-download-fill" />
              </div>
              <div className="settings-action-row__info">
                <span className="settings-action-row__title">Export Data</span>
                <span className="settings-action-row__desc">Download a full JSON backup of all tasks and settings.</span>
              </div>
              <button className="settings-btn settings-btn--primary" onClick={handleExport} id="export-btn">
                <i className="bi bi-download" /> Export
              </button>
            </div>

            {/* Import */}
            <div className="settings-action-row">
              <div className="settings-action-row__icon settings-action-row__icon--green">
                <i className="bi bi-cloud-upload-fill" />
              </div>
              <div className="settings-action-row__info">
                <span className="settings-action-row__title">Import Data</span>
                <span className="settings-action-row__desc">Restore your data from a previously exported JSON file.</span>
              </div>
              <input type="file" accept=".json" className="d-none" ref={fileInputRef} onChange={handleImport} />
              <button className="settings-btn settings-btn--primary" onClick={() => fileInputRef.current?.click()} id="import-btn">
                <i className="bi bi-upload" /> Import
              </button>
            </div>

            {/* Reset */}
            <div className="settings-action-row settings-action-row--danger">
              <div className="settings-action-row__icon settings-action-row__icon--red">
                <i className="bi bi-exclamation-triangle-fill" />
              </div>
              <div className="settings-action-row__info">
                <span className="settings-action-row__title settings-action-row__title--danger">Reset All Data</span>
                <span className="settings-action-row__desc">Permanently delete all tasks. This action cannot be undone.</span>
              </div>
              <button className="settings-btn settings-btn--danger" onClick={handleReset} id="reset-btn">
                <i className="bi bi-trash3-fill" /> Reset
              </button>
            </div>
          </div>
        </div>

        {/* Field Configurator */}
        <FieldConfigurator />
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className={`settings-toast settings-toast--${toastType}`} role="alert">
          <i className={`bi ${toastType === 'success' ? 'bi-check-circle-fill' : 'bi-x-circle-fill'}`} />
          <span>{toastMessage}</span>
          <button className="settings-toast__close" onClick={() => setToastMessage(null)} aria-label="Close">
            <i className="bi bi-x" />
          </button>
        </div>
      )}
    </div>
  );
}
