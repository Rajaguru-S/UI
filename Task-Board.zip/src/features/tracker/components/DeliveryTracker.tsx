import { useTasks } from '../../../context/TaskContext';
import { useTaskFilters } from '../../../context/FilterContext';
import { useSettings } from '../../../context/SettingsContext';
import { hashColor } from '../../../components/ui/OwnerPicker';
import { format } from 'date-fns';
import * as XLSX from 'xlsx';

export function DeliveryTracker() {
  const { tasks } = useTasks();
  const { settings } = useSettings();
  const { filters, setFilter } = useTaskFilters();

  // Apply filters
  let filteredTasks = tasks;
  if (filters.month !== 'All') filteredTasks = filteredTasks.filter(t => t.month === filters.month);
  if (filters.ownerIds !== 'All') filteredTasks = filteredTasks.filter(t => t.ownerIds?.includes(filters.ownerIds));
  if (filters.priority !== 'All') filteredTasks = filteredTasks.filter(t => t.priority === filters.priority);
  if (filters.health !== 'All') filteredTasks = filteredTasks.filter(t => t.health === filters.health);
  if (filters.category !== 'All') filteredTasks = filteredTasks.filter(t => t.category === filters.category);
  if (filters.search) {
    const s = filters.search.toLowerCase();
    filteredTasks = filteredTasks.filter(t =>
      t.name.toLowerCase().includes(s) ||
      t.taskNumber.toLowerCase().includes(s) ||
      (t.ownerIds || []).some(o => o.toLowerCase().includes(s)) ||
      (t.comments || '').toLowerCase().includes(s)
    );
  }

  const uniqueOwners = [...new Set(tasks.flatMap(t => t.ownerIds || []))].sort();

  const activeFilterCount = [
    filters.ownerIds !== 'All',
    filters.priority !== 'All',
    filters.health !== 'All',
    filters.month !== 'All',
  ].filter(Boolean).length;

  const clearFilters = () => {
    setFilter('search', '');
    setFilter('ownerIds', 'All');
    setFilter('priority', 'All');
    setFilter('health', 'All');
    setFilter('month', 'All');
  };

  const exportToExcel = () => {
    const data = filteredTasks.map(t => ({
      'Task ID': t.taskNumber,
      'Enablement': t.enablement && t.enablement !== 'None' ? t.enablement : '',
      'Task Name': t.name,
      'Owners': (t.ownerIds || []).join(', '),
      'Status': t.status,
      'Health': t.health,
      'Priority': t.priority,
      'Category': t.category,
      'Month': t.month,
      'Target Prod': t.targetProdDate ? format(new Date(t.targetProdDate), 'dd-MMM-yyyy') : '',
      'Completion Date': t.completionDate ? format(new Date(t.completionDate), 'dd-MMM-yyyy') : '',
      'Notes': t.comments
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Delivery Tracker');
    
    // Auto-size columns slightly
    const wscols = [
      { wch: 12 }, // ID
      { wch: 15 }, // Enablement
      { wch: 40 }, // Name
      { wch: 15 }, // Owner
      { wch: 20 }, // Status
      { wch: 15 }, // Health
      { wch: 12 }, // Priority
      { wch: 15 }, // Category
      { wch: 15 }, // Month
      { wch: 15 }, // Target Prod
      { wch: 15 }, // Completion
      { wch: 50 }, // Notes
    ];
    worksheet['!cols'] = wscols;

    XLSX.writeFile(workbook, `Delivery_Tracker_${format(new Date(), 'yyyyMMdd_HHmm')}.xlsx`);
  };

  const healthBadgeVariant = (health: string) => {
    switch (health) {
      case 'On Track': return 'success';
      case 'At Risk': return 'warning';
      case 'Blocked': return 'danger';
      case 'Completed': return 'success';
      case 'Spill Over': return 'info';
      default: return 'muted';
    }
  };

  return (
    <div className="tracker-page fade-in">
      {/* Header & Filters */}
      <div className="page-header">
        <div className="page-header__text">
          <h1 className="page-header__title">
            <i className="bi bi-table" />
            Delivery Tracker
          </h1>
          <p className="page-header__subtitle">Tabular view of all delivery items</p>
        </div>

        <div className="page-header__controls">
          <div className="filter-search">
            <i className="bi bi-search filter-search__icon" />
            <input
              className="filter-search__input"
              type="text"
              placeholder="Search tasks…"
              value={filters.search}
              onChange={(e) => setFilter('search', e.target.value)}
              aria-label="Search tasks"
            />
          </div>

          <div className="filter-divider" />

          <select 
            className="filter-select" 
            value={filters.month} 
            onChange={(e) => setFilter('month', e.target.value)}
            aria-label="Filter by month"
          >
            <option value="All">All Months</option>
            {settings.fieldOptions.targetMonth.map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>

          <select className="filter-select" value={filters.ownerIds} onChange={(e) => setFilter('ownerIds', e.target.value)}>
            <option value="All">All Owners</option>
            {uniqueOwners.map(o => <option key={o} value={o}>{o}</option>)}
          </select>

          <select className="filter-select" value={filters.priority} onChange={(e) => setFilter('priority', e.target.value)}>
            <option value="All">All Priorities</option>
            <option value="Critical">Critical</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>

          <select className="filter-select" value={filters.health} onChange={(e) => setFilter('health', e.target.value)}>
            <option value="All">All Health</option>
            <option value="On Track">On Track</option>
            <option value="At Risk">At Risk</option>
            <option value="Blocked">Blocked</option>
            <option value="Completed">Completed</option>
            <option value="Spill Over">Spill Over</option>
          </select>

          {(filters.search || activeFilterCount > 0) && (
            <button className="btn-clear-filters" onClick={clearFilters}>
              <i className="bi bi-x-circle" />
              Clear
              {activeFilterCount > 0 && <span className="filter-count">{activeFilterCount}</span>}
            </button>
          )}

          <div className="filter-divider" />

          <button className="btn-export-excel" onClick={exportToExcel}>
            <i className="bi bi-file-earmark-excel-fill" />
            <span>Export Excel</span>
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="tracker-table-card">
        <div className="tracker-table-scroll">
          <table className="tracker-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Enablement</th>
                <th>Task Name</th>
                <th>Owner</th>
                <th>Status</th>
                <th>Health</th>
                <th>Priority</th>
                <th>Target Prod</th>
              </tr>
            </thead>
            <tbody>
              {filteredTasks.length > 0 ? (
                filteredTasks.map(task => (
                  <tr key={task.id}>
                    <td className="cell-id">{task.taskNumber}</td>
                    <td>
                      <span className="badge bg-secondary opacity-75">
                        {task.enablement && task.enablement !== 'None' ? task.enablement : 'APC'}
                      </span>
                    </td>

                    <td className="cell-name" title={task.name}>{task.name}</td>
                    <td>
                      <div className="owner-avatar-stack">
                        {(task.ownerIds || []).slice(0, 3).map((owner, idx) => (
                          <div key={idx} className="stack-avatar" title={owner} style={{ background: hashColor(owner) }}>
                            {owner.substring(0, 2).toUpperCase()}
                          </div>
                        ))}
                        {(task.ownerIds?.length || 0) > 3 && (
                          <div className="stack-avatar stack-avatar--overflow">
                            +{(task.ownerIds?.length || 0) - 3}
                          </div>
                        )}
                        {(task.ownerIds?.length || 0) <= 2 && (
                          <span className="stack-names">{(task.ownerIds || []).join(', ')}</span>
                        )}
                      </div>
                    </td>
                    <td>
                      <span className="custom-badge custom-badge--muted">{task.status}</span>
                    </td>
                    <td>
                      <span className={`custom-badge custom-badge--${healthBadgeVariant(task.health)}`}>
                        {task.health}
                      </span>
                    </td>
                    <td>
                      <div className="cell-priority">
                        <span className={`priority-dot priority-dot--${task.priority.toLowerCase()}`} />
                        <span className="priority-label">{task.priority}</span>
                      </div>
                    </td>
                    <td className="cell-date">
                      <i className="bi bi-calendar3" />
                      {task.targetProdDate ? format(new Date(task.targetProdDate), 'dd MMM yyyy') : '—'}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7}>
                    <div className="tracker-empty">
                      <div className="empty-icon">
                        <i className="bi bi-inbox" />
                      </div>
                      <div className="empty-title">No tasks found</div>
                      <div className="empty-desc">Try adjusting your filters or search query</div>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="tracker-footer">
          <span className="footer-count">
            Showing <strong>{filteredTasks.length}</strong> of <strong>{tasks.length}</strong> items
          </span>
        </div>
      </div>
    </div>
  );
}
