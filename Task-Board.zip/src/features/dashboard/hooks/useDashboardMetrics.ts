import { useTasks } from '../../../context/TaskContext';
import { useTaskFilters } from '../../../context/FilterContext';
import { useMemo } from 'react';
import { Task } from '../../../types/task';

export interface DashboardMetrics {
  total: number;
  onTrack: number;
  yts: number;
  atRisk: number;
  blocked: number;
  completed: number;
  spillOver: number;
  userShadowing: number;
  stageDistribution: Record<string, number>;
  ownerDistribution: Record<string, number>;
  deliveryHealth: {
    completed: number;
    inProgress: number;
    atRisk: number;
    blocked: number;
    spillOver: number;
  };
}

export function useDashboardMetrics() {
  const { tasks } = useTasks();
  const { filters } = useTaskFilters();

  return useMemo(() => {
    let filteredTasks = tasks;
    
    // Filter by month if not 'All'
    if (filters.month !== 'All') {
      filteredTasks = filteredTasks.filter(t => t.month === filters.month);
    }

    const metrics: DashboardMetrics = {
      total: filteredTasks.length,
      onTrack: 0,
      yts: 0,
      atRisk: 0,
      blocked: 0,
      completed: 0,
      spillOver: 0,
      userShadowing: 0,
      stageDistribution: {},
      ownerDistribution: {},
      deliveryHealth: {
        completed: 0,
        inProgress: 0,
        atRisk: 0,
        blocked: 0,
        spillOver: 0,
      }
    };

    filteredTasks.forEach(task => {
      // Stage
      metrics.stageDistribution[task.status] = (metrics.stageDistribution[task.status] || 0) + 1;
      
      // Owners
      (task.ownerIds || []).forEach(ownerId => {
        metrics.ownerDistribution[ownerId] = (metrics.ownerDistribution[ownerId] || 0) + 1;
      });

      // User Shadowing (example heuristic: category Support or contains 'shadowing')
      if (task.category === 'Support' || task.name.toLowerCase().includes('shadow')) {
        metrics.userShadowing++;
      }

      if (task.status === 'NEW' || task.status === 'READY FOR WORK') {
        metrics.yts++;
      }

      if (task.health === 'Completed') {
        metrics.completed++;
        metrics.deliveryHealth.completed++;
      } else if (task.health === 'On Track') {
        metrics.onTrack++;
        metrics.deliveryHealth.inProgress++;
      } else if (task.health === 'At Risk') {
        metrics.atRisk++;
        metrics.deliveryHealth.atRisk++;
      } else if (task.health === 'Blocked') {
        metrics.blocked++;
        metrics.deliveryHealth.blocked++;
      } else if (task.health === 'Spill Over') {
        metrics.spillOver++;
        metrics.deliveryHealth.spillOver++;
      }
    });

    return metrics;
  }, [tasks, filters.month]);
}
