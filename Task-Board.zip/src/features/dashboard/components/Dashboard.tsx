import { useState } from 'react';
import { useDashboardMetrics } from '../hooks/useDashboardMetrics';
import { MetricCard } from '../../../components/ui/MetricCard';
import { Card } from '../../../components/ui/Card';
import { useTaskFilters } from '../../../context/FilterContext';
import { useTasks } from '../../../context/TaskContext';
import { useSettings } from '../../../context/SettingsContext';
import { TaskDetailsDrawer } from '../../tasks/components/TaskDetailsDrawer';
import { hashColor } from '../../../components/ui/OwnerPicker';
import { Task } from '../../../types/task';
import { format } from 'date-fns';

export function Dashboard() {
  const metrics = useDashboardMetrics();
  const { tasks } = useTasks();
  const { settings } = useSettings();
  const { filters, setFilter } = useTaskFilters();
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  const handleMonthChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFilter('month', e.target.value);
  };

  const deliveryHealthTotal =
    metrics.deliveryHealth.completed +
    metrics.deliveryHealth.inProgress +
    metrics.deliveryHealth.atRisk +
    metrics.deliveryHealth.blocked +
    metrics.deliveryHealth.spillOver;

  const pct = (val: number) =>
    deliveryHealthTotal === 0 ? 0 : Math.max(0, (val / deliveryHealthTotal) * 100);

  // Upcoming milestones: tasks with targetProdDate, not done, sorted by date
  const upcomingTasks = tasks
    .filter(t => t.targetProdDate && t.status !== 'DONE' && (filters.month === 'All' || t.month === filters.month))
    .sort((a, b) => new Date(a.targetProdDate!).getTime() - new Date(b.targetProdDate!).getTime())
    .slice(0, 8);

  const handleTaskClick = (task: Task) => {
    setSelectedTask(task);
    setIsDrawerOpen(true);
  };

  const stageEntries = Object.entries(metrics.stageDistribution).sort((a, b) => b[1] - a[1]);
  const ownerEntries = Object.entries(metrics.ownerDistribution).sort((a, b) => b[1] - a[1]);
  const maxOwner = ownerEntries[0]?.[1] ?? 1;

  return (
    <>
      <div className="dashboard-container fade-in">
        {/* Header */}
        <div className="page-header">
          <div className="page-header__text">
            <h1 className="page-header__title">Monthly Delivery Plan</h1>
            <p className="page-header__subtitle">Executive view of delivery health and progress</p>
          </div>
          <div className="page-header__controls">
            <select
              className="filter-select"
              value={filters.month}
              onChange={handleMonthChange}
              aria-label="Select month"
            >
              <option value="All">All Time</option>
              {settings.fieldOptions.targetMonth.map(m => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
            <button
              className="btn btn-primary d-flex align-items-center gap-2"
              onClick={() => { setSelectedTask(null); setIsDrawerOpen(true); }}
            >
              <i className="bi bi-plus-lg" />
              <span>Add Task</span>
            </button>
          </div>
        </div>


        {/* KPI Metrics */}
        <div className="metrics-grid">
          <MetricCard
            title="Total Tasks"
            value={metrics.total}
            icon="bi-list-task"
            iconBg="#eff6ff"
            iconColor="#1e40af"
          />
          <MetricCard
            title="On Track"
            value={metrics.onTrack}
            icon="bi-check-circle-fill"
            accentClass="metric-card--success"
            iconBg="#ecfdf5"
            iconColor="#059669"
          />
          <MetricCard
            title="YTS / Pending"
            value={metrics.yts}
            icon="bi-hourglass-split"
            accentClass="metric-card--warning"
            iconBg="#fffbeb"
            iconColor="#d97706"
          />
          <MetricCard
            title="At Risk / Blocked"
            value={metrics.atRisk + metrics.blocked}
            icon="bi-exclamation-triangle-fill"
            accentClass="metric-card--danger"
            iconBg="#fef2f2"
            iconColor="#dc2626"
          />
          <MetricCard
            title="Completed"
            value={metrics.completed}
            icon="bi-patch-check-fill"
            iconBg="#eff6ff"
            iconColor="#1e40af"
          />
          <MetricCard
            title="Spill Over"
            value={metrics.spillOver}
            icon="bi-arrow-repeat"
            accentClass="metric-card--muted"
            iconBg="#f1f5f9"
            iconColor="#64748b"
          />
        </div>

        {/* Delivery Health Bar */}
        <Card className="mb-4">
          <h3 className="section-title">
            <i className="bi bi-heart-pulse" />
            Delivery Health
          </h3>
          <div className="delivery-health-bar">
            <div className="health-progress-track">
              {metrics.deliveryHealth.completed > 0 && (
                <div
                  className="health-segment"
                  style={{ width: `${pct(metrics.deliveryHealth.completed)}%`, background: '#059669' }}
                  title={`Completed: ${metrics.deliveryHealth.completed}`}
                >
                  {pct(metrics.deliveryHealth.completed) >= 5 && `${Math.round(pct(metrics.deliveryHealth.completed))}%`}
                </div>
              )}
              {metrics.deliveryHealth.inProgress > 0 && (
                <div
                  className="health-segment"
                  style={{ width: `${pct(metrics.deliveryHealth.inProgress)}%`, background: '#1e40af' }}
                  title={`On Track: ${metrics.deliveryHealth.inProgress}`}
                >
                  {pct(metrics.deliveryHealth.inProgress) >= 5 && `${Math.round(pct(metrics.deliveryHealth.inProgress))}%`}
                </div>
              )}
              {metrics.deliveryHealth.atRisk > 0 && (
                <div
                  className="health-segment"
                  style={{ width: `${pct(metrics.deliveryHealth.atRisk)}%`, background: '#d97706' }}
                  title={`At Risk: ${metrics.deliveryHealth.atRisk}`}
                >
                  {pct(metrics.deliveryHealth.atRisk) >= 5 && `${Math.round(pct(metrics.deliveryHealth.atRisk))}%`}
                </div>
              )}
              {metrics.deliveryHealth.blocked > 0 && (
                <div
                  className="health-segment"
                  style={{ width: `${pct(metrics.deliveryHealth.blocked)}%`, background: '#dc2626' }}
                  title={`Blocked: ${metrics.deliveryHealth.blocked}`}
                >
                  {pct(metrics.deliveryHealth.blocked) >= 5 && `${Math.round(pct(metrics.deliveryHealth.blocked))}%`}
                </div>
              )}
              {metrics.deliveryHealth.spillOver > 0 && (
                <div
                  className="health-segment"
                  style={{ width: `${pct(metrics.deliveryHealth.spillOver)}%`, background: '#94a3b8' }}
                  title={`Spill Over: ${metrics.deliveryHealth.spillOver}`}
                >
                  {pct(metrics.deliveryHealth.spillOver) >= 5 && `${Math.round(pct(metrics.deliveryHealth.spillOver))}%`}
                </div>
              )}
            </div>
            <div className="health-legend">
              <span className="legend-item"><span className="legend-dot" style={{ background: '#059669' }} /> Completed ({metrics.deliveryHealth.completed})</span>
              <span className="legend-item"><span className="legend-dot" style={{ background: '#1e40af' }} /> On Track ({metrics.deliveryHealth.inProgress})</span>
              <span className="legend-item"><span className="legend-dot" style={{ background: '#d97706' }} /> At Risk ({metrics.deliveryHealth.atRisk})</span>
              <span className="legend-item"><span className="legend-dot" style={{ background: '#dc2626' }} /> Blocked ({metrics.deliveryHealth.blocked})</span>
              <span className="legend-item"><span className="legend-dot" style={{ background: '#94a3b8' }} /> Spill Over ({metrics.deliveryHealth.spillOver})</span>
            </div>
          </div>
        </Card>

        {/* Charts Grid */}
        <div className="charts-grid">
          {/* Stage Distribution */}
          <Card>
            <h3 className="section-title">
              <i className="bi bi-bar-chart" />
              Stage Distribution
            </h3>
            {stageEntries.length > 0 ? (
              stageEntries.map(([stage, count]) => (
                <div className="distribution-bar" key={stage}>
                  <div className="distribution-label">
                    <span className="dist-name">{stage}</span>
                    <span className="dist-count">{count}</span>
                  </div>
                  <div className="dist-track">
                    <div
                      className="dist-fill"
                      style={{ width: `${(count / (metrics.total || 1)) * 100}%` }}
                    />
                  </div>
                </div>
              ))
            ) : (
              <div className="empty-state"><i className="bi bi-inbox" /><span>No data</span></div>
            )}
          </Card>

          {/* Owner Distribution */}
          <Card>
            <h3 className="section-title">
              <i className="bi bi-people" />
              Owner Distribution
            </h3>
            {ownerEntries.length > 0 ? (
              ownerEntries.map(([owner, count]) => (
                <div className="owner-row" key={owner}>
                  <div
                    className="avatar avatar--sm flex-shrink-0"
                    style={{ background: hashColor(owner), borderRadius: '50%', color: '#fff', fontSize: '0.6875rem', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', width: 30, height: 30 }}
                  >
                    {owner.substring(0, 2).toUpperCase()}
                  </div>
                  <span style={{ fontSize: '0.8125rem', fontWeight: 500, color: '#334155', minWidth: 64, flexShrink: 0 }}>{owner}</span>
                  <div className="dist-track">
                    <div
                      className="dist-fill"
                      style={{ width: `${(count / maxOwner) * 100}%`, background: hashColor(owner) }}
                    />
                  </div>
                  <span className="owner-count">{count}</span>
                </div>
              ))
            ) : (
              <div className="empty-state"><i className="bi bi-inbox" /><span>No data</span></div>
            )}
          </Card>
        </div>

        {/* Upcoming Milestones Table */}
        {upcomingTasks.length > 0 && (
          <Card>
            <h3 className="section-title">
              <i className="bi bi-calendar-check" />
              Upcoming Milestones
            </h3>
            <div className="table-responsive">
              <table className="table table-hover mb-0" style={{ fontSize: '0.8125rem' }}>
                <thead>
                  <tr style={{ fontSize: '0.6875rem', textTransform: 'uppercase', letterSpacing: '0.06em', color: '#94a3b8' }}>
                    <th className="fw-semibold border-0 pb-3">ID</th>
                    <th className="fw-semibold border-0 pb-3">Task</th>
                    <th className="fw-semibold border-0 pb-3">Enablement</th>
                    <th className="fw-semibold border-0 pb-3">Owner</th>
                    <th className="fw-semibold border-0 pb-3">Status</th>
                    <th className="fw-semibold border-0 pb-3">Health</th>
                    <th className="fw-semibold border-0 pb-3">Target Prod</th>
                  </tr>
                </thead>
                <tbody>
                  {upcomingTasks.map(task => (
                    <tr
                      key={task.id}
                      onClick={() => handleTaskClick(task)}
                      style={{ cursor: 'pointer' }}
                    >
                      <td className="fw-semibold" style={{ color: '#94a3b8', verticalAlign: 'middle' }}>{task.taskNumber}</td>
                      <td className="fw-medium" style={{ verticalAlign: 'middle', maxWidth: 260 }}>{task.name}</td>
                      <td style={{ verticalAlign: 'middle' }}>
                        <span className="custom-badge custom-badge--info" style={{ fontSize: '0.6875rem' }}>
                          {task.enablement && task.enablement !== 'None' ? task.enablement : 'APC'}
                        </span>
                      </td>

                      <td style={{ verticalAlign: 'middle' }}>
                        <div className="owner-avatar-stack">
                          {(task.ownerIds || []).slice(0, 2).map((owner, idx) => (
                            <div key={idx} className="stack-avatar" title={owner} style={{ background: hashColor(owner) }}>
                              {owner.substring(0, 2).toUpperCase()}
                            </div>
                          ))}
                          {(task.ownerIds?.length || 0) > 2 && (
                            <div className="stack-avatar stack-avatar--overflow">
                              +{(task.ownerIds?.length || 0) - 2}
                            </div>
                          )}
                          {(task.ownerIds?.length || 0) <= 2 && (
                            <span className="stack-names">{(task.ownerIds || []).join(', ')}</span>
                          )}
                        </div>
                      </td>
                      <td style={{ verticalAlign: 'middle' }}>
                        <span className="custom-badge custom-badge--muted" style={{ fontSize: '0.6875rem' }}>{task.status}</span>
                      </td>
                      <td style={{ verticalAlign: 'middle' }}>
                        <span className={`custom-badge custom-badge--${task.health === 'On Track' ? 'success' : task.health === 'At Risk' ? 'warning' : task.health === 'Blocked' ? 'danger' : 'muted'}`} style={{ fontSize: '0.6875rem' }}>
                          {task.health}
                        </span>
                      </td>
                      <td style={{ verticalAlign: 'middle', color: '#64748b', fontVariantNumeric: 'tabular-nums' }}>
                        {format(new Date(task.targetProdDate!), 'dd MMM yyyy')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}
      </div>

      <TaskDetailsDrawer
        isOpen={isDrawerOpen}
        onClose={() => { setIsDrawerOpen(false); setSelectedTask(null); }}
        task={selectedTask}
        isNew={!selectedTask}
      />
    </>
  );
}
