import React, { useState } from 'react';
import { Task, TaskStatus } from '../../../types/task';
import { Drawer } from '../../../components/ui/Drawer';
import { TaskForm } from './TaskForm';
import { useTasks } from '../../../context/TaskContext';
import { Badge } from '../../../components/ui/Badge';
import { ProgressBar } from '../../../components/ui/ProgressBar';
import { hashColor } from '../../../components/ui/OwnerPicker';
import { format } from 'date-fns';

interface TaskDetailsDrawerProps {
  task: Task | null;
  isOpen: boolean;
  onClose: () => void;
  isNew?: boolean;
}

const STATUSES: TaskStatus[] = ['NEW', 'READY FOR WORK', 'DEV IN PROGRESS', 'READY FOR QA', 'QA IN PROGRESS', 'READY FOR ACCEPTANCE', 'READY FOR UAT', 'UAT RELEASED', 'READY FOR RELEASE', 'DONE'];

export function TaskDetailsDrawer({ task, isOpen, onClose, isNew = false }: TaskDetailsDrawerProps) {
  const [isEditing, setIsEditing] = useState(isNew);
  const { addTask, updateTask, moveTask, deleteTask } = useTasks();

  const handleDelete = () => {
    if (task && window.confirm('Are you sure you want to delete this task?')) {
      deleteTask(task.id);
      onClose();
    }
  };

  // Reset edit state when task changes unless it's new
  React.useEffect(() => {
    setIsEditing(isNew);
  }, [task, isNew, isOpen]);

  const handleSubmit = (data: Partial<Task>) => {
    if (isNew) {
      addTask(data as Omit<Task, 'id' | 'taskNumber' | 'createdAt' | 'updatedAt'>);
    } else if (task) {
      updateTask({ ...task, ...data } as Task);
    }
    setIsEditing(false);
    if (isNew) onClose();
  };

  const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    if (task) {
      moveTask(task.id, e.target.value as TaskStatus);
    }
  };

  if (!isOpen && !task && !isNew) return null;

  return (
    <Drawer 
      isOpen={isOpen} 
      onClose={onClose} 
      title={isNew ? 'Create New Task' : task?.taskNumber || 'Task Details'}
      width="600px"
    >
      {isEditing || isNew ? (
        <TaskForm 
          initialData={isNew ? null : task} 
          onSubmit={handleSubmit} 
          onCancel={() => isNew ? onClose() : setIsEditing(false)} 
        />
      ) : task ? (
        <div className="task-details-view fade-in">
          <div className="d-flex justify-content-between align-items-start mb-4">
            <div>
              <h4 className="fw-bold mb-1">{task.name}</h4>
              <div className="text-muted small">Created {format(new Date(task.createdAt), 'dd MMM yyyy')} • {task.category}</div>
            </div>
            <div className="d-flex gap-2">
              <button className="btn btn-outline-danger btn-sm" onClick={handleDelete}>
                <i className="bi bi-trash me-1"></i> Delete
              </button>
              <button className="btn btn-outline-primary btn-sm" onClick={() => setIsEditing(true)}>
                <i className="bi bi-pencil me-1"></i> Edit
              </button>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="card border-0 bg-light mb-4">
            <div className="card-body p-3 d-flex align-items-center justify-content-between">
              <div>
                <span className="fw-bold me-2">Current Stage:</span>
                <Badge variant={task.status === 'DONE' ? 'success' : 'primary'}>{task.status}</Badge>
              </div>
              <div className="d-flex align-items-center gap-2">
                <label className="small text-muted fw-bold mb-0 text-nowrap">Move to:</label>
                <select 
                  className="form-select form-select-sm" 
                  value={task.status}
                  onChange={handleStatusChange}
                >
                  {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>
          </div>

          <div className="row g-4 mb-4">
            <div className="col-sm-6">
              <h6 className="fw-bold text-muted text-uppercase small mb-2">Overview</h6>
              <ul className="list-unstyled mb-0">
                <li className="mb-2">
                  <span className="text-muted me-2">Owners:</span>
                  <div className="owner-avatar-stack d-inline-flex" style={{ verticalAlign: 'middle' }}>
                    {(task.ownerIds || []).map((owner, idx) => (
                      <div key={idx} className="stack-avatar" title={owner} style={{ background: hashColor(owner) }}>
                        {owner.substring(0, 2).toUpperCase()}
                      </div>
                    ))}
                    <span className="stack-names">{(task.ownerIds || []).join(', ')}</span>
                  </div>
                </li>
                <li className="mb-2"><span className="text-muted me-2">Enablement:</span> <strong>{task.enablement && task.enablement !== 'None' ? task.enablement : 'APC'}</strong></li>

                <li className="mb-2"><span className="text-muted me-2">Priority:</span> 
                  <Badge variant={task.priority === 'Critical' ? 'danger' : task.priority === 'High' ? 'warning' : 'info'}>{task.priority}</Badge>
                </li>
                <li className="mb-2"><span className="text-muted me-2">Work Type:</span> {task.workType}</li>
                <li><span className="text-muted me-2">Month:</span> {task.month}</li>
              </ul>
            </div>
            <div className="col-sm-6">
              <h6 className="fw-bold text-muted text-uppercase small mb-2">Health & Risk</h6>
              <ul className="list-unstyled mb-0">
                <li className="mb-2">
                  <span className="text-muted me-2">Health:</span> 
                  <Badge variant={task.health === 'On Track' ? 'success' : task.health === 'At Risk' ? 'warning' : task.health === 'Blocked' ? 'danger' : 'secondary'}>{task.health}</Badge>
                </li>
                <li className="mb-2">
                  <ProgressBar progress={task.progress || 0} showLabel className="mt-2" variant={task.progress === 100 ? 'success' : 'primary'} />
                </li>
              </ul>
            </div>
          </div>

          <hr className="my-4" />

          <h6 className="fw-bold text-muted text-uppercase small mb-3">Delivery Milestones</h6>
          <div className="row g-3 mb-4">
            <div className="col-sm-6">
              <div className="p-3 bg-light rounded">
                <div className="small text-muted mb-1">Target Production</div>
                <div className="fw-bold">{task.targetProdDate ? format(new Date(task.targetProdDate), 'dd MMM yyyy') : 'Not Set'}</div>
              </div>
            </div>
            <div className="col-sm-6">
              <div className="p-3 bg-light rounded">
                <div className="small text-muted mb-1">UAT Handover</div>
                <div className="fw-bold">{task.uatHandoverDate ? format(new Date(task.uatHandoverDate), 'dd MMM yyyy') : 'Not Set'}</div>
              </div>
            </div>
            {task.spillOverProdDate && (
              <div className="col-12">
                <div className="p-3 bg-warning bg-opacity-10 rounded border border-warning">
                  <div className="small text-warning fw-bold mb-1"><i className="bi bi-exclamation-triangle me-1"></i> Spill Over Target</div>
                  <div className="fw-bold">{format(new Date(task.spillOverProdDate), 'dd MMM yyyy')}</div>
                </div>
              </div>
            )}
          </div>

          {task.comments && (
            <>
              <h6 className="fw-bold text-muted text-uppercase small mb-2">Comments</h6>
              <div className="p-3 bg-light rounded mb-4">
                {task.comments}
              </div>
            </>
          )}

          <hr className="my-4" />

          <h6 className="fw-bold text-muted text-uppercase small mb-3">Activity History</h6>
          <div className="activity-timeline position-relative border-start border-2 ms-2 ps-3 border-light">
            {(task.activities || []).slice().reverse().map(act => (
              <div key={act.id} className="mb-3 position-relative">
                <span className="position-absolute top-0 start-0 translate-middle p-1 bg-primary border border-white rounded-circle" style={{ marginLeft: '-15px' }}></span>
                <div className="small text-muted mb-1">{format(new Date(act.date), 'dd MMM yyyy HH:mm')}</div>
                <div className="fw-medium">{act.description}</div>
              </div>
            ))}
          </div>

        </div>
      ) : null}
    </Drawer>
  );
}
