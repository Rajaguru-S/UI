import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Task, TaskCategory, WorkType, Priority, TaskStatus, DeliveryEnvironment } from '../../../types/task';
import { OwnerPicker } from '../../../components/ui/OwnerPicker';
import { useSettings } from '../../../context/SettingsContext';
import { format } from 'date-fns';

interface TaskFormProps {
  initialData?: Task | null;
  onSubmit: (data: Partial<Task>) => void;
  onCancel: () => void;
}

export function TaskForm({ initialData, onSubmit, onCancel }: TaskFormProps) {
  const [selectedOwners, setSelectedOwners] = useState<string[]>(
    initialData?.ownerIds || []
  );
  const { settings } = useSettings();

  const { register, handleSubmit, formState: { errors }, reset } = useForm<Partial<Task>>({
    defaultValues: initialData || {
      name: '',
      month: 'August 2026',
      category: 'Development',
      workType: 'Product Backlog',
      priority: 'Medium',
      status: 'NEW',
      taskDate: new Date().toISOString().split('T')[0],
      environment: 'UAT + Production',
      health: 'On Track',
      progress: 0,
      enablement: 'APC',
    }
  });

  useEffect(() => {
    if (initialData) {
      reset(initialData);
      setSelectedOwners(initialData.ownerIds || []);
    }
  }, [initialData, reset]);

  const submitHandler = (data: Partial<Task>) => {
    onSubmit({ ...data, ownerIds: selectedOwners });
  };

  return (
    <form onSubmit={handleSubmit(submitHandler)}>
      <div className="row g-3 mb-3">
        <div className="col-md-4">
          <label className="form-label fw-bold">Enablement</label>
          <select className="form-select" {...register('enablement')}>
            {settings.fieldOptions.enablement.map(en => (
              <option key={en} value={en}>{en}</option>
            ))}
          </select>
        </div>
        <div className="col-md-8">
          <label className="form-label fw-bold">Task Name *</label>
          <input 
            type="text" 
            className={`form-control ${errors.name ? 'is-invalid' : ''}`}
            {...register('name', { required: 'Task name is required' })} 
          />
          {errors.name && <div className="invalid-feedback">{errors.name.message}</div>}
        </div>
      </div>

      <div className="row g-3 mb-3">
        <div className="col-md-6">
          <label className="form-label fw-bold">
            <i className="bi bi-people-fill me-1 text-primary"></i>
            Owners *
          </label>
          <OwnerPicker value={selectedOwners} onChange={setSelectedOwners} />
          {selectedOwners.length === 0 && (
            <div className="text-danger small mt-1">At least one owner is required</div>
          )}
        </div>
        <div className="col-md-6">
          <label className="form-label fw-bold">Target Month *</label>
          <select className="form-select" {...register('month', { required: true })}>
            {settings.fieldOptions.targetMonth.map(month => (
              <option key={month} value={month}>{month}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="row g-3 mb-3">
        <div className="col-md-4">
          <label className="form-label fw-bold">Category</label>
          <select className="form-select" {...register('category')}>
            {settings.fieldOptions.category.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
        <div className="col-md-4">
          <label className="form-label fw-bold">Work Type</label>
          <select className="form-select" {...register('workType')}>
            {settings.fieldOptions.workType.map(wt => (
              <option key={wt} value={wt}>{wt}</option>
            ))}
          </select>
        </div>
        <div className="col-md-4">
          <label className="form-label fw-bold">Priority</label>
          <select className="form-select" {...register('priority')}>
            {settings.fieldOptions.priority.map(p => (
              <option key={p} value={p}>{p}</option>
            ))}
          </select>
        </div>
      </div>

      <hr className="my-4" />
      <h6 className="fw-bold mb-3 text-primary">Delivery Milestones</h6>

      <div className="row g-3 mb-3">
        <div className="col-md-6">
          <label className="form-label fw-bold">Environment</label>
          <select className="form-select" {...register('environment')}>
            {settings.fieldOptions.environment.map(env => (
              <option key={env} value={env}>{env}</option>
            ))}
          </select>
        </div>
        <div className="col-md-6">
          <label className="form-label fw-bold">Target Prod Date</label>
          <input type="date" className="form-control" {...register('targetProdDate')} />
        </div>
      </div>

      <div className="row g-3 mb-3">
        <div className="col-md-6">
          <label className="form-label fw-bold">UAT Handover Date</label>
          <input type="date" className="form-control" {...register('uatHandoverDate')} />
        </div>
        <div className="col-md-6">
          <label className="form-label fw-bold">UAT Sign-off Planned Date</label>
          <input type="date" className="form-control" {...register('uatSignoffPlannedDate')} />
        </div>
      </div>

      <div className="mb-3">
        <label className="form-label fw-bold">Spill-over Prod Date</label>
        <input type="date" className="form-control" {...register('spillOverProdDate')} />
      </div>

      <hr className="my-4" />
      <h6 className="fw-bold mb-3 text-primary">Additional Information</h6>

      <div className="mb-3">
        <label className="form-label fw-bold">Comments / Next Actions</label>
        <textarea className="form-control" rows={3} {...register('comments')}></textarea>
      </div>

      <div className="d-flex justify-content-end gap-2 mt-4">
        <button type="button" className="btn btn-light" onClick={onCancel}>Cancel</button>
        <button type="submit" className="btn btn-primary" disabled={selectedOwners.length === 0}>Save Task</button>
      </div>
    </form>
  );
}
