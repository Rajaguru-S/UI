export interface FieldOptions {
  enablement: string[];
  category: string[];
  workType: string[];
  priority: string[];
  environment: string[];
  targetMonth: string[];
  owners: string[];
}

export interface AppSettings {
  fieldOptions: FieldOptions;
}

export const DEFAULT_FIELD_OPTIONS: FieldOptions = {
  enablement: ['None', 'APC', 'DRG', 'Others'],
  category: ['Development', 'Enhancement', 'Bug', 'Support', 'Configuration', 'Analysis', 'Release', 'Documentation', 'Other'],
  workType: ['Product Backlog', 'Bug', 'Enhancement', 'Support'],
  priority: ['Critical', 'High', 'Medium', 'Low'],
  environment: ['UAT', 'Production', 'Configuration', 'UAT + Production', 'Other'],
  targetMonth: ['July 2026', 'August 2026', 'September 2026', 'October 2026', 'November 2026', 'December 2026'],
  owners: ['Raj', 'Kumar', 'Sarah', 'Alex', 'Priya', 'Michael'],
};

export const DEFAULT_SETTINGS: AppSettings = {
  fieldOptions: DEFAULT_FIELD_OPTIONS,
};
