export type TaskCategory =
  | 'Development'
  | 'Enhancement'
  | 'Bug'
  | 'Support'
  | 'Configuration'
  | 'Release'
  | 'Analysis'
  | 'Documentation'
  | 'Other';

export type WorkType =
  | 'Product Backlog'
  | 'Bug'
  | 'Enhancement'
  | 'Support';

export type Priority =
  | 'Critical'
  | 'High'
  | 'Medium'
  | 'Low';

export type TaskStatus =
  | 'NEW'
  | 'READY FOR WORK'
  | 'DEV IN PROGRESS'
  | 'READY FOR QA'
  | 'QA IN PROGRESS'
  | 'READY FOR ACCEPTANCE'
  | 'READY FOR UAT'
  | 'UAT RELEASED'
  | 'READY FOR RELEASE'
  | 'DONE';

export type DeliveryEnvironment =
  | 'UAT'
  | 'Production'
  | 'Configuration'
  | 'UAT + Production'
  | 'Other';

export type DeliveryHealth =
  | 'On Track'
  | 'At Risk'
  | 'Blocked'
  | 'Completed'
  | 'Spill Over';

export interface TaskActivity {
  id: string;
  date: string;
  description: string;
}

export interface Task {
  id: string;
  taskNumber: string; // e.g., TASK-1001
  taskDate: string; // ISO string
  month: string; // e.g., 'August 2026'
  name: string;
  category: TaskCategory;
  workType: WorkType;
  ownerIds: string[]; // Replaced single ownerId with an array of owners
  priority: Priority;
  status: TaskStatus;
  enablement?: string;
  comments?: string;

  environment?: DeliveryEnvironment;

  uatHandoverDate?: string;
  uatSignoffPlannedDate?: string;
  qcViewUatDate?: string;
  targetProdDate?: string;
  spillOverProdDate?: string;
  deliveryComments?: string;

  health: DeliveryHealth;
  progress?: number; // 0-100

  isBlocked?: boolean;
  blockerComment?: string;

  createdAt: string;
  updatedAt: string;
  
  activities?: TaskActivity[];
}

export interface User {
  id: string;
  name: string;
  avatarUrl?: string;
}
