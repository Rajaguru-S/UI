const fs = require('fs');
const path = require('path');

const dirs = [
  'src/styles/abstracts',
  'src/styles/base',
  'src/styles/components',
  'src/styles/layout',
  'src/styles/pages',
  'src/styles/themes',
  'src/styles/vendors',
];

const files = {
  'src/styles/abstracts/_variables.scss': '',
  'src/styles/abstracts/_mixins.scss': '',
  'src/styles/abstracts/_functions.scss': '',
  'src/styles/base/_reset.scss': '',
  'src/styles/base/_typography.scss': '',
  'src/styles/base/_global.scss': '',
  'src/styles/components/_buttons.scss': '',
  'src/styles/components/_cards.scss': '',
  'src/styles/components/_forms.scss': '',
  'src/styles/components/_badges.scss': '',
  'src/styles/components/_kanban.scss': '',
  'src/styles/components/_metrics.scss': '',
  'src/styles/layout/_header.scss': '',
  'src/styles/layout/_sidebar.scss': '',
  'src/styles/layout/_content.scss': '',
  'src/styles/layout/_responsive.scss': '',
  'src/styles/pages/_dashboard.scss': '',
  'src/styles/pages/_workboard.scss': '',
  'src/styles/pages/_settings.scss': '',
  'src/styles/themes/_default.scss': '',
  'src/styles/vendors/_bootstrap.scss': '@import "bootstrap/scss/bootstrap";\n@import "bootstrap-icons/font/bootstrap-icons.scss";\n',
  'src/styles/main.scss': `
@import "abstracts/variables";
@import "abstracts/functions";
@import "abstracts/mixins";

@import "vendors/bootstrap";

@import "base/reset";
@import "base/typography";
@import "base/global";

@import "themes/default";

@import "layout/header";
@import "layout/sidebar";
@import "layout/content";
@import "layout/responsive";

@import "components/buttons";
@import "components/cards";
@import "components/forms";
@import "components/badges";
@import "components/kanban";
@import "components/metrics";

@import "pages/dashboard";
@import "pages/workboard";
@import "pages/settings";
`
};

dirs.forEach(dir => {
  fs.mkdirSync(path.join(__dirname, dir), { recursive: true });
});

Object.entries(files).forEach(([file, content]) => {
  fs.writeFileSync(path.join(__dirname, file), content.trim() + '\n');
});

console.log('SCSS structure created successfully.');
