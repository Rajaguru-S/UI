# Item Hover Color Background

A Pen created on CodePen.io. Original URL: [https://codepen.io/wikyware-net/pen/dyKPRxQ](https://codepen.io/wikyware-net/pen/dyKPRxQ).

