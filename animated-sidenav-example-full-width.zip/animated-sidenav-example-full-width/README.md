# Animated Sidenav Example Full Width

A Pen created on CodePen.io. Original URL: [https://codepen.io/francobao/pen/XoRrOP](https://codepen.io/francobao/pen/XoRrOP).

