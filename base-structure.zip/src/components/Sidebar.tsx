import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Sidebar.css';

const Sidebar: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [submenuOpen, setSubmenuOpen] = useState(false);

  return (
    <div
      className={`sidebar bg-light border-end ${
        collapsed ? 'collapsed' : 'expanded'
      }`}
    >
      <button
        className="btn btn-outline-primary w-100 toggle-btn"
        onClick={() => setCollapsed(!collapsed)}
      >
        {collapsed ? '☰' : '⇤'}
      </button>

      <ul className="list-group mt-3">
        <li className="list-group-item">
          <Link to="/">
            <span className="icon">🏠</span>
            {!collapsed && <span className="text">Dashboard</span>}
          </Link>
        </li>

        <li className="list-group-item">
          <div
            onClick={() => setSubmenuOpen(!submenuOpen)}
            className="submenu-toggle d-flex justify-content-between align-items-center"
          >
            <span>
              <span className="icon">⚙️</span>
              {!collapsed && <span className="text ms-2">Settings</span>}
            </span>
            {!collapsed && (
              <span className="arrow">{submenuOpen ? '▲' : '▼'}</span>
            )}
          </div>

          <ul
            className={`submenu list-unstyled ps-4 ${
              submenuOpen && !collapsed ? 'open' : ''
            }`}
          >
            <li>
              <Link to="/settings/profile">Profile</Link>
            </li>
            <li>
              <Link to="/settings/account">Account</Link>
            </li>
            <li>
              <Link to="/settings/security">Security</Link>
            </li>
          </ul>
        </li>

        <li className="list-group-item">
          <Link to="/profile">
            <span className="icon">👤</span>
            {!collapsed && <span className="text">Profile</span>}
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
