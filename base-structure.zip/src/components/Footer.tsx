import React from 'react';

const Footer: React.FC = () => (
  <footer className="bg-dark text-white text-center p-3 mt-auto">
    <small>&copy; 2025 My Company</small>
  </footer>
);

export default Footer;
