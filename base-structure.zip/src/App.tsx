import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';

const Dashboard = () => <h2>Dashboard</h2>;
const Profile = () => <h2>User Profile</h2>;
const SettingsProfile = () => <h2>Settings - Profile</h2>;
const SettingsAccount = () => <h2>Settings - Account</h2>;
const SettingsSecurity = () => <h2>Settings - Security</h2>;

const App: React.FC = () => (
  <Router>
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/settings/profile" element={<SettingsProfile />} />
        <Route path="/settings/account" element={<SettingsAccount />} />
        <Route path="/settings/security" element={<SettingsSecurity />} />
      </Routes>
    </Layout>
  </Router>
);

export default App;
