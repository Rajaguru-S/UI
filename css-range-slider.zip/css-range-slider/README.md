# CSS | Range Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/shashank_coder/pen/jOqxOpK](https://codepen.io/shashank_coder/pen/jOqxOpK).

