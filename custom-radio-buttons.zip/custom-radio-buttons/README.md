# Custom Radio Buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/tobias-totz/pen/PoPrVxw](https://codepen.io/tobias-totz/pen/PoPrVxw).

I needed a simple css only solution for a custom checkbox / custom radiobutton. I experimented a bit  with some UI/UX designs and ended with this.  (No Javascript needed)