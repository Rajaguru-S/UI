import React, { useState, useRef } from "react";
import "./App.css";

const App = () => {
  const [editableText, setEditableText] = useState(""); // Textarea content
  const textareaRef = useRef(null); // Reference to the textarea

  const textItems = Array.from({ length: 15 }, (_, i) => ({
    id: i + 1,
    content: `This is item ${i + 1} to edit.`,
  }));

  const handleEdit = (content, event) => {
    const clickedElementRect = event.target.getBoundingClientRect();
    const startTop = clickedElementRect.top + window.scrollY;
    const startLeft = clickedElementRect.left;

    const textareaRect = textareaRef.current.getBoundingClientRect();
    const endTop = textareaRect.top + window.scrollY;
    const endLeft = textareaRect.left;

    // Create a duplicate div for animation
    const animatedDiv = document.createElement("div");
    animatedDiv.textContent = content;
    animatedDiv.className = "text-item moving";
    animatedDiv.style.position = "absolute";
    animatedDiv.style.top = `${startTop}px`;
    animatedDiv.style.left = `${startLeft}px`;
    animatedDiv.style.transform = `translate(0, 0)`;
    document.body.appendChild(animatedDiv);

    // Trigger animation
    setTimeout(() => {
      animatedDiv.style.transform = `translate(${endLeft - startLeft}px, ${
        endTop - startTop
      }px)`;
    }, 0);

    // Remove the animated div and update the textarea after the animation
    animatedDiv.addEventListener("transitionend", () => {
      setEditableText(content);
      animatedDiv.remove();
    });
  };

  return (
    <div className="container">
      {/* Fixed Textarea */}
      <div className="text-area">
        <textarea
          ref={textareaRef}
          value={editableText}
          readOnly
          placeholder="Click Edit to move text here..."
        />
      </div>

      {/* List of Text Items */}
      <div className="text-items">
        {textItems.map((item) => (
          <div key={item.id} className="text-item">
            <span>{item.content}</span>
            <button onClick={(e) => handleEdit(item.content, e)}>Edit</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;

<style>
    body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.container {
  width: 100%;
  max-width: 600px;
  position: relative;
}

/* Text Area */
.text-area {
  width: 100%;
  position: fixed;
  top: 20px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  justify-content: center;
}

textarea {
  width: 90%;
  height: 100px;
  font-size: 16px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

/* Text Items */
.text-items {
  margin-top: 150px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.text-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 5px;
  background-color: #f9f9f9;
}

/* Moving Animation */
.text-item.moving {
  z-index: 1000;
  background-color: #e0f7fa;
  transition: transform 0.5s ease-out;
}

button {
  margin-left: 10px;
  padding: 5px 10px;
  font-size: 14px;
  cursor: pointer;
  border: none;
  background-color: #007bff;
  color: white;
  border-radius: 5px;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #0056b3;
}

</style>