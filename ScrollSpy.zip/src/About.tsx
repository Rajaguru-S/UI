import { useEffect, useRef, useState } from 'react';

const sections = ['section1', 'section2', 'section3'];

export default function ScrollSpyTS() {
  const [activeSection, setActiveSection] = useState<string>('');
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sectionRefs = useRef<Record<string, HTMLDivElement | null>>({});

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleScroll = () => {
      const containerRect = container.getBoundingClientRect();

      const offsets = sections.map((id) => {
        const el = sectionRefs.current[id];
        if (!el) return { id, offset: Infinity };

        const rect = el.getBoundingClientRect();
        const relativeTop = rect.top - containerRect.top;

        return { id, offset: Math.abs(relativeTop) };
      });

      const closest = offsets.reduce((prev, curr) =>
        curr.offset < prev.offset ? curr : prev
      );

      setActiveSection(closest.id);
    };

    container.addEventListener('scroll', handleScroll);
    handleScroll(); // Initial call

    return () => {
      container.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const scrollToSection = (id: string) => {
    const section = sectionRefs.current[id];
    section?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div style={{ display: 'flex' }}>
      {/* Navigation */}
      <nav style={{ marginRight: '1rem' }}>
        {sections.map((id) => (
          <a
            key={id}
            href={`#${id}`}
            style={{
              display: 'block',
              padding: '0.5rem',
              color: activeSection === id ? 'red' : 'black',
              cursor: 'pointer',
              textDecoration: 'none',
            }}
            onClick={(e) => {
              e.preventDefault();
              scrollToSection(id);
            }}
          >
            {id}
          </a>
        ))}
      </nav>

      {/* Scrollable container */}
      <div
        ref={containerRef}
        style={{
          height: '300px', // container is scrollable
          overflowY: 'scroll',
          border: '1px solid #ccc',
          width: '100%',
        }}
      >
        {sections.map((id) => (
          <div
            key={id}
            id={id}
            ref={(el) => (sectionRefs.current[id] = el)}
            style={{
              padding: '1rem',
              borderBottom: '1px solid #eee',
            }}
          >
            <h2>{id}</h2>
            <p>
              This is the content for {id}. Lorem ipsum dolor sit amet,
              consectetur adipiscing elit. Sed sit amet facilisis urna. Praesent
              ultrices nulla at nisl tincidunt, in pharetra erat interdum. Etiam
              in volutpat ipsum.
            </p>
            <p>
              Vivamus imperdiet, sem eu scelerisque placerat, justo arcu rutrum
              erat, in fermentum felis velit at velit.
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
