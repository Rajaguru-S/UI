# Voice Search with JavaScript (Web Speech API)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Coding_Journey/pen/ewrWyG](https://codepen.io/Coding_Journey/pen/ewrWyG).

Use speech recognition to perform a Google search. For this purpose, the Web Speech API is used (currently only supported by Chrome).