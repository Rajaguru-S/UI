# Modal Button Animation - React

A Pen created on CodePen.io. Original URL: [https://codepen.io/matthewvincent/pen/reLPQZ](https://codepen.io/matthewvincent/pen/reLPQZ).

Cool modal pop-out button made with React