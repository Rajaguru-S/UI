$("button").click(function(){
    $(".trigger").toggleClass("drawn")
});