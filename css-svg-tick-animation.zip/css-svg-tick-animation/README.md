# CSS & SVG Tick animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/houbly/pen/yyzajr](https://codepen.io/houbly/pen/yyzajr).

