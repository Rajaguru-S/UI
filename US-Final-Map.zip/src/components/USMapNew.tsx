import { useState, useEffect, useRef } from "react";
import {
  ComposableMap,
  Geographies,
  Geography,
  Marker,
  Annotation,
} from "react-simple-maps";
import { stateCentroids, StateCentroid } from "../data/states";

const geoUrl = "https://cdn.jsdelivr.net/npm/us-atlas@3/states-10m.json";

type RiskLevel = "high" | "medium" | "low";

type RiskLevelStyles = {
  [key in RiskLevel]: {
    fill: string;
    stroke: string;
  };
};

const riskLevelStyles: RiskLevelStyles = {
  high: {
    fill: "url(#high-risk-pattern)",
    stroke: "#FFFFFF",
  },
  medium: {
    fill: "url(#medium-risk-pattern)",
    stroke: "#FFFFFF",
  },
  low: {
    fill: "url(#low-risk-pattern)",
    stroke: "#FFFFFF",
  },
};
// Mock data for state-specific information
const stateInfo = {
  California: {
    pharmacies: ["Pharmacy A", "Pharmacy B"],
    claimLineCounts: 1200,
    riskScore: 85,
    prescriptions: ["Prescription X", "Prescription Y"],
  },
  Texas: {
    pharmacies: ["Pharmacy C", "Pharmacy D"],
    claimLineCounts: 900,
    riskScore: 70,
    prescriptions: ["Prescription Z", "Prescription W"],
  },
  // Add more states as needed
};
const Map = () => {
  const [highlightedState, setHighlightedState] = useState(null);
  const [activeStates, setActiveStates] = useState<Set<string>>(new Set());
  const [popoverPosition, setPopoverPosition] = useState<{
    x: number;
    y: number;
  } | null>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const allStateNames = stateCentroids.map((state: any) => state.name);
  const isAllSelected = activeStates.size === allStateNames.length;

  const toggleAllStates = () => {
    if (isAllSelected) {
      setActiveStates(new Set());
    } else {
      setActiveStates(new Set(allStateNames));
    }
  };

  const handleStateClick = (stateName: string) => {
    setActiveStates((prev) => {
      const newActiveStates = new Set(prev);
      if (newActiveStates.has(stateName)) {
        newActiveStates.delete(stateName);
      } else {
        newActiveStates.add(stateName);
      }
      return newActiveStates;
    });
  };

  const [dimensions, setDimensions] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });

  useEffect(() => {
    const handleResize = () => {
      setDimensions({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const problematicStates = [
    "RI",
    "MA",
    "CT",
    "NJ",
    "MD",
    "DE",
    "VT",
    "NH",
    "DC",
    "WV",
  ];

  const getAdjustedValues = (state: StateCentroid, screenWidth: number) => {
    if (screenWidth < 600) {
      return {
        dx: state.dx ? state.dx * 0.5 : 0,
        dy: state.dy ? state.dy * 0.5 : 0,
        textDx: state.textDx ? state.textDx * 0.5 : 0,
        textDy: state.textDy ? state.textDy * 0.5 : 0,
      };
    }
    return {
      dx: state.dx || 0,
      dy: state.dy || 0,
      textDx: state.textDx || 0,
      textDy: state.textDy || 0,
    };
  };
  const handleStateHover = (stateName: string, event: React.MouseEvent) => {
    if (!mapContainerRef.current) return;

    const mapRect = mapContainerRef.current.getBoundingClientRect();
    const cursorX = event.clientX - mapRect.left;
    const cursorY = event.clientY - mapRect.top;

    // Popover dimensions (approximate)
    const popoverWidth = 250;
    const popoverHeight = 200;

    // Calculate available space
    const spaceRight = mapRect.width - cursorX;
    const spaceBottom = mapRect.height - cursorY;

    // Adjust popover position to avoid overflow
    const popoverX =
      spaceRight > popoverWidth ? cursorX + 10 : cursorX - popoverWidth - 10;
    const popoverY =
      spaceBottom > popoverHeight ? cursorY + 10 : cursorY - popoverHeight - 10;

    setHighlightedState(stateName);
    setPopoverPosition({ x: popoverX, y: popoverY });
  };

  const handleStateLeave = () => {
    setHighlightedState(null);
    setPopoverPosition(null);
  };

  const popoverStyle = {
    position: "absolute",
    left: popoverPosition?.x,
    top: popoverPosition?.y,
    backgroundColor: "white",
    padding: "16px",
    borderRadius: "8px",
    boxShadow: "0 4px 20px rgba(0, 0, 0, 0.15)",
    zIndex: 1000,
    minWidth: "250px",
    pointerEvents: "none",
  };

  const arrowStyle = {
    position: "absolute",
    width: "0",
    height: "0",
    borderLeft: "10px solid transparent",
    borderRight: "10px solid transparent",
    borderBottom: "10px solid white",
    top: "-10px",
    left: "50%",
    transform: "translateX(-50%)",
  };

  // Calculate the arrow position based on the state's centroid
  // const stateCentroid = stateCentroids.find(
  //   (s) => s.name === highlightedState
  // )?.coordinates;
  // if (stateCentroid && popoverPosition) {
  //   const arrowLeft = stateCentroid[0] - popoverPosition.x;
  //   arrowStyle.left = `${arrowLeft}px`;
  // }

  return (
    <div
      ref={mapContainerRef}
      style={{
        width: "100vw",
        height: "100vh",
        overflow: "hidden",
        position: "relative",
      }}
    >
      <button
        onClick={toggleAllStates}
        style={{
          position: "absolute",
          top: "20px",
          left: "20px",
          zIndex: 1000,
          padding: "8px 16px",
          backgroundColor: isAllSelected ? "#ff4444" : "#4CAF50",
          color: "white",
          border: "none",
          borderRadius: "4px",
          cursor: "pointer",
        }}
      >
        {isAllSelected ? "Deselect All" : "Select All"}
      </button>
      <ComposableMap
        projection="geoAlbersUsa"
        width={dimensions.width}
        height={dimensions.height}
        projectionConfig={{
          scale: dimensions.width * 1,
          translate: [dimensions.width / 2, dimensions.height / 2],
        }}
      >
        <defs>
          <pattern
            id="high-risk-pattern"
            x="0"
            y="0"
            width="300"
            height="168"
            patternUnits="userSpaceOnUse"
            patternContentUnits="userSpaceOnUse"
          >
            <image href="../../high.png" x="0" y="0" width="300" height="168" />
          </pattern>
          <pattern
            id="medium-risk-pattern"
            x="0"
            y="0"
            width="189"
            height="267"
            patternUnits="userSpaceOnUse"
            patternContentUnits="userSpaceOnUse"
          >
            <image
              href="../../medium.png"
              x="0"
              y="0"
              width="189"
              height="267"
            />
          </pattern>
          <pattern
            id="low-risk-pattern"
            x="0"
            y="0"
            width="1000"
            height="562"
            patternUnits="userSpaceOnUse"
            patternContentUnits="userSpaceOnUse"
          >
            <image
              href="../../green.png"
              x="0"
              y="0"
              width="1000"
              height="562"
            />
          </pattern>
        </defs>

        <defs>
          <filter id="state-shadow" height="130%" width="130%">
            <feDropShadow
              dx="0"
              dy="0"
              stdDeviation="4"
              floodColor="rgba(0,0,0,0.6)"
            />
          </filter>
        </defs>

        <Geographies geography={geoUrl}>
          {({ geographies }: any) =>
            geographies.map((geo: any) => {
              const state = stateCentroids.find(
                (s: any) => s.name === geo.properties.name
              );
              const riskLevel: RiskLevel = state ? state.riskLevel : "low";
              const style = riskLevelStyles[riskLevel];

              return (
                <Geography
                  key={geo.rsmKey}
                  geography={geo}
                  fill={style.fill}
                  stroke={style.stroke}
                  strokeWidth={0.5}
                  style={{
                    default: {
                      strokeWidth: 0.75,
                      outline: "none",
                      cursor: "pointer",
                      filter: activeStates.has(geo.properties.name)
                        ? "url(#state-shadow)"
                        : "none",
                    },
                    hover: {
                      strokeWidth: 0.75,
                      outline: "none",
                      cursor: "pointer",
                      filter: activeStates.has(geo.properties.name)
                        ? "url(#state-shadow)"
                        : "none",
                    },
                    pressed: {
                      strokeWidth: 0.75,
                      outline: "none",
                      cursor: "pointer",
                      filter: activeStates.has(geo.properties.name)
                        ? "url(#state-shadow)"
                        : "none",
                    },
                  }}
                  onClick={() => handleStateClick(geo.properties.name)}
                  onMouseEnter={(event: any) =>
                    handleStateHover(geo.properties.name, event)
                  }
                  onMouseLeave={handleStateLeave}
                  pointerEvents="all"
                />
              );
            })
          }
        </Geographies>

        {stateCentroids.map((state: any) => {
          if (problematicStates.includes(state.abbrev)) {
            const adjusted = getAdjustedValues(state, dimensions.width);
            return (
              <Annotation
                key={state.abbrev}
                subject={state.coordinates}
                dx={adjusted.dx}
                dy={adjusted.dy}
                connectorProps={{
                  stroke: "#FFFFFF",
                  strokeWidth: 1,
                  strokeLinecap: "round",
                }}
              >
                <text
                  x={adjusted.textDx}
                  y={adjusted.textDy}
                  fontSize={dimensions.width < 600 ? 8 : 10}
                  fontFamily="Arial"
                  textAnchor="middle"
                  fill="#FFFFFF"
                >
                  {state.name}
                </text>
              </Annotation>
            );
          }

          return (
            <Marker key={state.abbrev} coordinates={state.coordinates}>
              <text
                x={state.textDx || 0}
                y={state.textDy || 0}
                fontSize={dimensions.width < 600 ? 8 : 10}
                fontFamily="Arial"
                textAnchor="middle"
                fill={highlightedState === state.name ? "#333" : "#333"}
              >
                {state.name}
              </text>
            </Marker>
          );
        })}
      </ComposableMap>

      {highlightedState && popoverPosition && (
        <div style={popoverStyle}>
          <div style={arrowStyle} />
          <h3 style={{ margin: "0 0 12px 0", color: "#2c3e50" }}>
            {highlightedState}
          </h3>
          <div style={{ marginBottom: "8px" }}>
            <strong>Pharmacies:</strong>
            <ul style={{ margin: "8px 0", paddingLeft: "20px" }}>
              {stateInfo[highlightedState]?.pharmacies.map((pharmacy, i) => (
                <li key={i}>{pharmacy}</li>
              ))}
            </ul>
          </div>
          <div style={{ marginBottom: "8px" }}>
            <strong>Claim Line Counts:</strong>{" "}
            {stateInfo[highlightedState]?.claimLineCounts.toLocaleString()}
          </div>
          <div style={{ marginBottom: "8px" }}>
            <strong>Risk Score:</strong>{" "}
            {stateInfo[highlightedState]?.riskScore}/100
          </div>
          <div>
            <strong>Common Prescriptions:</strong>
            <ul style={{ margin: "8px 0", paddingLeft: "20px" }}>
              {stateInfo[highlightedState]?.prescriptions.map((rx, i) => (
                <li key={i}>{rx}</li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default Map;
