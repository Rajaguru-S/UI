import React from 'react';
import './Timeline.css';

type TimelineStatus = 'success' | 'failed' | 'in-progress' | 'not-started';

interface TimelineItem {
  id: string;
  title: string;
  description: string;
  date: string;
  status: TimelineStatus;
}

interface TimelineProps {
  items: TimelineItem[];
}

const Timeline: React.FC<TimelineProps> = ({ items }) => {
  const getStatusIcon = (status: TimelineStatus) => {
    switch (status) {
      case 'success':
        return (
          <svg className="timeline-icon status-success" viewBox="0 0 24 24">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
            <path d="M22 4L12 14.01l-3-3" />
          </svg>
        );
      case 'failed':
        return (
          <svg className="timeline-icon status-failed" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10" />
            <path d="M15 9l-6 6" />
            <path d="M9 9l6 6" />
          </svg>
        );
      case 'in-progress':
        return (
          <svg className="timeline-icon status-in-progress" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10" />
            <path d="M12 6v6l4 2" />
          </svg>
        );
      case 'not-started':
        return (
          <svg className="timeline-icon status-not-started" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10" />
          </svg>
        );
      default:
        return (
          <svg className="timeline-icon status-not-started" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10" />
          </svg>
        );
    }
  };

  return (
    <div className="timeline-container">
      {items.map((item, index) => (
        <div key={item.id} className="timeline-item">
          {index !== items.length - 1 && (
            <div className={`timeline-connector status-${item.status}`} />
          )}
          <div className="timeline-icon-container">
            {getStatusIcon(item.status)}
          </div>
          <div className="timeline-content">
            <div className="timeline-header">
              <h3 className="timeline-title">{item.title}</h3>
              <span className="timeline-date">{item.date}</span>
            </div>
            <p className="timeline-description">{item.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Timeline;