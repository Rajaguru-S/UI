import React from 'react';
import Timeline from './Timeline';

const App: React.FC = () => {
  const timelineItems = [
    {
      id: '1',
      title: 'Project Initiation',
      description: 'Project kickoff meeting with stakeholders',
      date: 'Jan 15, 2023',
      status: 'success' as const,
    },
    {
      id: '2',
      title: 'Requirements Gathering',
      description: 'Collecting and documenting all requirements',
      date: 'Feb 1, 2023',
      status: 'success' as const,
    },
    {
      id: '3',
      title: 'Development Phase',
      description: 'Implementing core features',
      date: 'Mar 10, 2023',
      status: 'in-progress' as const,
    },
    {
      id: '4',
      title: 'Testing',
      description: 'QA and user acceptance testing',
      date: 'Apr 5, 2023',
      status: 'not-started' as const,
    },
    {
      id: '5',
      title: 'Deployment',
      description: 'Production deployment and go-live',
      date: 'May 1, 2023',
      status: 'not-started' as const,
    },
  ];

  return (
    <div style={{ padding: '32px' }}>
      <h1 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '24px' }}>
        Project Timeline
      </h1>
      <Timeline items={timelineItems} />
    </div>
  );
};

export default App;