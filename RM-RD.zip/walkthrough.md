# Release Mailer Builder Walkthrough

The Release Mailer Builder has been successfully implemented according to your requirements. Below is a walkthrough of the features and technical decisions.

## Application Modules

### 1. Mail Builder
The core of the application is a two-column responsive layout built using `react-resizable-panels`.
- **Editor Panel (Left)**: Uses `react-hook-form` to manage the complex email state. It is divided into logical tabs (Basic, Content, Highlights, Next, Links, Brand) to prevent UI clutter.
- **Live Preview (Right)**: Renders the generated email in real-time. It uses inline CSS styles (specifically designed for Outlook compatibility) and sanitizes any HTML input using `DOMPurify`.
- **Toolbar**: Provides actions to Save Draft, Export HTML, and Copy HTML. Copying the HTML tracks the usage in the History module.

### 2. Templates
- Users can view and use templates to jumpstart their email creation.
- Two default templates ("Standard Release Notes" and "Emergency Hotfix") are seeded automatically on first load.
- Users can duplicate templates to create custom ones, and delete non-default templates.

### 3. Snippets
- A reusable content library organized by categories (Greetings, Release Summary, Support, etc.).
- Snippets can be inserted directly into the Editor Panel via the "Snippets" button located above supported text areas (like Greeting or Summary).

### 4. History & Drafts
- **Drafts**: Users can save their progress locally and resume later.
- **History**: Tracks all generated emails (when "Copy HTML" is clicked). Features KPI cards displaying total emails created, content copied, drafts saved, and the most used template.

### 5. Settings
- Allows global configuration for Brand Details (Company Name, Logo URL, Banner URL, Colors).
- Default settings for emails (Greeting, Closing, Environment).
- Export preferences and draft auto-save configurations.

## Technical Architecture

> [!TIP]
> **No Backend Required**
> The entire application uses `localforage` (a wrapper over IndexedDB) to persist all data locally in the browser, adhering strictly to the "no backend" requirement while providing a snappy, enterprise-grade experience.

- **Vite & React 19**: Lightning-fast builds and strict type checking with TypeScript.
- **7-1 SCSS Architecture**: A scalable styling structure utilizing `Bootstrap 5` for base components and custom SCSS variables/mixins for brand alignment.
- **Feature-Based Structure**: Code is organized logically by feature (`src/features/builder`, `src/features/templates`, etc.), ensuring the codebase remains maintainable as the app grows.

## Running the Application

To start the development server, you can run:
```bash
npm run dev
```

Navigate to `http://localhost:5173` in your browser to experience the builder. You can start by configuring your brand in the **Settings** tab, and then proceed to the **Builder** to generate your first release email!

## Testing

> [!NOTE]
> The application includes a comprehensive unit testing suite built with **Vitest** and **React Testing Library**.

### Test Coverage
- **Services (`storage.test.ts`)**: Mocks `localforage` to ensure that standard CRUD operations function as expected within our generic storage service.
- **UI Components (`Button.test.tsx`, `Input.test.tsx`)**: Checks rendering, conditional classes (variants, sizes), accessibility states, and basic interactions.
- **Features (`EmailPreview.test.tsx`, `Snippets.test.tsx`)**: Verifies that the live preview constructs DOM elements appropriately based on passed context props, ensures `DOMPurify` safely mitigates XSS attacks by sanitizing inputs, and validates the complex tab filtering behavior within snippets.

### Running Tests

To run the unit test suite, execute:
```bash
npm run test
```
