import { describe, it, expect, beforeEach, vi } from 'vitest';
import { StorageService } from './storage';


// Mock localforage
vi.mock('localforage', () => ({
  default: {
    createInstance: vi.fn(() => ({
      getItem: vi.fn(),
      setItem: vi.fn(),
      removeItem: vi.fn(),
      iterate: vi.fn(),
    })),
  },
}));

describe('StorageService', () => {
  let mockStore: any;
  let service: StorageService<{ id: string; name: string }>;

  beforeEach(() => {
    mockStore = {
      getItem: vi.fn(),
      setItem: vi.fn(),
      removeItem: vi.fn(),
      iterate: vi.fn(),
    };
    service = new StorageService(mockStore);
  });

  it('should save an item', async () => {
    const item = { id: '1', name: 'Test' };
    mockStore.setItem.mockResolvedValue(item);

    const result = await service.save(item);
    expect(mockStore.setItem).toHaveBeenCalledWith('1', item);
    expect(result).toEqual(item);
  });

  it('should get an item by id', async () => {
    const item = { id: '1', name: 'Test' };
    mockStore.getItem.mockResolvedValue(item);

    const result = await service.getById('1');
    expect(mockStore.getItem).toHaveBeenCalledWith('1');
    expect(result).toEqual(item);
  });

  it('should get all items', async () => {
    const items = [
      { id: '1', name: 'Test 1' },
      { id: '2', name: 'Test 2' },
    ];
    
    mockStore.iterate.mockImplementation(async (callback: (val: any) => void) => {
      items.forEach(callback);
    });

    const result = await service.getAll();
    expect(mockStore.iterate).toHaveBeenCalled();
    expect(result).toEqual(items);
  });

  it('should delete an item', async () => {
    mockStore.removeItem.mockResolvedValue(undefined);

    await service.delete('1');
    expect(mockStore.removeItem).toHaveBeenCalledWith('1');
  });
});
