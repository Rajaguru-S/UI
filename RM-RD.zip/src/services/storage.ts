import localforage from 'localforage';
import type { Template, Draft, Snippet, HistoryRecord, AppSettings } from '../types';

// Initialize localforage instances for different collections
export const storageTemplates = localforage.createInstance({
  name: 'ReleaseMailer',
  storeName: 'templates'
});

export const storageDrafts = localforage.createInstance({
  name: 'ReleaseMailer',
  storeName: 'drafts'
});

export const storageSnippets = localforage.createInstance({
  name: 'ReleaseMailer',
  storeName: 'snippets'
});

export const storageHistory = localforage.createInstance({
  name: 'ReleaseMailer',
  storeName: 'history'
});

export const storageSettings = localforage.createInstance({
  name: 'ReleaseMailer',
  storeName: 'settings'
});

// Generic service class for CRUD operations
export class StorageService<T extends { id: string }> {
  private store: LocalForage;

  constructor(store: LocalForage) {
    this.store = store;
  }

  async getAll(): Promise<T[]> {
    const items: T[] = [];
    await this.store.iterate((value: T) => {
      items.push(value);
    });
    return items;
  }

  async getById(id: string): Promise<T | null> {
    return this.store.getItem<T>(id);
  }

  async save(item: T): Promise<T> {
    return this.store.setItem(item.id, item);
  }

  async delete(id: string): Promise<void> {
    return this.store.removeItem(id);
  }
}

export const templateService = new StorageService<Template>(storageTemplates);
export const draftService = new StorageService<Draft>(storageDrafts);
export const snippetService = new StorageService<Snippet>(storageSnippets);
export const historyService = new StorageService<HistoryRecord>(storageHistory);

// Settings is a singleton document, doesn't need the generic CRUD
export const settingsService = {
  async getSettings(): Promise<AppSettings | null> {
    return storageSettings.getItem<AppSettings>('app_settings');
  },
  async saveSettings(settings: AppSettings): Promise<AppSettings> {
    return storageSettings.setItem('app_settings', settings);
  }
};
