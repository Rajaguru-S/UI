import { useForm } from 'react-hook-form';
import { useSettings } from '@/app/SettingsContext';
import { Card, CardHeader, CardBody } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import toast from 'react-hot-toast';
import type { AppSettings } from '@/types';

export default function Settings() {
  const { settings, updateSettings, isLoading } = useSettings();
  
  const { register, handleSubmit, formState: { isSubmitting } } = useForm<AppSettings>({
    defaultValues: settings || {}
  });

  if (isLoading) return <div>Loading...</div>;

  const onSubmit = async (data: AppSettings) => {
    try {
      await updateSettings(data);
      toast.success('Settings saved successfully');
    } catch (err) {
      toast.error('Failed to save settings');
    }
  };

  return (
    <div className="container-fluid max-w-1200 mx-auto">
      <div className="d-flex align-items-center justify-content-between mb-4">
        <h2 className="m-0 fw-bold">Settings</h2>
        <Button onClick={handleSubmit(onSubmit)} isLoading={isSubmitting}>
          Save Changes
        </Button>
      </div>

      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="row g-4">
          <div className="col-12 col-xl-6">
            <Card className="h-100">
              <CardHeader>
                <h5 className="m-0 fw-bold">Brand Details</h5>
              </CardHeader>
              <CardBody>
                <Input label="Company Name" {...register('brand.companyName')} />
                <Input label="Logo URL" {...register('brand.logoUrl')} />
                <Input label="Banner Image URL" {...register('brand.bannerUrl')} />
                <Input label="Primary Color (Hex)" type="color" className="form-control form-control-color w-100" {...register('brand.primaryColor')} />
                <Input label="Footer Text" {...register('brand.footerText')} />
              </CardBody>
            </Card>
          </div>
          
          <div className="col-12 col-xl-6">
            <Card className="h-100">
              <CardHeader>
                <h5 className="m-0 fw-bold">Email Defaults</h5>
              </CardHeader>
              <CardBody>
                <Input label="Default Subject Prefix" {...register('defaults.subject')} />
                <Input label="Default Greeting" {...register('defaults.greeting')} />
                <Input label="Default Environment" {...register('defaults.environment')} />
                <Input label="Default Closing" {...register('defaults.closing')} />
              </CardBody>
            </Card>
          </div>

          <div className="col-12 col-xl-6">
            <Card className="h-100">
              <CardHeader>
                <h5 className="m-0 fw-bold">Draft & Save Settings</h5>
              </CardHeader>
              <CardBody>
                <div className="form-check form-switch mb-3">
                  <input className="form-check-input" type="checkbox" role="switch" id="autoSave" {...register('draft.autoSave')} />
                  <label className="form-check-label fw-medium text-secondary small" htmlFor="autoSave">Enable Auto-Save</label>
                </div>
                <Input label="Auto-Save Interval (Seconds)" type="number" {...register('draft.saveInterval', { valueAsNumber: true })} />
              </CardBody>
            </Card>
          </div>

          <div className="col-12 col-xl-6">
            <Card className="h-100">
              <CardHeader>
                <h5 className="m-0 fw-bold">Export Preferences</h5>
              </CardHeader>
              <CardBody>
                <div className="form-check form-switch mb-3">
                  <input className="form-check-input" type="checkbox" role="switch" id="copyHtml" {...register('copy.copyHtml')} />
                  <label className="form-check-label fw-medium text-secondary small" htmlFor="copyHtml">Copy as HTML</label>
                </div>
                <div className="form-check form-switch mb-3">
                  <input className="form-check-input" type="checkbox" role="switch" id="copyInlineCss" {...register('copy.copyInlineCss')} />
                  <label className="form-check-label fw-medium text-secondary small" htmlFor="copyInlineCss">Inject Inline CSS (Recommended for Outlook)</label>
                </div>
              </CardBody>
            </Card>
          </div>
        </div>
      </form>
    </div>
  );
}
