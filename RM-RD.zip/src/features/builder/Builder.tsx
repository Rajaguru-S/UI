import { useState, useEffect } from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import { useSearchParams } from 'react-router-dom';
import { templateService, draftService } from '@/services/storage';
import type { MailContent } from '@/types';
import { useSettings } from '@/app/SettingsContext';
import { EditorPanel } from './EditorPanel';
import { EmailPreview } from './EmailPreview';
import { Toolbar } from './Toolbar';
import { v4 as uuidv4 } from 'uuid';

const defaultEmptyContent: MailContent = {
  subject: '',
  releaseVersion: '',
  releaseDate: new Date().toISOString().split('T')[0],
  environment: '',
  bannerTitle: '',
  bannerDescription: '',
  greeting: '',
  releaseSummary: '',
  processItems: '',
  additionalNotes: '',
  closing: '',
  highlightsTitle: 'Release Highlights',
  highlightsDescription: '',
  highlightCards: [
    { id: uuidv4(), title: '', description: '' },
    { id: uuidv4(), title: '', description: '' },
    { id: uuidv4(), title: '', description: '' },
    { id: uuidv4(), title: '', description: '' }
  ],
  whatsNextTitle: "What's Next?",
  whatsNextDescription: '',
  whatsNextBullets: [''],
  links: []
};

export default function Builder() {
  const [searchParams] = useSearchParams();
  const { settings } = useSettings();
  const [currentDraftId, setCurrentDraftId] = useState<string | null>(null);

  const methods = useForm<MailContent>({
    defaultValues: defaultEmptyContent,
    mode: 'onChange'
  });

  const { reset, watch } = methods;
  const currentContent = watch();

  useEffect(() => {
    loadInitialData();
  }, [searchParams, settings]);

  const loadInitialData = async () => {
    const templateId = searchParams.get('template');
    const draftId = searchParams.get('draft');

    if (draftId) {
      const draft = await draftService.getById(draftId);
      if (draft) {
        reset(draft.content);
        setCurrentDraftId(draft.id);
        return;
      }
    }

    if (templateId) {
      const template = await templateService.getById(templateId);
      if (template) {
        reset(template.content);
        return;
      }
    }

    if (!draftId && !templateId && settings) {
      reset({
        ...defaultEmptyContent,
        subject: settings.defaults.subject,
        greeting: settings.defaults.greeting,
        closing: settings.defaults.closing,
        environment: settings.defaults.environment,
      });
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', gap: 0 }}>
      {/* Top Toolbar */}
      <Toolbar
        content={currentContent}
        draftId={currentDraftId}
        setDraftId={setCurrentDraftId}
      />

      {/* Two-column split layout */}
      <div style={{
        flex: 1,
        display: 'flex',
        gap: '16px',
        padding: '16px',
        minHeight: 0,
        overflow: 'hidden',
      }}>
        {/* Left: Editor — 44% */}
        <div style={{ flex: '0 0 44%', overflowY: 'auto', minWidth: 0 }} className="smooth-scroll">
          <FormProvider {...methods}>
            <EditorPanel />
          </FormProvider>
        </div>

        {/* Divider */}
        <div style={{
          flex: '0 0 1px',
          background: 'linear-gradient(to bottom, transparent, #D1D5E8 20%, #D1D5E8 80%, transparent)',
          alignSelf: 'stretch',
          borderRadius: '1px',
          flexShrink: 0,
        }} />

        {/* Right: Live Preview — remainder */}
        <div style={{ flex: 1, overflowY: 'auto', minWidth: 0 }} className="smooth-scroll">
          <EmailPreview content={currentContent} />
        </div>
      </div>
    </div>
  );
}
