import { render, screen } from '@testing-library/react';
import { EmailPreview } from './EmailPreview';


// Mock the DOMPurify since it relies on DOM APIs that might be tricky in basic jsdom sometimes,
// but usually it works fine. We will let it run natively.
vi.mock('@/app/SettingsContext', async (importOriginal) => {
  const actual: any = await importOriginal();
  return {
    ...actual,
    useSettings: () => ({
      settings: {
        brand: {
          primaryColor: '#ff0000',
          logoUrl: 'http://example.com/logo.png',
          bannerUrl: 'http://example.com/banner.png',
          footerText: 'Test Footer',
          companyName: 'Test Company'
        }
      }
    })
  };
});

describe('EmailPreview Component', () => {
  const mockContent = {
    subject: 'Test Subject',
    releaseVersion: '1.2.3',
    environment: 'Staging',
    bannerTitle: 'New Update',
    bannerDescription: 'Awesome new features',
    greeting: 'Hi there,',
    releaseSummary: '<p>Summary text</p>',
    highlightsTitle: 'Key Highlights',
    highlightCards: [
      { id: '1', title: 'Feature 1', description: 'Desc 1' },
      { id: '2', title: 'Feature 2', description: 'Desc 2' }
    ],
    whatsNextBullets: ['Next 1', 'Next 2'],
    links: [
      { id: 'l1', label: 'Docs', url: 'http://docs.com' }
    ],
    closing: 'Bye'
  };

  it('renders correctly with provided content', () => {
    render(<EmailPreview content={mockContent as any} />);

    // Check header info
    expect(screen.getByText('Staging Environment')).toBeInTheDocument();
    expect(screen.getByText('Version: 1.2.3')).toBeInTheDocument();

    // Check Banner
    expect(screen.getByText('New Update')).toBeInTheDocument();
    expect(screen.getByText('Awesome new features')).toBeInTheDocument();

    // Check Body
    expect(screen.getByText('Hi there,')).toBeInTheDocument();
    expect(screen.getByText('Summary text')).toBeInTheDocument();

    // Check Highlights
    expect(screen.getByText('Key Highlights')).toBeInTheDocument();
    expect(screen.getByText('Feature 1')).toBeInTheDocument();
    expect(screen.getByText('Desc 2')).toBeInTheDocument();

    // Check Next
    expect(screen.getByText('Next 1')).toBeInTheDocument();

    // Check Links
    const link = screen.getByRole('link', { name: 'Docs' });
    expect(link).toHaveAttribute('href', 'http://docs.com');

    // Check Closing
    expect(screen.getByText('Bye')).toBeInTheDocument();
  });

  it('sanitizes dangerous HTML in summary', () => {
    const dangerousContent = {
      ...mockContent,
      releaseSummary: '<p>Safe text <script>alert("xss")</script></p>'
    };

    render(<EmailPreview content={dangerousContent as any} />);
    expect(screen.getByText('Safe text')).toBeInTheDocument();
    // The script tag should be removed by DOMPurify
    expect(screen.queryByText('alert("xss")')).not.toBeInTheDocument();
  });
});
