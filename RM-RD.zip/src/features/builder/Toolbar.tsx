import { useState } from 'react';
import { Button } from '@/components/ui/Button';
import { FiSave, FiCopy, FiDownload, FiCheckCircle, FiMail } from 'react-icons/fi';
import { draftService, historyService } from '@/services/storage';
import type { MailContent } from '@/types';
import toast from 'react-hot-toast';
import { v4 as uuidv4 } from 'uuid';

interface ToolbarProps {
  content: MailContent;
  draftId: string | null;
  setDraftId: (id: string) => void;
}

export const Toolbar = ({ content, draftId, setDraftId }: ToolbarProps) => {
  const [isSaving, setIsSaving] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleSaveDraft = async () => {
    setIsSaving(true);
    try {
      const id = draftId || uuidv4();
      await draftService.save({
        id,
        name: content.subject || 'Untitled Draft',
        content,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });
      setDraftId(id);
      toast.success('Draft saved');
    } catch (_error) {
      toast.error('Failed to save draft');
    } finally {
      setIsSaving(false);
    }
  };

  /**
   * Get the rendered email HTML from the preview container.
   * Builds a complete, self-contained HTML document for Outlook compatibility.
   */
  const getEmailHtml = (): string => {
    const emailWrapper = document.querySelector('.email-preview-container [data-email-root]') as HTMLElement;
    if (!emailWrapper) {
      toast.error('Preview not found. Make sure the preview is visible.');
      return '';
    }

    const innerHtml = emailWrapper.outerHTML;

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>${content.subject || 'Release Email'}</title>
</head>
<body style="margin:0;padding:20px;background-color:#f4f5f7;font-family:Arial,sans-serif;">
  ${innerHtml}
</body>
</html>`;
  };

  /**
   * Copy the email as rich HTML to the clipboard.
   * Uses the ClipboardItem API so pasting into Outlook renders formatted email.
   */
  const handleCopyHtml = async () => {
    const html = getEmailHtml();
    if (!html) return;

    try {
      const blob = new Blob([html], { type: 'text/html' });
      const clipboardItem = new ClipboardItem({ 'text/html': blob });
      await navigator.clipboard.write([clipboardItem]);

      setCopied(true);
      toast.success('Email copied! Paste directly into Outlook.');
      setTimeout(() => setCopied(false), 3000);

      await historyService.save({
        id: uuidv4(),
        subject: content.subject || 'No Subject',
        releaseVersion: content.releaseVersion || 'N/A',
        templateName: 'Custom Builder',
        status: 'Generated',
        copiedCount: 1,
        content,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });
    } catch (_err) {
      try {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = html;
        tempDiv.style.position = 'absolute';
        tempDiv.style.left = '-9999px';
        document.body.appendChild(tempDiv);

        const range = document.createRange();
        range.selectNodeContents(tempDiv);
        const selection = window.getSelection();
        selection?.removeAllRanges();
        selection?.addRange(range);

        document.execCommand('copy');
        selection?.removeAllRanges();
        document.body.removeChild(tempDiv);

        setCopied(true);
        toast.success('Email copied! Paste directly into Outlook.');
        setTimeout(() => setCopied(false), 3000);
      } catch (_fallbackErr) {
        toast.error('Copy failed. Please use Export HTML instead.');
      }
    }
  };

  const handleExport = () => {
    const html = getEmailHtml();
    if (!html) return;
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `release-email-${content.releaseVersion || 'draft'}.html`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('HTML file exported successfully.');
  };

  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '12px 20px',
      background: 'rgba(255,255,255,0.85)',
      backdropFilter: 'blur(12px)',
      WebkitBackdropFilter: 'blur(12px)',
      borderBottom: '1px solid rgba(0,0,0,0.07)',
      boxShadow: '0 1px 0 rgba(0,0,0,0.04)',
      flexShrink: 0,
      gap: '12px',
    }}>
      {/* Left — Breadcrumb + status */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', minWidth: 0 }}>
        <div style={{
          width: 32,
          height: 32,
          borderRadius: '8px',
          background: 'linear-gradient(135deg, #4F6BFF 0%, #7C3AED 100%)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
        }}>
          <FiMail size={15} color="#fff" />
        </div>
        <div style={{ minWidth: 0 }}>
          <div style={{
            fontSize: '14px',
            fontWeight: 700,
            color: '#0D1117',
            lineHeight: 1.2,
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            maxWidth: '280px',
          }}>
            {content.subject || 'Untitled Email'}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '2px' }}>
            <span style={{
              display: 'inline-flex',
              alignItems: 'center',
              fontSize: '10px',
              fontWeight: 600,
              letterSpacing: '0.4px',
              textTransform: 'uppercase',
              padding: '2px 8px',
              borderRadius: '99px',
              background: draftId ? 'rgba(79,107,255,0.10)' : 'rgba(34,197,94,0.10)',
              color: draftId ? '#4F6BFF' : '#16a34a',
              border: `1px solid ${draftId ? 'rgba(79,107,255,0.25)' : 'rgba(34,197,94,0.25)'}`,
            }}>
              {draftId ? '● Draft' : '● New Email'}
            </span>
            {content.releaseVersion && (
              <span style={{
                fontSize: '10px',
                fontWeight: 600,
                color: '#6B7A99',
                letterSpacing: '0.3px',
              }}>
                v{content.releaseVersion}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Right — Action buttons */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexShrink: 0 }}>
        <Button
          variant="outline-secondary"
          onClick={handleSaveDraft}
          isLoading={isSaving}
          leftIcon={<FiSave size={13} />}
          size="sm"
        >
          Save Draft
        </Button>

        <Button
          variant="outline-primary"
          onClick={handleExport}
          leftIcon={<FiDownload size={13} />}
          size="sm"
        >
          Export HTML
        </Button>

        <Button
          variant="primary"
          onClick={handleCopyHtml}
          leftIcon={copied ? <FiCheckCircle size={14} /> : <FiCopy size={13} />}
          size="sm"
          style={{
            background: copied
              ? 'linear-gradient(135deg, #22C55E 0%, #16a34a 100%)'
              : 'linear-gradient(135deg, #4F6BFF 0%, #7C3AED 100%)',
            border: 'none',
            minWidth: '160px',
          }}
        >
          {copied ? 'Copied for Outlook!' : 'Copy for Outlook'}
        </Button>
      </div>
    </div>
  );
};
