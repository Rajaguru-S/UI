import { useState, useEffect } from 'react';
import { useFormContext, useFieldArray } from 'react-hook-form';
import type { MailContent, Snippet } from '@/types';
import { snippetService } from '@/services/storage';
import { Input, Textarea } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { FiPlus, FiTrash2, FiBookOpen, FiInfo } from 'react-icons/fi';
import { Modal } from '@/components/ui/Modal';

interface Tab {
  id: string;
  label: string;
}

const TABS: Tab[] = [
  { id: 'Basic',      label: 'Basic' },
  { id: 'Content',    label: 'Content' },
  { id: 'Highlights', label: 'Highlights' },
  { id: 'Next',       label: "What's Next" },
  { id: 'Links',      label: 'Links' },
  { id: 'Brand',      label: 'Brand' },
];

export const EditorPanel = () => {
  const { register, control, watch, setValue } = useFormContext<MailContent>();
  const [activeTab, setActiveTab] = useState(TABS[0].id);
  const [snippets, setSnippets] = useState<Snippet[]>([]);
  const [snippetModalOpen, setSnippetModalOpen] = useState(false);
  const [activeSnippetField, setActiveSnippetField] = useState<keyof MailContent | null>(null);

  const { fields: highlightFields } = useFieldArray({ control, name: 'highlightCards' });
  const { fields: linkFields, append: appendLink, remove: removeLink } = useFieldArray({ control, name: 'links' });
  const { fields: bulletFields, append: appendBullet, remove: removeBullet } = useFieldArray({
    control,
    name: 'whatsNextBullets' as never
  });

  useEffect(() => {
    snippetService.getAll().then(setSnippets);
  }, []);

  const openSnippetModal = (field: keyof MailContent) => {
    setActiveSnippetField(field);
    setSnippetModalOpen(true);
  };

  const applySnippet = (snippetContent: string) => {
    if (activeSnippetField) {
      const currentVal = watch(activeSnippetField) || '';
      setValue(activeSnippetField, currentVal + (currentVal ? '\n' : '') + snippetContent, { shouldDirty: true });
    }
    setSnippetModalOpen(false);
  };

  return (
    <div style={{
      background: '#fff',
      borderRadius: '12px',
      border: '1.5px solid #E4E7F0',
      boxShadow: '0 2px 8px rgba(0,0,0,0.07)',
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
    }}>
      {/* ── Tab strip header ── */}
      <div style={{
        padding: '12px 16px 0',
        borderBottom: '1px solid #E4E7F0',
        background: '#F7F8FC',
        borderRadius: '12px 12px 0 0',
        flexShrink: 0,
      }}>
        <div style={{
          display: 'flex',
          gap: '2px',
          padding: '4px',
          background: '#EEF0F6',
          borderRadius: '10px',
          marginBottom: '0',
          overflowX: 'auto',
        }} className="hide-scrollbar">
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                flex: '0 0 auto',
                padding: '7px 14px',
                fontSize: '12px',
                fontWeight: 600,
                color: activeTab === tab.id ? '#4F6BFF' : '#6B7A99',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer',
                whiteSpace: 'nowrap',
                letterSpacing: '0.2px',
                transition: 'all 0.15s ease',
                background: activeTab === tab.id
                  ? '#ffffff'
                  : 'transparent',
                boxShadow: activeTab === tab.id
                  ? '0 1px 3px rgba(0,0,0,0.09)'
                  : 'none',
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Tab content ── */}
      <div style={{
        flex: 1,
        overflowY: 'auto',
        padding: '20px 20px',
      }} className="smooth-scroll">

        {/* BASIC */}
        {activeTab === 'Basic' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <SectionLabel label="Email Details" />
            <div className="row g-3">
              <div className="col-12">
                <Input label="Email Subject" {...register('subject')} />
              </div>
              <div className="col-6">
                <Input label="Release Version" placeholder="e.g. 2.4.1" {...register('releaseVersion')} />
              </div>
              <div className="col-6">
                <Input label="Environment" placeholder="e.g. Production" {...register('environment')} />
              </div>
              <div className="col-12">
                <Input label="Release Date" type="date" {...register('releaseDate')} />
              </div>
            </div>

            <SectionLabel label="Banner" />
            <div className="row g-3">
              <div className="col-12">
                <Input label="Banner Title" placeholder="e.g. Production Release v2.4.1" {...register('bannerTitle')} />
              </div>
              <div className="col-12">
                <Textarea label="Banner Description" rows={2} placeholder="Short summary shown under the title..." {...register('bannerDescription')} />
              </div>
            </div>
          </div>
        )}

        {/* CONTENT */}
        {activeTab === 'Content' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            <SectionLabel label="Email Body" />

            <FieldWithSnippet label="Greeting" onSnippet={() => openSnippetModal('greeting')}>
              <Input placeholder="e.g. Hi Team," {...register('greeting')} />
            </FieldWithSnippet>

            <FieldWithSnippet label="Release Summary" hint="HTML supported" onSnippet={() => openSnippetModal('releaseSummary')}>
              <Textarea rows={5} placeholder="Describe the release changes..." {...register('releaseSummary')} />
            </FieldWithSnippet>

            <FieldWithSnippet label="Process / Release Items" hint="HTML supported" onSnippet={() => openSnippetModal('processItems')}>
              <Textarea rows={4} placeholder="List the release process steps..." {...register('processItems')} />
            </FieldWithSnippet>

            <FieldWithSnippet label="Additional Notes" hint="HTML supported" onSnippet={() => openSnippetModal('additionalNotes')}>
              <Textarea rows={3} placeholder="Any important notes or caveats..." {...register('additionalNotes')} />
            </FieldWithSnippet>

            <FieldWithSnippet label="Closing" onSnippet={() => openSnippetModal('closing')}>
              <Textarea rows={3} placeholder="e.g. Thanks & Regards,\nRelease Team" {...register('closing')} />
            </FieldWithSnippet>
          </div>
        )}

        {/* HIGHLIGHTS */}
        {activeTab === 'Highlights' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <SectionLabel label="Section Config" />
            <Input label="Section Title" {...register('highlightsTitle')} />
            <Input label="Section Description" {...register('highlightsDescription')} />

            <SectionLabel label="Cards (4 max)" />
            {highlightFields.map((field, index) => (
              <div key={field.id} style={{
                padding: '14px 16px',
                border: '1.5px solid #E4E7F0',
                borderRadius: '10px',
                background: '#F7F8FC',
                display: 'flex',
                flexDirection: 'column',
                gap: '10px',
              }}>
                <div style={{
                  fontSize: '11px',
                  fontWeight: 700,
                  color: '#4F6BFF',
                  letterSpacing: '0.5px',
                  textTransform: 'uppercase',
                }}>
                  Card {index + 1}
                </div>
                <Input placeholder="Card Title" {...register(`highlightCards.${index}.title`)} />
                <Textarea placeholder="Card Description" rows={2} {...register(`highlightCards.${index}.description`)} />
              </div>
            ))}
          </div>
        )}

        {/* WHAT'S NEXT */}
        {activeTab === 'Next' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <SectionLabel label="Section Config" />
            <Input label="Section Title" {...register('whatsNextTitle')} />
            <Input label="Section Description" {...register('whatsNextDescription')} />

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '4px' }}>
              <SectionLabel label="Bullet Points" inline />
              <Button size="sm" variant="outline-primary" onClick={() => appendBullet('')}>
                <FiPlus size={12} /> Add Bullet
              </Button>
            </div>

            {bulletFields.map((field, index) => (
              <div key={field.id} style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                <div style={{
                  width: '6px',
                  height: '6px',
                  borderRadius: '50%',
                  background: '#4F6BFF',
                  flexShrink: 0,
                  marginTop: '2px',
                }} />
                <Input
                  className="flex-grow-1"
                  placeholder="Bullet text..."
                  {...register(`whatsNextBullets.${index}` as never)}
                />
                <button
                  type="button"
                  onClick={() => removeBullet(index)}
                  style={{
                    width: '32px',
                    height: '32px',
                    border: '1px solid rgba(239,68,68,0.3)',
                    borderRadius: '7px',
                    background: 'transparent',
                    color: '#EF4444',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    flexShrink: 0,
                    transition: 'all 0.15s ease',
                  }}
                  onMouseEnter={e => {
                    (e.currentTarget as HTMLButtonElement).style.background = 'rgba(239,68,68,0.08)';
                  }}
                  onMouseLeave={e => {
                    (e.currentTarget as HTMLButtonElement).style.background = 'transparent';
                  }}
                >
                  <FiTrash2 size={13} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* LINKS */}
        {activeTab === 'Links' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <SectionLabel label="SharePoint Links" inline />
              <Button
                size="sm"
                variant="outline-primary"
                onClick={() => appendLink({ id: Date.now().toString(), label: '', url: '' })}
              >
                <FiPlus size={12} /> Add Link
              </Button>
            </div>

            {linkFields.length === 0 && (
              <div style={{
                textAlign: 'center',
                padding: '32px 20px',
                color: '#6B7A99',
                fontSize: '13px',
                border: '1.5px dashed #E4E7F0',
                borderRadius: '10px',
                background: '#F7F8FC',
              }}>
                No links yet — click <strong>Add Link</strong> to add SharePoint URLs.
              </div>
            )}

            {linkFields.map((field, index) => (
              <div key={field.id} style={{
                padding: '14px 16px',
                border: '1.5px solid #E4E7F0',
                borderRadius: '10px',
                background: '#F7F8FC',
                display: 'flex',
                flexDirection: 'column',
                gap: '10px',
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{
                    fontSize: '11px',
                    fontWeight: 700,
                    color: '#4F6BFF',
                    letterSpacing: '0.5px',
                    textTransform: 'uppercase',
                  }}>
                    Link {index + 1}
                  </span>
                  <button
                    type="button"
                    onClick={() => removeLink(index)}
                    style={{
                      background: 'none',
                      border: 'none',
                      color: '#EF4444',
                      cursor: 'pointer',
                      padding: '2px',
                      display: 'flex',
                    }}
                  >
                    <FiTrash2 size={14} />
                  </button>
                </div>
                <Input placeholder="Label (e.g. Release Notes)" {...register(`links.${index}.label`)} />
                <Input placeholder="SharePoint URL" {...register(`links.${index}.url`)} />
              </div>
            ))}
          </div>
        )}

        {/* BRAND */}
        {activeTab === 'Brand' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div style={{
              display: 'flex',
              alignItems: 'flex-start',
              gap: '10px',
              padding: '12px 14px',
              background: 'rgba(79,107,255,0.06)',
              border: '1px solid rgba(79,107,255,0.2)',
              borderRadius: '10px',
              fontSize: '12.5px',
              color: '#4F6BFF',
            }}>
              <FiInfo size={15} style={{ flexShrink: 0, marginTop: '1px' }} />
              <span>These override the global brand settings <strong>for this email only</strong>. Leave blank to use global defaults.</span>
            </div>
            <SectionLabel label="Per-Email Brand Overrides" />
            <Input
              label="Custom Banner Image URL"
              placeholder="Leave blank to use global default"
              {...register('bannerImageUrl')}
              helpText="PNG or JPG, 600×180px recommended"
            />
            <Input
              label="Custom Logo URL"
              placeholder="Leave blank to use global default"
              {...register('companyLogoUrl')}
              helpText="PNG or SVG, max 160×40px"
            />
          </div>
        )}
      </div>

      {/* Snippet Modal */}
      <Modal
        isOpen={snippetModalOpen}
        onClose={() => setSnippetModalOpen(false)}
        title="Insert Snippet"
        size="lg"
      >
        {snippets.length === 0 ? (
          <div style={{
            textAlign: 'center',
            padding: '40px 20px',
            color: '#6B7A99',
          }}>
            <FiBookOpen size={32} style={{ opacity: 0.4, marginBottom: '12px' }} />
            <p style={{ fontSize: '14px', margin: 0 }}>
              No snippets in your library yet.<br />
              Go to <strong>Snippets</strong> to create some.
            </p>
          </div>
        ) : (
          <div className="row g-3">
            {snippets.map(snippet => (
              <div className="col-6" key={snippet.id}>
                <div
                  className="snippet-card"
                  onClick={() => applySnippet(snippet.content)}
                >
                  <div style={{ fontWeight: 700, fontSize: '13px', color: '#0D1117', marginBottom: '4px' }}>
                    {snippet.title}
                  </div>
                  <span style={{
                    display: 'inline-block',
                    fontSize: '10px',
                    fontWeight: 600,
                    letterSpacing: '0.4px',
                    textTransform: 'uppercase',
                    color: '#4F6BFF',
                    background: 'rgba(79,107,255,0.1)',
                    padding: '2px 8px',
                    borderRadius: '99px',
                    marginBottom: '8px',
                  }}>
                    {snippet.category}
                  </span>
                  <p style={{
                    fontSize: '12px',
                    color: '#6B7A99',
                    margin: 0,
                    display: '-webkit-box',
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: 'vertical',
                    overflow: 'hidden',
                  }}>
                    {snippet.content}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </Modal>
    </div>
  );
};

// ── Reusable sub-components ──────────────────────────────

interface SectionLabelProps {
  label: string;
  inline?: boolean;
}

const SectionLabel = ({ label, inline }: SectionLabelProps) => (
  <div style={{
    display: inline ? 'inline-flex' : 'flex',
    alignItems: 'center',
    gap: '8px',
    fontSize: '11px',
    fontWeight: 700,
    color: '#6B7A99',
    letterSpacing: '0.6px',
    textTransform: 'uppercase',
  }}>
    {label}
    {!inline && (
      <div style={{ flex: 1, height: '1px', background: '#E4E7F0' }} />
    )}
  </div>
);

interface FieldWithSnippetProps {
  label: string;
  hint?: string;
  onSnippet: () => void;
  children: React.ReactNode;
}

const FieldWithSnippet = ({ label, hint, onSnippet, children }: FieldWithSnippetProps) => (
  <div>
    <div style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: '6px',
    }}>
      <label style={{
        fontSize: '12px',
        fontWeight: 600,
        color: '#6B7A99',
        letterSpacing: '0.2px',
        textTransform: 'uppercase',
        display: 'flex',
        alignItems: 'center',
        gap: '5px',
      }}>
        {label}
        {hint && (
          <span style={{
            fontSize: '10px',
            fontWeight: 500,
            color: '#4F6BFF',
            background: 'rgba(79,107,255,0.1)',
            padding: '1px 6px',
            borderRadius: '4px',
            textTransform: 'none',
          }}>
            {hint}
          </span>
        )}
      </label>
      <button
        type="button"
        onClick={onSnippet}
        style={{
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          fontSize: '11px',
          fontWeight: 600,
          color: '#4F6BFF',
          display: 'flex',
          alignItems: 'center',
          gap: '4px',
          padding: '2px 4px',
          borderRadius: '4px',
          transition: 'background 0.15s ease',
        }}
        onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(79,107,255,0.08)'; }}
        onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; }}
      >
        <FiBookOpen size={11} /> Snippets
      </button>
    </div>
    {children}
  </div>
);
