import React from 'react';
import type { MailContent, CardContent, LinkItem } from '@/types';
import { useSettings } from '@/app/SettingsContext';
import DOMPurify from 'dompurify';

interface EmailPreviewProps {
  content: Partial<MailContent>;
}

export const EmailPreview: React.FC<EmailPreviewProps> = ({ content }) => {
  const { settings } = useSettings();

  const brand = settings?.brand || {
    primaryColor: '#0052CC',
    logoUrl: '',
    bannerUrl: '',
    footerText: '',
    companyName: ''
  };

  // Sanitize HTML input (allow safe tags for email content)
  const createMarkup = (html: string) => ({
    __html: DOMPurify.sanitize(html.replace(/\n/g, '<br/>'), {
      ALLOWED_TAGS: ['p', 'br', 'b', 'i', 'u', 'strong', 'em', 'ul', 'ol', 'li', 'a', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'span', 'table', 'tr', 'td', 'th', 'thead', 'tbody'],
      ALLOWED_ATTR: ['href', 'target', 'style', 'class', 'rel']
    })
  });

  const currentBannerUrl = content.bannerImageUrl || brand.bannerUrl;
  const currentLogoUrl = content.companyLogoUrl || brand.logoUrl;

  return (
    <div className="email-preview-container bg-light border rounded shadow-sm overflow-auto h-100 p-3">
      {/*
        data-email-root is the anchor used by Toolbar.tsx to grab the email HTML for copying.
        All inline styles are intentionally written for maximum email client compatibility (Outlook).
      */}
      <div
        data-email-root
        style={{
          maxWidth: '600px',
          margin: '0 auto',
          backgroundColor: '#ffffff',
          border: '1px solid #eaeaea',
          borderRadius: '8px',
          overflow: 'hidden',
          fontFamily: 'Arial, Helvetica, sans-serif',
          color: '#333333',
          fontSize: '15px',
          lineHeight: '1.6'
        }}
      >
        {/* Banner Image */}
        {currentBannerUrl && (
          <div style={{ width: '100%', height: '180px', backgroundColor: brand.primaryColor, backgroundImage: `url(${currentBannerUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
        )}

        {/* No banner — show colored header bar */}
        {!currentBannerUrl && (
          <div style={{ width: '100%', height: '8px', backgroundColor: brand.primaryColor }} />
        )}

        {/* Email Body */}
        <div style={{ padding: '30px' }}>

          {/* Header Row: Logo + Version/Env */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '2px solid #eaeaea', paddingBottom: '20px', marginBottom: '20px' }}>
            <div>
              {currentLogoUrl
                ? <img src={currentLogoUrl} alt="Company Logo" style={{ maxHeight: '40px', maxWidth: '160px' }} />
                : <span style={{ fontSize: '18px', fontWeight: 'bold', color: brand.primaryColor }}>{brand.companyName || 'Company'}</span>
              }
            </div>
            <div style={{ textAlign: 'right' }}>
              {content.environment && (
                <div style={{ fontSize: '11px', color: '#888888', textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: '1px' }}>
                  {content.environment} Environment
                </div>
              )}
              {content.releaseDate && (
                <div style={{ fontSize: '12px', color: '#aaaaaa' }}>{content.releaseDate}</div>
              )}
              <div style={{ fontSize: '14px', fontWeight: 'bold', color: brand.primaryColor, marginTop: '2px' }}>
                Version: {content.releaseVersion || 'X.X.X'}
              </div>
            </div>
          </div>

          {/* Banner Title & Description */}
          <div style={{ marginBottom: '30px', textAlign: 'center' }}>
            <h1 style={{ fontSize: '26px', color: brand.primaryColor, margin: '0 0 12px 0', fontWeight: 'bold' }}>
              {content.bannerTitle || 'Release Notes'}
            </h1>
            {content.bannerDescription && (
              <p style={{ margin: '0', color: '#555555', fontSize: '16px' }}>{content.bannerDescription}</p>
            )}
          </div>

          {/* Greeting */}
          {content.greeting && (
            <p style={{ fontWeight: 'bold', marginBottom: '15px', fontSize: '15px' }}>{content.greeting}</p>
          )}

          {/* Release Summary */}
          {content.releaseSummary && (
            <div style={{ marginBottom: '25px' }} dangerouslySetInnerHTML={createMarkup(content.releaseSummary)} />
          )}

          {/* Process / Release Items */}
          {content.processItems && (
            <div style={{ marginBottom: '25px', padding: '15px 20px', backgroundColor: '#f9f9f9', borderRadius: '6px', borderLeft: `4px solid ${brand.primaryColor}` }}>
              <h3 style={{ fontSize: '15px', margin: '0 0 10px 0', color: '#333333', fontWeight: 'bold' }}>Release Process</h3>
              <div dangerouslySetInnerHTML={createMarkup(content.processItems)} />
            </div>
          )}

          {/* Highlight Cards */}
          {content.highlightCards && content.highlightCards.some((c: CardContent) => c.title) && (
            <div style={{ marginBottom: '30px' }}>
              <h2 style={{ fontSize: '20px', borderBottom: '1px solid #eaeaea', paddingBottom: '10px', color: brand.primaryColor, fontWeight: 'bold' }}>
                {content.highlightsTitle || 'Release Highlights'}
              </h2>
              {content.highlightsDescription && (
                <p style={{ marginBottom: '20px', color: '#555' }}>{content.highlightsDescription}</p>
              )}
              {/* 2-column table layout for Outlook compat */}
              <table cellPadding={0} cellSpacing={0} style={{ width: '100%', borderCollapse: 'collapse' }}>
                <tbody>
                  {Array.from({ length: Math.ceil((content.highlightCards?.length || 0) / 2) }).map((_, rowIdx) => (
                    <tr key={rowIdx}>
                      {[0, 1].map((colIdx) => {
                        const card: CardContent | undefined = content.highlightCards?.[rowIdx * 2 + colIdx];
                        return card ? (
                          <td key={colIdx} style={{ width: '50%', padding: '6px', verticalAlign: 'top' }}>
                            <div style={{ backgroundColor: '#ffffff', border: '1px solid #eaeaea', padding: '15px', borderRadius: '6px', borderTop: `3px solid ${brand.primaryColor}` }}>
                              <h4 style={{ margin: '0 0 8px 0', color: brand.primaryColor, fontSize: '15px', fontWeight: 'bold' }}>
                                {card.title || 'Feature'}
                              </h4>
                              <p style={{ margin: 0, fontSize: '13px', color: '#666666' }}>
                                {card.description || ''}
                              </p>
                            </div>
                          </td>
                        ) : (
                          <td key={colIdx} style={{ width: '50%', padding: '6px' }} />
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* What's Next */}
          {content.whatsNextBullets && content.whatsNextBullets.some((b: string) => b.trim()) && (
            <div style={{ marginBottom: '25px' }}>
              <h2 style={{ fontSize: '20px', borderBottom: '1px solid #eaeaea', paddingBottom: '10px', color: brand.primaryColor, fontWeight: 'bold' }}>
                {content.whatsNextTitle || "What's Next?"}
              </h2>
              {content.whatsNextDescription && (
                <p style={{ color: '#555' }}>{content.whatsNextDescription}</p>
              )}
              <ul style={{ paddingLeft: '20px', margin: '10px 0 0 0' }}>
                {content.whatsNextBullets.filter((b: string) => b.trim()).map((bullet: string, idx: number) => (
                  <li key={idx} style={{ marginBottom: '8px', color: '#333' }}>{bullet}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Additional Notes */}
          {content.additionalNotes && (
            <div style={{ marginBottom: '25px', padding: '12px 16px', backgroundColor: '#fffbeb', border: '1px solid #fde68a', borderRadius: '6px' }}>
              <h3 style={{ fontSize: '14px', margin: '0 0 8px 0', color: '#92400e', fontWeight: 'bold' }}>📌 Additional Notes</h3>
              <div dangerouslySetInnerHTML={createMarkup(content.additionalNotes)} />
            </div>
          )}

          {/* SharePoint Links */}
          {content.links && content.links.length > 0 && content.links.some((l: LinkItem) => l.label && l.url) && (
            <div style={{ marginBottom: '25px', textAlign: 'center' }}>
              <h3 style={{ fontSize: '15px', color: '#333', marginBottom: '12px', fontWeight: 'bold' }}>📎 Resources & Links</h3>
              <div>
                {content.links.filter((l: LinkItem) => l.label && l.url).map((link: LinkItem) => (
                  <a
                    key={link.id}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      display: 'inline-block',
                      padding: '10px 20px',
                      margin: '5px',
                      backgroundColor: brand.primaryColor,
                      color: '#ffffff',
                      textDecoration: 'none',
                      borderRadius: '4px',
                      fontWeight: 'bold',
                      fontSize: '14px'
                    }}
                  >
                    {link.label}
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Closing */}
          {content.closing && (
            <div style={{ marginTop: '30px', paddingTop: '20px', borderTop: '1px solid #eaeaea' }}>
              <div dangerouslySetInnerHTML={createMarkup(content.closing)} />
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{ backgroundColor: '#f4f5f7', padding: '20px', textAlign: 'center', fontSize: '12px', color: '#888888', borderTop: '1px solid #eaeaea' }}>
          {brand.footerText || `${brand.companyName || 'Release Team'} · This email was auto-generated by the Release Mailer Tool.`}
        </div>
      </div>
    </div>
  );
};
