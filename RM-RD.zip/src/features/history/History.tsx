import { useState, useEffect, useMemo } from 'react';
import { historyService } from '@/services/storage';
import type { HistoryRecord } from '@/types';
import { Card, CardBody } from '@/components/ui/Card';
import { FiTrash2, FiEdit3 } from 'react-icons/fi';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';

export default function History() {
  const [history, setHistory] = useState<HistoryRecord[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    const data = await historyService.getAll();
    setHistory(data.sort((a: HistoryRecord, b: HistoryRecord) => b.updatedAt - a.updatedAt));
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this record?')) {
      await historyService.delete(id);
      toast.success('Record deleted');
      loadHistory();
    }
  };

  const handleEdit = (id: string) => {
    navigate(`/?history=${id}`);
  };

  const KPIs = useMemo(() => {
    const generated = history.filter(h => h.status === 'Generated');
    const totalCopies = history.reduce((acc, curr) => acc + curr.copiedCount, 0);
    const draftsCount = history.filter(h => h.status === 'Draft').length; // Some might be saved as drafts here, though we have a separate Drafts module.
    
    // Most used template
    const templateCounts = history.reduce((acc, curr) => {
      acc[curr.templateName] = (acc[curr.templateName] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    const topTemplate = Object.entries(templateCounts).sort((a: [string, number], b: [string, number]) => b[1] - a[1])[0]?.[0] || 'N/A';

    return {
      emailsCreated: generated.length,
      contentCopied: totalCopies,
      draftsSaved: draftsCount,
      topTemplate
    };
  }, [history]);

  return (
    <div className="container-fluid max-w-1200 mx-auto">
      <div className="mb-4">
        <h2 className="m-0 fw-bold">Email History & KPIs</h2>
        <p className="text-secondary">Track the performance and usage of your release emails.</p>
      </div>

      <div className="row g-4 mb-5">
        <div className="col-12 col-sm-6 col-xl-3">
          <Card className="h-100 bg-primary text-white">
            <CardBody>
              <h6 className="text-white-50 text-uppercase fw-bold mb-2">Emails Created</h6>
              <h2 className="m-0 display-5 fw-bold">{KPIs.emailsCreated}</h2>
            </CardBody>
          </Card>
        </div>
        <div className="col-12 col-sm-6 col-xl-3">
          <Card className="h-100">
            <CardBody>
              <h6 className="text-secondary text-uppercase fw-bold mb-2">Content Copied</h6>
              <h2 className="m-0 display-5 fw-bold text-dark">{KPIs.contentCopied}</h2>
            </CardBody>
          </Card>
        </div>
        <div className="col-12 col-sm-6 col-xl-3">
          <Card className="h-100">
            <CardBody>
              <h6 className="text-secondary text-uppercase fw-bold mb-2">Top Template</h6>
              <h2 className="m-0 h4 fw-bold text-dark mt-3">{KPIs.topTemplate}</h2>
            </CardBody>
          </Card>
        </div>
        <div className="col-12 col-sm-6 col-xl-3">
          <Card className="h-100">
            <CardBody>
              <h6 className="text-secondary text-uppercase fw-bold mb-2">Drafts Saved</h6>
              <h2 className="m-0 display-5 fw-bold text-dark">{KPIs.draftsSaved}</h2>
            </CardBody>
          </Card>
        </div>
      </div>

      <Card>
        <CardBody className="p-0">
          <div className="table-responsive">
            <table className="table table-hover align-middle mb-0">
              <thead className="table-light">
                <tr>
                  <th className="px-4 py-3 text-uppercase text-secondary small fw-bold">Subject / Version</th>
                  <th className="px-4 py-3 text-uppercase text-secondary small fw-bold">Template</th>
                  <th className="px-4 py-3 text-uppercase text-secondary small fw-bold">Status</th>
                  <th className="px-4 py-3 text-uppercase text-secondary small fw-bold">Last Modified</th>
                  <th className="px-4 py-3 text-uppercase text-secondary small fw-bold">Copied Count</th>
                  <th className="px-4 py-3 text-uppercase text-secondary small fw-bold text-end">Actions</th>
                </tr>
              </thead>
              <tbody>
                {history.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-5 text-muted">
                      No history found. Generate some emails to see them here.
                    </td>
                  </tr>
                ) : (
                  history.map(record => (
                    <tr key={record.id}>
                      <td className="px-4 py-3">
                        <div className="fw-bold">{record.subject}</div>
                        <div className="text-secondary small">v{record.releaseVersion}</div>
                      </td>
                      <td className="px-4 py-3">{record.templateName}</td>
                      <td className="px-4 py-3">
                        <span className={`badge rounded-pill ${record.status === 'Generated' ? 'bg-success' : 'bg-warning text-dark'}`}>
                          {record.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-secondary small">
                        {new Date(record.updatedAt).toLocaleString()}
                      </td>
                      <td className="px-4 py-3">
                        {record.copiedCount} times
                      </td>
                      <td className="px-4 py-3 text-end">
                        <div className="d-flex justify-content-end gap-2">
                          <button className="btn btn-sm btn-light text-secondary" onClick={() => handleEdit(record.id)} title="Edit">
                            <FiEdit3 />
                          </button>
                          <button className="btn btn-sm btn-light text-danger" onClick={() => handleDelete(record.id)} title="Delete">
                            <FiTrash2 />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
