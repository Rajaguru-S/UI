import { useState, useEffect } from 'react';
import { templateService } from '@/services/storage';
import type { Template } from '@/types';
import { defaultTemplates } from './defaultTemplates';
import { Card, CardHeader, CardBody } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { FiCopy, FiTrash2, FiPlay } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { v4 as uuidv4 } from 'uuid';

export default function Templates() {
  const [templates, setTemplates] = useState<Template[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    const data = await templateService.getAll();
    if (data.length === 0) {
      // Seed default templates
      for (const t of defaultTemplates) {
        await templateService.save(t);
      }
      setTemplates(defaultTemplates);
    } else {
      setTemplates(data.sort((a: Template, b: Template) => b.updatedAt - a.updatedAt));
    }
  };

  const handleDuplicate = async (template: Template) => {
    const newTemplate: Template = {
      ...template,
      id: uuidv4(),
      name: `${template.name} (Copy)`,
      isDefault: false,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    await templateService.save(newTemplate);
    toast.success('Template duplicated');
    loadTemplates();
  };

  const handleDelete = async (id: string, isDefault?: boolean) => {
    if (isDefault) {
      toast.error('Cannot delete default template');
      return;
    }
    if (confirm('Are you sure you want to delete this template?')) {
      await templateService.delete(id);
      toast.success('Template deleted');
      loadTemplates();
    }
  };

  const handleUseTemplate = (id: string) => {
    navigate(`/?template=${id}`);
  };

  return (
    <div className="container-fluid max-w-1200 mx-auto">
      <div className="d-flex align-items-center justify-content-between mb-4">
        <h2 className="m-0 fw-bold">Templates</h2>
        {/* Creating a new blank template would just route to builder without ID */}
        <Button onClick={() => navigate('/')}>
          Create New Email
        </Button>
      </div>

      <div className="row g-4">
        {templates.map(template => (
          <div className="col-12 col-md-6 col-xl-4" key={template.id}>
            <Card className="h-100 d-flex flex-column">
              <CardHeader>
                <div className="d-flex justify-content-between align-items-start">
                  <h5 className="fw-bold mb-1">{template.name}</h5>
                  {template.isDefault && <span className="badge bg-primary rounded-pill">Default</span>}
                </div>
                <p className="text-secondary small mb-0">{template.type}</p>
              </CardHeader>
              <CardBody className="flex-grow-1">
                <p className="text-secondary small">
                  {template.description || 'No description provided.'}
                </p>
              </CardBody>
              <div className="card-footer bg-white border-top-0 pt-0 pb-4 px-4 d-flex justify-content-between align-items-center gap-2">
                <Button size="sm" variant="outline-primary" onClick={() => handleUseTemplate(template.id)} className="flex-grow-1">
                  <FiPlay /> Use Template
                </Button>
                <div className="d-flex gap-2">
                  <button className="btn btn-sm btn-light text-secondary" onClick={() => handleDuplicate(template)} title="Duplicate">
                    <FiCopy />
                  </button>
                  {!template.isDefault && (
                    <button className="btn btn-sm btn-light text-danger" onClick={() => handleDelete(template.id, template.isDefault)} title="Delete">
                      <FiTrash2 />
                    </button>
                  )}
                </div>
              </div>
            </Card>
          </div>
        ))}
      </div>
    </div>
  );
}
