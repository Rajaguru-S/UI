import type { Template } from '@/types';

export const defaultTemplates: Template[] = [
  {
    id: 'default-release-notes',
    name: 'Standard Release Notes',
    type: 'Release Notes',
    description: 'A standard template for major and minor feature releases.',
    isDefault: true,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    content: {
      subject: 'Release Notes: v',
      releaseVersion: '1.0.0',
      releaseDate: new Date().toISOString().split('T')[0],
      environment: 'Production',
      bannerTitle: 'New Release Updates',
      bannerDescription: 'Check out the latest features, improvements, and bug fixes in this release.',
      greeting: 'Hello Team,',
      releaseSummary: 'We are excited to announce the deployment of our latest release. This version brings significant improvements to our platform.',
      processItems: 'The deployment process has been completed successfully across all regions.',
      additionalNotes: 'If you experience any issues, please contact the support team immediately.',
      closing: 'Best regards,\nThe Release Management Team',
      highlightsTitle: 'Release Highlights',
      highlightsDescription: 'Key features included in this release.',
      highlightCards: [
        { id: '1', title: 'Performance Boost', description: 'Faster loading times across the application.' },
        { id: '2', title: 'New Dashboard', description: 'Redesigned analytics dashboard for better insights.' },
        { id: '3', title: 'Security Patch', description: 'Critical security updates applied.' },
        { id: '4', title: 'Bug Fixes', description: 'Resolved multiple customer-reported bugs.' }
      ],
      whatsNextTitle: 'What\'s Next?',
      whatsNextDescription: 'Here is what we are working on for the next release:',
      whatsNextBullets: [
        'Integration with third-party authentication providers',
        'Mobile app enhancements',
        'Advanced reporting capabilities'
      ],
      links: [
        { id: 'link-1', label: 'Detailed Release Notes', url: 'https://sharepoint.com/notes' },
        { id: 'link-2', label: 'User Manual', url: 'https://sharepoint.com/manual' }
      ]
    }
  },
  {
    id: 'default-hotfix',
    name: 'Emergency Hotfix',
    type: 'Hotfix',
    description: 'Template for urgent bug fixes and emergency patches.',
    isDefault: true,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    content: {
      subject: 'HOTFIX DEPLOYMENT: v',
      releaseVersion: '1.0.1-hotfix',
      releaseDate: new Date().toISOString().split('T')[0],
      environment: 'Production',
      bannerTitle: 'Emergency Hotfix Deployed',
      bannerDescription: 'A critical issue has been resolved in the production environment.',
      greeting: 'Team,',
      releaseSummary: 'This is to inform you that an emergency hotfix has been successfully deployed to address a critical system error.',
      processItems: 'All systems have been verified and are operating normally.',
      additionalNotes: 'No further action is required from end-users.',
      closing: 'Thanks,\nThe Release Management Team',
      highlightsTitle: 'Issue Resolved',
      highlightsDescription: 'Details of the fix applied in this patch.',
      highlightCards: [
        { id: '1', title: 'Root Cause', description: 'Memory leak in the background processing job.' },
        { id: '2', title: 'Impact', description: 'System performance degradation for 15 minutes.' },
        { id: '3', title: 'Resolution', description: 'Optimized memory usage and restarted services.' },
        { id: '4', title: 'Monitoring', description: 'Enhanced alerting configured for this issue.' }
      ],
      whatsNextTitle: 'Post-Incident Review',
      whatsNextDescription: 'Next steps following this hotfix:',
      whatsNextBullets: [
        'Conduct a thorough RCA (Root Cause Analysis)',
        'Update runbooks for faster mitigation'
      ],
      links: [
        { id: 'link-1', label: 'Incident Report', url: 'https://sharepoint.com/incident' }
      ]
    }
  }
];
