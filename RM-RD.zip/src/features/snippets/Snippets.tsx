import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { snippetService } from '@/services/storage';
import type { Snippet, SnippetCategory } from '@/types';
import { Card, CardHeader, CardBody } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input, Textarea } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { FiPlus, FiEdit2, FiTrash2 } from 'react-icons/fi';
import toast from 'react-hot-toast';
import { v4 as uuidv4 } from 'uuid';
import clsx from 'clsx';

const categories: SnippetCategory[] = [
  'Greetings', 'Release Summary', 'Release Highlights', 
  'What\'s Next', 'Support', 'Closing', 'Important Notes'
];

export default function Snippets() {
  const [snippets, setSnippets] = useState<Snippet[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSnippet, setEditingSnippet] = useState<Snippet | null>(null);
  const [activeCategory, setActiveCategory] = useState<SnippetCategory | 'All'>('All');

  const { register, handleSubmit, reset, formState: { errors } } = useForm<Snippet>();

  useEffect(() => {
    loadSnippets();
  }, []);

  const loadSnippets = async () => {
    const data = await snippetService.getAll();
    setSnippets(data.sort((a: Snippet, b: Snippet) => b.updatedAt - a.updatedAt));
  };

  const openModal = (snippet?: Snippet) => {
    if (snippet) {
      setEditingSnippet(snippet);
      reset(snippet);
    } else {
      setEditingSnippet(null);
      reset({ title: '', content: '', category: 'Greetings' });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    reset();
  };

  const onSubmit = async (data: Snippet) => {
    try {
      if (editingSnippet) {
        await snippetService.save({ ...editingSnippet, ...data, updatedAt: Date.now() });
        toast.success('Snippet updated');
      } else {
        await snippetService.save({
          ...data,
          id: uuidv4(),
          createdAt: Date.now(),
          updatedAt: Date.now()
        });
        toast.success('Snippet created');
      }
      closeModal();
      loadSnippets();
    } catch (err) {
      toast.error('Failed to save snippet');
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this snippet?')) {
      await snippetService.delete(id);
      toast.success('Snippet deleted');
      loadSnippets();
    }
  };

  const filteredSnippets = activeCategory === 'All' ? snippets : snippets.filter(s => s.category === activeCategory);

  return (
    <div className="container-fluid max-w-1200 mx-auto h-100 d-flex flex-column">
      <div className="d-flex align-items-center justify-content-between mb-4">
        <h2 className="m-0 fw-bold">Snippets Library</h2>
        <Button onClick={() => openModal()} leftIcon={<FiPlus />}>
          Create Snippet
        </Button>
      </div>

      <div className="row flex-grow-1 overflow-hidden">
        <div className="col-3 h-100 overflow-y-auto pe-3 border-end">
          <ul className="nav nav-pills flex-column gap-2">
            <li className="nav-item">
              <button 
                className={clsx('nav-link w-100 text-start', activeCategory === 'All' && 'active')}
                onClick={() => setActiveCategory('All')}
              >
                All Categories
              </button>
            </li>
            {categories.map(cat => (
              <li className="nav-item" key={cat}>
                <button 
                  className={clsx('nav-link w-100 text-start', activeCategory === cat && 'active')}
                  onClick={() => setActiveCategory(cat)}
                >
                  {cat}
                </button>
              </li>
            ))}
          </ul>
        </div>
        
        <div className="col-9 h-100 overflow-y-auto px-4 pb-4">
          {filteredSnippets.length === 0 ? (
            <div className="text-center py-5 text-muted">
              <p>No snippets found.</p>
            </div>
          ) : (
            <div className="row g-4">
              {filteredSnippets.map(snippet => (
                <div className="col-12 col-xl-6" key={snippet.id}>
                  <Card className="h-100">
                    <CardHeader className="d-flex justify-content-between align-items-start">
                      <div>
                        <h6 className="fw-bold mb-1">{snippet.title}</h6>
                        <span className="badge bg-light text-secondary">{snippet.category}</span>
                      </div>
                      <div className="d-flex gap-2">
                        <button className="btn btn-sm btn-light text-secondary" onClick={() => openModal(snippet)}>
                          <FiEdit2 />
                        </button>
                        <button className="btn btn-sm btn-light text-danger" onClick={() => handleDelete(snippet.id)}>
                          <FiTrash2 />
                        </button>
                      </div>
                    </CardHeader>
                    <CardBody>
                      <p className="text-secondary small mb-0 text-truncate" style={{ display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', whiteSpace: 'normal' }}>
                        {snippet.content}
                      </p>
                    </CardBody>
                  </Card>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <Modal isOpen={isModalOpen} onClose={closeModal} title={editingSnippet ? 'Edit Snippet' : 'New Snippet'}>
        <form id="snippetForm" onSubmit={handleSubmit(onSubmit)}>
          <Input 
            label="Title" 
            {...register('title', { required: 'Title is required' })} 
            error={errors.title}
          />
          <div className="mb-3">
            <label className="form-label fw-medium text-secondary small mb-1">Category</label>
            <select className={clsx('form-select', { 'is-invalid': !!errors.category })} {...register('category', { required: 'Category is required' })}>
              {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
            </select>
            {errors.category && <div className="invalid-feedback d-block">{errors.category.message}</div>}
          </div>
          <Textarea 
            label="Content" 
            rows={5} 
            {...register('content', { required: 'Content is required' })} 
            error={errors.content}
          />
        </form>
        <div className="d-flex justify-content-end gap-2 mt-4">
          <Button variant="light" onClick={closeModal}>Cancel</Button>
          <Button type="submit" form="snippetForm">Save</Button>
        </div>
      </Modal>
    </div>
  );
}
