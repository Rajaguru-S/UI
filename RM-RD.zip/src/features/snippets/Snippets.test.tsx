import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Snippets from './Snippets';
import { snippetService } from '@/services/storage';

// Mock the storage service
vi.mock('@/services/storage', () => ({
  snippetService: {
    getAll: vi.fn(),
    save: vi.fn(),
    delete: vi.fn()
  }
}));

describe('Snippets Module', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    (snippetService.getAll as any).mockResolvedValue([
      { id: '1', title: 'Standard Greeting', category: 'Greetings', content: 'Hello team,', updatedAt: 1000 },
      { id: '2', title: 'Bug Fixes Header', category: 'Release Highlights', content: 'We fixed some bugs.', updatedAt: 2000 }
    ]);
  });

  it('renders snippets from storage', async () => {
    render(<Snippets />);
    
    expect(screen.getByText('Snippets Library')).toBeInTheDocument();
    
    // Wait for async load
    await waitFor(() => {
      expect(screen.getByText('Standard Greeting')).toBeInTheDocument();
      expect(screen.getByText('Bug Fixes Header')).toBeInTheDocument();
    });
  });

  it('filters snippets by category', async () => {
    render(<Snippets />);
    
    await waitFor(() => {
      expect(screen.getByText('Standard Greeting')).toBeInTheDocument();
    });

    // Click 'Greetings' filter
    const greetingsTab = screen.getByRole('button', { name: 'Greetings' });
    await userEvent.click(greetingsTab);

    expect(screen.getByText('Standard Greeting')).toBeInTheDocument();
    expect(screen.queryByText('Bug Fixes Header')).not.toBeInTheDocument();
  });

  it('opens modal to create new snippet', async () => {
    render(<Snippets />);
    
    const createBtn = screen.getByRole('button', { name: /create snippet/i });
    await userEvent.click(createBtn);

    expect(screen.getByText('New Snippet')).toBeInTheDocument();
    expect(screen.getByRole('textbox', { name: /title/i })).toBeInTheDocument();
  });
});
