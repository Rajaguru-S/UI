import { useState, useEffect } from 'react';
import { draftService } from '@/services/storage';
import type { Draft } from '@/types';
import { Card, CardHeader, CardBody } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { FiCopy, FiTrash2, FiEdit3 } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { v4 as uuidv4 } from 'uuid';

export default function Drafts() {
  const [drafts, setDrafts] = useState<Draft[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    loadDrafts();
  }, []);

  const loadDrafts = async () => {
    const data = await draftService.getAll();
    setDrafts(data.sort((a: Draft, b: Draft) => b.updatedAt - a.updatedAt));
  };

  const handleDuplicate = async (draft: Draft) => {
    const newDraft: Draft = {
      ...draft,
      id: uuidv4(),
      name: `${draft.name} (Copy)`,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    await draftService.save(newDraft);
    toast.success('Draft duplicated');
    loadDrafts();
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this draft?')) {
      await draftService.delete(id);
      toast.success('Draft deleted');
      loadDrafts();
    }
  };

  const handleResume = (id: string) => {
    navigate(`/?draft=${id}`);
  };

  return (
    <div className="container-fluid max-w-1200 mx-auto">
      <div className="d-flex align-items-center justify-content-between mb-4">
        <h2 className="m-0 fw-bold">My Drafts</h2>
      </div>

      {drafts.length === 0 ? (
        <div className="text-center py-5 mt-5">
          <FiEdit3 size={48} className="text-muted mb-3" />
          <h5 className="text-muted fw-bold">No drafts found</h5>
          <p className="text-secondary">Your saved works-in-progress will appear here.</p>
          <Button onClick={() => navigate('/')}>Create New Email</Button>
        </div>
      ) : (
        <div className="row g-4">
          {drafts.map(draft => (
            <div className="col-12 col-md-6 col-xl-4" key={draft.id}>
              <Card className="h-100 d-flex flex-column">
                <CardHeader>
                  <h5 className="fw-bold mb-1">{draft.name || draft.content.subject}</h5>
                  <p className="text-secondary small mb-0">Last updated: {new Date(draft.updatedAt).toLocaleString()}</p>
                </CardHeader>
                <CardBody className="flex-grow-1">
                  <p className="text-secondary small mb-1">
                    <strong>Template:</strong> {draft.templateId ? 'Custom / From Template' : 'Blank'}
                  </p>
                  <p className="text-secondary small mb-0">
                    <strong>Version:</strong> {draft.content.releaseVersion} | <strong>Env:</strong> {draft.content.environment}
                  </p>
                </CardBody>
                <div className="card-footer bg-white border-top-0 pt-0 pb-4 px-4 d-flex justify-content-between align-items-center gap-2">
                  <Button size="sm" variant="primary" onClick={() => handleResume(draft.id)} className="flex-grow-1">
                    <FiEdit3 /> Resume Draft
                  </Button>
                  <div className="d-flex gap-2">
                    <button className="btn btn-sm btn-light text-secondary" onClick={() => handleDuplicate(draft)} title="Duplicate">
                      <FiCopy />
                    </button>
                    <button className="btn btn-sm btn-light text-danger" onClick={() => handleDelete(draft.id)} title="Delete">
                      <FiTrash2 />
                    </button>
                  </div>
                </div>
              </Card>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
