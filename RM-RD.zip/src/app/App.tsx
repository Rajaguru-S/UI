import { Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import Layout from '@/components/layout/Layout'
import Settings from '@/features/settings/Settings'
import Snippets from '@/features/snippets/Snippets'
import Templates from '@/features/templates/Templates'
import History from '@/features/history/History'
import Drafts from '@/features/drafts/Drafts'
import Builder from '@/features/builder/Builder'

export default function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Builder />} />
          <Route path="templates" element={<Templates />} />
          <Route path="history" element={<History />} />
          <Route path="drafts" element={<Drafts />} />
          <Route path="snippets" element={<Snippets />} />
          <Route path="settings" element={<Settings />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
      <Toaster position="bottom-right" />
    </>
  )
}
