import React, { createContext, useContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import type { AppSettings } from '@/types';
import { settingsService } from '@/services/storage';

interface SettingsContextType {
  settings: AppSettings | null;
  updateSettings: (newSettings: Partial<AppSettings>) => Promise<void>;
  isLoading: boolean;
}

// Inline SVG data URIs — no external service dependency, always renders
const DEFAULT_LOGO_SVG = `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" width="150" height="50" viewBox="0 0 150 50">
  <rect width="150" height="50" rx="6" fill="#0052CC"/>
  <text x="75" y="32" font-family="Arial,sans-serif" font-size="16" font-weight="bold" fill="white" text-anchor="middle">Acme Corp</text>
</svg>
`)}`;

const DEFAULT_BANNER_SVG = `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" width="800" height="200" viewBox="0 0 800 200">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0052CC"/>
      <stop offset="100%" stop-color="#0747A6"/>
    </linearGradient>
  </defs>
  <rect width="800" height="200" fill="url(#bg)"/>
  <text x="400" y="90" font-family="Arial,sans-serif" font-size="36" font-weight="bold" fill="white" text-anchor="middle">Release Notes</text>
  <text x="400" y="135" font-family="Arial,sans-serif" font-size="18" fill="rgba(255,255,255,0.75)" text-anchor="middle">Powered by Release Mailer</text>
</svg>
`)}`;

const defaultSettings: AppSettings = {
  brand: {
    companyName: 'Acme Corp',
    logoUrl: DEFAULT_LOGO_SVG,
    bannerUrl: DEFAULT_BANNER_SVG,
    footerText: '© 2026 Acme Corp. All rights reserved.',
    primaryColor: '#0052CC',
  },
  defaults: {
    greeting: 'Hello Team,',
    closing: 'Best regards,\nThe Release Management Team',
    environment: 'Production',
    subject: 'Release Notes: v',
  },
  draft: {
    autoSave: true,
    saveInterval: 30,
  },
  copy: {
    copyHtml: true,
    copyInlineCss: true,
    minifyHtml: false,
  }
};

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadSettings = async () => {
      try {
        const stored = await settingsService.getSettings();
        if (stored) {
          // Migrate any stale via.placeholder.com URLs to SVG data URIs
          const migratedSettings = { ...stored };
          if (stored.brand.logoUrl?.includes('via.placeholder.com')) {
            migratedSettings.brand = { ...stored.brand, logoUrl: DEFAULT_LOGO_SVG };
          }
          if (stored.brand.bannerUrl?.includes('via.placeholder.com')) {
            migratedSettings.brand = { ...migratedSettings.brand, bannerUrl: DEFAULT_BANNER_SVG };
          }
          setSettings(migratedSettings);
        } else {
          await settingsService.saveSettings(defaultSettings);
          setSettings(defaultSettings);
        }
      } catch (error) {
        console.error('Failed to load settings', error);
      } finally {
        setIsLoading(false);
      }
    };
    loadSettings();
  }, []);

  const updateSettings = async (newSettings: Partial<AppSettings>) => {
    if (!settings) return;
    const merged = { ...settings, ...newSettings };
    setSettings(merged);
    await settingsService.saveSettings(merged);
  };

  return (
    <SettingsContext.Provider value={{ settings, updateSettings, isLoading }}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
