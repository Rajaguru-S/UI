export type TemplateType = 'Release Notes' | 'Hotfix' | 'Maintenance' | 'Security Patch' | 'General Announcement' | 'Custom';

export interface CardContent {
  id: string;
  title: string;
  description: string;
}

export interface LinkContent {
  id: string;
  label: string;
  url: string; // SharePoint URL
}

// Alias used in EmailPreview
export type LinkItem = LinkContent;

export interface MailContent {
  subject: string;
  releaseVersion: string;
  releaseDate: string;
  environment: string;
  bannerTitle: string;
  bannerDescription: string;
  greeting: string;
  releaseSummary: string;
  processItems: string;
  additionalNotes: string;
  closing: string;
  
  // Release Highlights Section
  highlightsTitle: string;
  highlightsDescription: string;
  highlightCards: CardContent[]; // Exactly four cards
  
  // What's Next Section
  whatsNextTitle: string;
  whatsNextDescription: string;
  whatsNextBullets: string[];
  
  // Links Section
  links: LinkContent[];
  
  // Branding (Usually injected from settings, but can be customized per mail)
  bannerImageUrl?: string;
  companyLogoUrl?: string;
}

export interface Template {
  id: string;
  name: string;
  type: TemplateType;
  description?: string;
  content: MailContent;
  createdAt: number;
  updatedAt: number;
  isDefault?: boolean;
}

export interface Draft {
  id: string;
  name: string;
  templateId?: string;
  content: MailContent;
  createdAt: number;
  updatedAt: number;
}

export type SnippetCategory = 'Greetings' | 'Release Summary' | 'Release Highlights' | 'What\'s Next' | 'Support' | 'Closing' | 'Important Notes';

export interface Snippet {
  id: string;
  title: string;
  category: SnippetCategory;
  content: string;
  createdAt: number;
  updatedAt: number;
}

export interface HistoryRecord {
  id: string;
  subject: string;
  releaseVersion: string;
  templateName: string;
  copiedCount: number;
  status: 'Draft' | 'Generated';
  content: MailContent;
  createdAt: number;
  updatedAt: number;
}

export interface AppSettings {
  brand: {
    companyName: string;
    logoUrl: string;
    bannerUrl: string;
    footerText: string;
    primaryColor: string;
  };
  defaults: {
    greeting: string;
    closing: string;
    environment: string;
    subject: string;
  };
  draft: {
    autoSave: boolean;
    saveInterval: number; // in seconds
  };
  copy: {
    copyHtml: boolean;
    copyInlineCss: boolean;
    minifyHtml: boolean;
  };
}
