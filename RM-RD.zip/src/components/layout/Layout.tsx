import { NavLink } from 'react-router-dom'
import { Outlet } from 'react-router-dom'
import {
  FiEdit3,
  FiLayout,
  FiClock,
  FiFileText,
  FiScissors,
  FiSettings,
} from 'react-icons/fi'

interface NavItem {
  to: string
  icon: React.ElementType
  label: string
  end?: boolean
}

const navItems: NavItem[] = [
  { to: '/',         icon: FiEdit3,    label: 'Builder',   end: true },
  { to: '/templates', icon: FiLayout,   label: 'Templates' },
  { to: '/drafts',   icon: FiFileText, label: 'Drafts' },
  { to: '/history',  icon: FiClock,    label: 'History' },
  { to: '/snippets', icon: FiScissors, label: 'Snippets' },
]

const bottomItems: NavItem[] = [
  { to: '/settings', icon: FiSettings,  label: 'Settings' },
]

export default function Layout() {
  return (
    <div className="main-layout">
      {/* ── Sidebar ── */}
      <aside className="sidebar">
        {/* Logo mark */}
        <div className="sidebar-logo-wrap" title="Release Mailer">
          <span className="sidebar-logo-text">RM</span>
        </div>

        {/* Primary nav */}
        <nav className="sidebar-nav">
          {navItems.map((item) => (
            <div className="sidebar-nav-item" key={item.to}>
              <NavLink
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  `sidebar-link${isActive ? ' active' : ''}`
                }
              >
                <item.icon className="sidebar-link-icon" size={20} />
                <span className="sidebar-link-label">{item.label}</span>
              </NavLink>
              <span className="sidebar-tooltip">{item.label}</span>
            </div>
          ))}
        </nav>

        {/* Bottom: Settings + version */}
        <div className="d-flex flex-column align-items-center gap-1 w-100 px-2">
          {bottomItems.map((item) => (
            <div className="sidebar-nav-item" key={item.to}>
              <NavLink
                to={item.to}
                className={({ isActive }) =>
                  `sidebar-link${isActive ? ' active' : ''}`
                }
              >
                <item.icon className="sidebar-link-icon" size={20} />
                <span className="sidebar-link-label">{item.label}</span>
              </NavLink>
              <span className="sidebar-tooltip">{item.label}</span>
            </div>
          ))}

          <div className="sidebar-footer">
            <span className="sidebar-footer-text">Release{'\n'}Mailer</span>
            <span className="sidebar-footer-text" style={{ opacity: 0.4 }}>v1.0</span>
          </div>
        </div>
      </aside>

      {/* ── Content ── */}
      <main className="content-area p-4">
        <Outlet />
      </main>
    </div>
  )
}
