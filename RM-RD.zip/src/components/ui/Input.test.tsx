import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Input } from './Input';

describe('Input Component', () => {
  it('renders input with label', () => {
    render(<Input label="Username" id="user" name="username" />);
    expect(screen.getByLabelText('Username')).toBeInTheDocument();
  });

  it('renders error message and applies invalid class', () => {
    render(<Input label="Email" error="Invalid email address" />);
    const input = screen.getByRole('textbox');
    expect(input).toHaveClass('is-invalid');
    expect(screen.getByText('Invalid email address')).toBeInTheDocument();
  });

  it('renders help text', () => {
    render(<Input helpText="We'll never share your email." />);
    expect(screen.getByText("We'll never share your email.")).toBeInTheDocument();
  });

  it('allows typing into the input', async () => {
    render(<Input label="Search" />);
    const input = screen.getByLabelText('Search');
    await userEvent.type(input, 'Testing');
    expect(input).toHaveValue('Testing');
  });
});
