import React from 'react';
import clsx from 'clsx';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'success' | 'danger' | 'warning' | 'info' | 'light' | 'dark' | 'outline-primary' | 'outline-secondary' | 'outline-danger' | 'link';
  size?: 'sm' | 'lg';
  isLoading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size, isLoading, leftIcon, rightIcon, children, disabled, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={clsx(
          'btn',
          `btn-${variant}`,
          size && `btn-${size}`,
          className
        )}
        disabled={disabled || isLoading}
        {...props}
      >
        {isLoading && <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>}
        {!isLoading && leftIcon && <span className="me-2 d-flex align-items-center">{leftIcon}</span>}
        {children}
        {!isLoading && rightIcon && <span className="ms-2 d-flex align-items-center">{rightIcon}</span>}
      </button>
    );
  }
);
Button.displayName = 'Button';
