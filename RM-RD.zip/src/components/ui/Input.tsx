import React, { forwardRef } from 'react';
import clsx from 'clsx';
import type { FieldError } from 'react-hook-form';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: FieldError | string;
  helpText?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className, label, error, helpText, id, ...props }, ref) => {
    const inputId = id || props.name || Math.random().toString(36).substring(7);
    const errorMessage = typeof error === 'string' ? error : error?.message;

    return (
      <div className="mb-3">
        {label && (
          <label htmlFor={inputId} className="form-label fw-medium text-secondary small mb-1">
            {label}
          </label>
        )}
        <input
          ref={ref}
          id={inputId}
          className={clsx(
            'form-control',
            { 'is-invalid': !!error },
            className
          )}
          {...props}
        />
        {helpText && !error && <div className="form-text">{helpText}</div>}
        {errorMessage && <div className="invalid-feedback d-block">{errorMessage}</div>}
      </div>
    );
  }
);
Input.displayName = 'Input';

export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: FieldError | string;
  helpText?: string;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, label, error, helpText, id, ...props }, ref) => {
    const inputId = id || props.name || Math.random().toString(36).substring(7);
    const errorMessage = typeof error === 'string' ? error : error?.message;

    return (
      <div className="mb-3">
        {label && (
          <label htmlFor={inputId} className="form-label fw-medium text-secondary small mb-1">
            {label}
          </label>
        )}
        <textarea
          ref={ref}
          id={inputId}
          className={clsx(
            'form-control',
            { 'is-invalid': !!error },
            className
          )}
          {...props}
        />
        {helpText && !error && <div className="form-text">{helpText}</div>}
        {errorMessage && <div className="invalid-feedback d-block">{errorMessage}</div>}
      </div>
    );
  }
);
Textarea.displayName = 'Textarea';
