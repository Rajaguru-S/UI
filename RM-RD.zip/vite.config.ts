import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'
import path from "path";

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  css: {
    preprocessorOptions: {
      scss: {
        // Silence Dart Sass deprecation warnings that come from Bootstrap 5's
        // own SCSS internals (red(), green(), blue(), mix(), unit(), if()).
        // These are Bootstrap's problem, not ours — they'll be fixed in Bootstrap 6.
        quietDeps: true,
        silenceDeprecations: [
          'color-functions',  // red(), green(), blue()
          'global-builtin',   // math.unit, color.mix
          'import',           // @import in favour of @use
          'if-function',      // CSS if() vs Sass if()
        ],
      },
    },
  },
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: './src/setupTests.ts',
  },
})
