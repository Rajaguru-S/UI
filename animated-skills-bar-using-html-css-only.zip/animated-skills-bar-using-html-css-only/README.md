# Animated Skills Bar using HTML & CSS only

A Pen created on CodePen.io. Original URL: [https://codepen.io/rhenaldkarrel-the-bold/pen/xxgZjmX](https://codepen.io/rhenaldkarrel-the-bold/pen/xxgZjmX).

