# CSS3 ribbons

A Pen created on CodePen.io. Original URL: [https://codepen.io/nazarelen/pen/BKGZPP](https://codepen.io/nazarelen/pen/BKGZPP).

