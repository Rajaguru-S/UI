import React from "react";
import ComponentDemo from "../components/docs/ComponentDemo";
import Card from "../components/ui/Card/Card";
import Button from "../components/ui/Button/Button";

const CardPage: React.FC = () => {
  const basicCardCode = `
<Card title="Card Title" subtitle="Card Subtitle">
  This is the content of the card. You can put any React elements here.
</Card>
  `.trim();

  const imageCardCode = `
<Card 
  title="Image Card"
  image="https://via.placeholder.com/300x200"
  imageAlt="Placeholder image"
>
  This card includes an image at the top.
</Card>
  `.trim();

  const hoverCardCode = `
<Card 
  title="Hover Effect Card"
  hoverEffect
>
  Hover over this card to see the effect.
</Card>
  `.trim();

  const footerCardCode = `
<Card 
  title="Card with Footer"
  footer={
    <div className="d-flex justify-content-between">
      <Button variant="outline-secondary" size="sm">Cancel</Button>
      <Button variant="primary" size="sm">Confirm</Button>
    </div>
  }
>
  This card has a custom footer with action buttons.
</Card>
  `.trim();

  return (
    <div className="card-page">
      <ComponentDemo
        title="Basic Card"
        description="A simple card with title and content."
        code={basicCardCode}
      >
        <Card title="Card Title" subtitle="Card Subtitle">
          This is the content of the card. You can put any React elements here.
        </Card>
      </ComponentDemo>

      <ComponentDemo
        title="Card with Image"
        description="Card with an image at the top."
        code={imageCardCode}
      >
        <Card
          title="Image Card"
          image="https://via.placeholder.com/300x200"
          imageAlt="Placeholder image"
        >
          This card includes an image at the top.
        </Card>
      </ComponentDemo>

      <ComponentDemo
        title="Card with Hover Effect"
        description="Card that elevates on hover."
        code={hoverCardCode}
      >
        <Card title="Hover Effect Card" hoverEffect>
          Hover over this card to see the effect.
        </Card>
      </ComponentDemo>

      <ComponentDemo
        title="Card with Footer"
        description="Card with a custom footer area."
        code={footerCardCode}
      >
        <Card
          title="Card with Footer"
          footer={
            <div className="d-flex justify-content-between">
              <Button variant="secondary" size="sm">
                Cancel
              </Button>
              <Button variant="primary" size="sm">
                Confirm
              </Button>
            </div>
          }
        >
          This card has a custom footer with action buttons.
        </Card>
      </ComponentDemo>
    </div>
  );
};

export default CardPage;
