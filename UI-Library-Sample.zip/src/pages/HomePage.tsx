import React from "react";
import { Container, Card, Button } from "react-bootstrap";
import { Link } from "react-router-dom";

const HomePage: React.FC = () => {
  return (
    <Container>
      <h1 className="mb-4">Custom UI Components Library</h1>

      <Card className="mb-4">
        <Card.Body>
          <Card.Title>Welcome to our UI Library</Card.Title>
          <Card.Text>
            This library provides a set of customizable React components built
            with React Bootstrap. Browse the components in the navigation bar to
            see examples and usage.
          </Card.Text>
          <div className="d-flex gap-3">
            <Button variant="primary">View Buttons</Button>
            <Button variant="outline-secondary">View Cards</Button>
          </div>
        </Card.Body>
      </Card>
    </Container>
  );
};

export default HomePage;
