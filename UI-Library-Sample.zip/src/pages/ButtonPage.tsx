import React from "react";
import ComponentDemo from "../components/docs/ComponentDemo";
import Button from "../components/ui/Button/Button";
import { FiArrowRight, FiDownload, FiSettings } from "react-icons/fi";

const ButtonPage: React.FC = () => {
  const buttonVariantsCode = `
<Button variant="primary">Primary</Button>
<Button variant="secondary" className="ms-2">Secondary</Button>
<Button variant="success" className="ms-2">Success</Button>
<Button variant="danger" className="ms-2">Danger</Button>
<Button variant="warning" className="ms-2">Warning</Button>
<Button variant="info" className="ms-2">Info</Button>
<Button variant="light" className="ms-2">Light</Button>
<Button variant="dark" className="ms-2">Dark</Button>
<Button variant="link" className="ms-2">Link</Button>
  `.trim();

  const buttonSizesCode = `
<Button size="lg" className="me-2">Large Button</Button>
<Button className="me-2">Default Button</Button>
<Button size="sm">Small Button</Button>
  `.trim();

  const buttonWithIconsCode = `
<Button variant="primary" icon={<FiDownload />}>Download</Button>
<Button variant="outline-primary" icon={<FiArrowRight />} className="ms-2">
  Continue
</Button>
<Button variant="success" icon={<FiSettings />} className="ms-2" />
  `.trim();

  const loadingButtonCode = `
<Button variant="primary" isLoading>Loading...</Button>
<Button variant="secondary" isLoading className="ms-2" />
  `.trim();

  return (
    <div className="button-page">
      <ComponentDemo
        title="Button Variants"
        description="All available button variants with our custom styling."
        code={buttonVariantsCode}
      >
        <Button variant="primary">Primary</Button>
        <Button variant="secondary" className="ms-2">
          Secondary
        </Button>
        <Button variant="success" className="ms-2">
          Success
        </Button>
        <Button variant="danger" className="ms-2">
          Danger
        </Button>
        <Button variant="warning" className="ms-2">
          Warning
        </Button>
        <Button variant="info" className="ms-2">
          Info
        </Button>
        <Button variant="light" className="ms-2">
          Light
        </Button>
        <Button variant="dark" className="ms-2">
          Dark
        </Button>
        <Button variant="link" className="ms-2">
          Link
        </Button>
      </ComponentDemo>

      <ComponentDemo
        title="Button Sizes"
        description="Buttons available in different sizes."
        code={buttonSizesCode}
      >
        <Button size="lg" className="me-2">
          Large Button
        </Button>
        <Button className="me-2">Default Button</Button>
        <Button size="sm">Small Button</Button>
      </ComponentDemo>

      <ComponentDemo
        title="Buttons with Icons"
        description="Buttons can include icons alongside text or as standalone icons."
        code={buttonWithIconsCode}
      >
        <Button variant="primary">Download</Button>
        <Button variant="primary" className="ms-2">
          Continue
        </Button>
        <Button variant="success" className="ms-2" />
      </ComponentDemo>

      <ComponentDemo
        title="Loading Buttons"
        description="Buttons can show a loading state with a spinner."
        code={loadingButtonCode}
      >
        <Button variant="primary" isLoading>
          Loading...
        </Button>
        <Button variant="secondary" isLoading className="ms-2" />
      </ComponentDemo>
    </div>
  );
};

export default ButtonPage;
