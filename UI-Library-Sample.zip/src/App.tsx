import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { Container, Navbar, Nav } from "react-bootstrap";
import "./App.scss";
import HomePage from "./pages/HomePage";
import ButtonPage from "./pages/ButtonPage";
import CardPage from "./pages/CardPage";

const App: React.FC = () => {
  return (
    <Router>
      <div className="app">
        <Navbar bg="dark" variant="dark" expand="lg" className="mb-4">
          <Container>
            <Navbar.Brand as={Link} to="/">
              UI Library
            </Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <Nav className="me-auto">
                <Nav.Link as={Link} to="/">
                  Home
                </Nav.Link>
                <Nav.Link as={Link} to="/buttons">
                  Buttons
                </Nav.Link>
                <Nav.Link as={Link} to="/cards">
                  Cards
                </Nav.Link>
              </Nav>
            </Navbar.Collapse>
          </Container>
        </Navbar>

        <Container className="main-content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/buttons" element={<ButtonPage />} />
            <Route path="/cards" element={<CardPage />} />
          </Routes>
        </Container>
      </div>
    </Router>
  );
};

export default App;
