import React from "react";
import { Button as BootstrapButton } from "react-bootstrap";
import "./Button.scss";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?:
    | "primary"
    | "secondary"
    | "success"
    | "danger"
    | "warning"
    | "info"
    | "light"
    | "dark"
    | "link";
  size?: "sm" | "lg";
  rounded?: boolean;
  icon?: React.ReactNode;
  isLoading?: boolean;
  fullWidth?: boolean;
}

const Button: React.FC<ButtonProps> = ({
  children,
  variant = "primary",
  size,
  rounded = false,
  icon,
  isLoading = false,
  fullWidth = false,
  className = "",
  ...props
}) => {
  const buttonClasses = [
    "custom-button",
    className,
    rounded ? "rounded-pill" : "",
    icon ? "btn-with-icon" : "",
    isLoading ? "loading" : "",
    fullWidth ? "w-100" : "",
  ]
    .join(" ")
    .trim();

  return (
    <BootstrapButton
      variant={variant}
      size={size}
      className={buttonClasses}
      disabled={isLoading || props.disabled}
      {...props}
    >
      {isLoading && (
        <span
          className="spinner-border spinner-border-sm me-2"
          role="status"
          aria-hidden="true"
        />
      )}
      {icon && <span className="button-icon me-2">{icon}</span>}
      {children}
    </BootstrapButton>
  );
};

export default Button;
