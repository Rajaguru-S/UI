import React from "react";
import { Card as BootstrapCard } from "react-bootstrap";
import "./Card.scss";

interface CardProps {
  title?: string;
  subtitle?: string;
  image?: string;
  imageAlt?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  hoverEffect?: boolean;
  className?: string;
}

const Card: React.FC<CardProps> = ({
  title,
  subtitle,
  image,
  imageAlt,
  children,
  footer,
  hoverEffect = false,
  className = "",
}) => {
  const cardClasses = [
    "custom-card",
    className,
    hoverEffect ? "hover-effect" : "",
  ]
    .join(" ")
    .trim();

  return (
    <BootstrapCard className={cardClasses}>
      {image && (
        <BootstrapCard.Img
          variant="top"
          src={image}
          alt={imageAlt || "Card image"}
        />
      )}
      <BootstrapCard.Body>
        {title && <BootstrapCard.Title>{title}</BootstrapCard.Title>}
        {subtitle && (
          <BootstrapCard.Subtitle className="mb-2 text-muted">
            {subtitle}
          </BootstrapCard.Subtitle>
        )}
        <BootstrapCard.Text>{children}</BootstrapCard.Text>
      </BootstrapCard.Body>
      {footer && (
        <BootstrapCard.Footer className="bg-transparent">
          {footer}
        </BootstrapCard.Footer>
      )}
    </BootstrapCard>
  );
};

export default Card;
