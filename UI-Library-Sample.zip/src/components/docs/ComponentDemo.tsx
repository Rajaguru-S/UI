import React, { useState } from "react";
import { Container, Tab, Tabs } from "react-bootstrap";
import CodeBlock from "./CodeBlock";
import "./ComponentDemo.scss";

interface ComponentDemoProps {
  title: string;
  description?: string;
  children: React.ReactNode;
  code: string;
  tsCode?: string;
}

const ComponentDemo: React.FC<ComponentDemoProps> = ({
  title,
  description,
  children,
  code,
  tsCode,
}) => {
  const [activeKey, setActiveKey] = useState("preview");

  return (
    <Container className="component-demo my-5">
      <h2 className="mb-3">{title}</h2>
      {description && <p className="text-muted mb-4">{description}</p>}

      <Tabs
        activeKey={activeKey}
        onSelect={(k) => setActiveKey(k || "preview")}
        className="mb-3"
        id="component-demo-tabs"
      >
        <Tab eventKey="preview" title="Preview">
          <div className="preview-container p-4 border rounded bg-white">
            {children}
          </div>
        </Tab>
        <Tab eventKey="code" title="React Code">
          <CodeBlock code={code} language="jsx" />
        </Tab>
        {tsCode && (
          <Tab eventKey="tsCode" title="TypeScript">
            <CodeBlock code={tsCode} language="typescript" />
          </Tab>
        )}
      </Tabs>
    </Container>
  );
};

export default ComponentDemo;
