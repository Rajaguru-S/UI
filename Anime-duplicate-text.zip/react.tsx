import React, { useState, useRef } from "react";
import "./App.css";

const App = () => {
  const [editableText, setEditableText] = useState(""); // For the textarea content
  const [animatingDivs, setAnimatingDivs] = useState([]); // Stores all currently animating divs
  const textItemsRef = useRef([]); // Refs to track positions of text items

  const textItems = [
    { id: 1, content: "This is the first text to edit." },
    { id: 2, content: "This is the second text to edit." },
    { id: 3, content: "This is the third text to edit." },
    { id: 4, content: "This is the fourth text to edit." },
    { id: 5, content: "This is the fifth text to edit." },
    { id: 6, content: "This is the sixth text to edit." },
    { id: 7, content: "This is the seventh text to edit." },
    { id: 8, content: "This is the eighth text to edit." },
    { id: 9, content: "This is the ninth text to edit." },
    { id: 10, content: "This is the tenth text to edit." },
    { id: 11, content: "This is the eleventh text to edit." },
    { id: 12, content: "This is the twelfth text to edit." },
    { id: 13, content: "This is the thirteenth text to edit." },
    { id: 14, content: "This is the fourteenth text to edit." },
    { id: 15, content: "This is the fifteenth text to edit." },
  ];

  const handleEdit = (id, content) => {
    // Find the index of the clicked item
    const index = textItems.findIndex((item) => item.id === id);
    if (index !== -1) {
      // Get the position of the item that was clicked
      const rect = textItemsRef.current[index].getBoundingClientRect();
      const top = rect.top + window.scrollY; // Position relative to the viewport

      // Create a duplicate of the div to animate upwards from its current position
      setAnimatingDivs((prev) => [
        ...prev,
        { id, content, top, key: Date.now() },
      ]);
    }

    setTimeout(() => {
      setEditableText(content); // Update the textarea content after the animation starts
    }, 500); // Matches CSS animation duration
  };

  return (
    <div className="container">
      {/* Fixed Text Area */}
      <div className="text-area">
        <textarea
          id="editable-text"
          value={editableText}
          placeholder="Edit text here..."
          readOnly
        />
      </div>

      {/* List of Editable Text Items */}
      <div className="text-items">
        {textItems.map((item, index) => (
          <div
            key={item.id}
            className="text-item"
            ref={(el) => (textItemsRef.current[index] = el)} // Save reference to each item
          >
            <span className="text-content">{item.content}</span>
            <button
              className="edit-btn"
              onClick={() => handleEdit(item.id, item.content)}
            >
              Edit
            </button>
          </div>
        ))}
      </div>

      {/* Duplicates for Animation */}
      {animatingDivs.map((div) => (
        <div
          key={div.key}
          className="text-item moving"
          style={{ top: div.top }} // Set initial position of the animated div
          onAnimationEnd={() => {
            // Remove the animated div after the animation ends
            setAnimatingDivs((prev) => prev.filter((d) => d.key !== div.key));
          }}
        >
          <span className="text-content">{div.content}</span>
        </div>
      ))}
    </div>
  );
};

export default App;


<style>
    /* General Styles */
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  height: 100vh;
  justify-content: flex-start;
  align-items: center;
}

.container {
  width: 100%;
  max-width: 600px;
}

/* Text Area */
.text-area {
  width: 100%;
  position: fixed;
  top: 20px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  justify-content: center;
}

textarea {
  width: 90%;
  height: 100px;
  font-size: 16px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

/* Text Items */
.text-items {
  margin-top: 150px;
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.text-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 5px;
  background-color: #f9f9f9;
}

/* Moving Duplicate Divs */
.text-item.moving {
  position: absolute; /* Ensure that the duplicate divs don't affect the layout */
  left: 50%;
  transform: translateX(-50%) translateY(0);
  background-color: #e0f7fa;
  animation: move-up 0.5s ease-in-out forwards;
  z-index: 10; /* Ensure the animated divs are on top of other elements */
}

/* Animation Keyframes */
@keyframes move-up {
  from {
    transform: translateX(-50%) translateY(0);
    opacity: 1;
  }
  to {
    transform: translateX(-50%) translateY(-120px);
    opacity: 0;
  }
}

button {
  margin-left: 10px;
  padding: 5px 10px;
  font-size: 14px;
  cursor: pointer;
  border: none;
  background-color: #007bff;
  color: #fff;
  border-radius: 5px;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #0056b3;
}

button:disabled {
  background-color: #aaa;
  cursor: not-allowed;
}

</style>