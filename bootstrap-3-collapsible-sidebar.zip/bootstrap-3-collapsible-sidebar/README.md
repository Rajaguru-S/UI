# Bootstrap 3 collapsible sidebar

A Pen created on CodePen.io. Original URL: [https://codepen.io/diego-q/pen/qBWjZwr](https://codepen.io/diego-q/pen/qBWjZwr).

This pen shows you how to easily create a Bootstrap collapsible sidebar. It is part of a tutorial from Bootstrapious.com