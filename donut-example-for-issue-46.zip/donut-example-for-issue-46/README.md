# Donut Example for issue #46

A Pen created on CodePen.io. Original URL: [https://codepen.io/apexcharts/pen/aaOrjE](https://codepen.io/apexcharts/pen/aaOrjE).

