var options = {
  chart: {
    width: 380,
    type: "donut"
  },
  colors: ["#1ab7ea", "#0084ff", "#39539E", "#0077B5"],
  dataLabels: {
     enabled: false
  },
  series: [76, 67, 61, 90],
  tooltip: {
    enabled: true,
    y: {
      formatter: function(val) {
        return val + ".00" + " Rs"
      },
      title: {
        formatter: function (seriesName) {
          return ''
        }
      }
    }
  },
  legend: {
    show: false
  }
};

var chart = new ApexCharts(document.querySelector("#chart"), options);

chart.render();
