import React, { useEffect, useRef, useState } from 'react';
import './ThumbsUpButton.css';

interface Props {
  id: number;
}

export const ThumbsUpButton: React.FC<Props> = ({ id }) => {
  const [checked, setChecked] = useState(true);
  const [showPopover, setShowPopover] = useState(false);
  const [isClosing, setIsClosing] = useState(false);
  const popoverRef = useRef<HTMLDivElement | null>(null);

  const handleClick = () => {
    if (checked) {
      setChecked(false);
      setShowPopover(true);
    } else {
      setChecked(true);
    }
  };

  const handleClose = () => {
    setIsClosing(true);
    setTimeout(() => {
      setShowPopover(false);
      setIsClosing(false);
    }, 300); // match CSS animation duration
  };

  const handleAction = (action: string) => {
    console.log(`Action: ${action}`);
    handleClose();
  };

  // Close on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (
        popoverRef.current &&
        !popoverRef.current.contains(e.target as Node)
      ) {
        handleClose();
      }
    };

    if (showPopover) {
      document.addEventListener('mousedown', handleOutsideClick);
    }

    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [showPopover]);

  return (
    <div className="thumb-wrapper">
      <button
        className={`thumb-button ${checked ? 'checked' : ''}`}
        onClick={handleClick}
      >
        👍
      </button>

      {showPopover && (
        <div
          ref={popoverRef}
          className={`thumb-popover ${isClosing ? 'zoom-out' : 'zoom-in'}`}
        >
          <div className="popover-arrow" />
          <div className="popover-content">
            <p className="popover-title">What would you like to do?</p>
            <div className="popover-actions">
              <button onClick={() => handleAction('Undo')}>Undo</button>
              <button onClick={() => handleAction('Feedback')}>Feedback</button>
              <button onClick={() => handleAction('Dismiss')}>Dismiss</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
