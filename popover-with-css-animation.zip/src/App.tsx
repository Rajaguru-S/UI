import React from 'react';
import { ThumbsUpButton } from './ThumbsUpButton';

const App: React.FC = () => {
  return (
    <div style={{ padding: '2rem' }}>
      <ThumbsUpButton id={1} />
    </div>
  );
};

export default App;
