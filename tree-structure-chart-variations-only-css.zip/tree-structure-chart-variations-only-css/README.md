# Tree structure chart variations only CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/talleyran/pen/eLbjRN](https://codepen.io/talleyran/pen/eLbjRN).

Unordered lists structure as tree visualisation only CSS