// src/types/typo.d.ts
declare module "typo-js" {
  export default class Typo {
    constructor(
      language: string,
      affData: string,
      wordsData: string,
      settings?: { platform: string }
    );
    check(word: string): boolean;
    suggest(word: string): string[];
  }
}
