import React, { useState, useEffect, useRef } from 'react';

interface ModalProps {
  children: React.ReactNode;
  onClose: () => void;
  title?: string;
  initialWidth?: number;
  initialHeight?: number;
}

interface Position {
  x: number;
  y: number;
}

interface Size {
  width: number;
  height: number;
}

const CustomModal: React.FC<ModalProps> = ({
  children,
  onClose,
  title = 'Modal',
  initialWidth = 400,
  initialHeight = 300,
}) => {
  const [position, setPosition] = useState<Position>({ x: 0, y: 0 });
  const [size, setSize] = useState<Size>({
    width: initialWidth,
    height: initialHeight,
  });
  const [isMaximized, setIsMaximized] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [zIndex, setZIndex] = useState(1000);
  const [prevPosition, setPrevPosition] = useState<Position>({ x: 0, y: 0 });
  const [prevSize, setPrevSize] = useState<Size>({
    width: initialWidth,
    height: initialHeight,
  });

  const modalRef = useRef<HTMLDivElement>(null);
  const dragStartPos = useRef<Position>({ x: 0, y: 0 });
  const resizeStartPos = useRef<Position>({ x: 0, y: 0 });
  const resizeStartSize = useRef<Size>({ width: 0, height: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging && !isResizing) return;

      const newPos = {
        x: e.clientX - dragStartPos.current.x,
        y: e.clientY - dragStartPos.current.y,
      };

      if (isDragging) {
        setPosition(newPos);
      }

      if (isResizing) {
        const newWidth =
          resizeStartSize.current.width +
          (e.clientX - resizeStartPos.current.x);
        const newHeight =
          resizeStartSize.current.height +
          (e.clientY - resizeStartPos.current.y);
        setSize({
          width: Math.max(300, newWidth),
          height: Math.max(200, newHeight),
        });
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      setIsResizing(false);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, isResizing]);

  const handleMouseDown = (e: React.MouseEvent) => {
    setZIndex(zIndex + 1);
    if (modalRef.current) {
      const rect = modalRef.current.getBoundingClientRect();
      dragStartPos.current = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      };
    }
    setIsDragging(true);
  };

  const handleResizeMouseDown = (e: React.MouseEvent) => {
    e.stopPropagation();
    resizeStartPos.current = { x: e.clientX, y: e.clientY };
    resizeStartSize.current = { ...size };
    setIsResizing(true);
  };

  const toggleMaximize = () => {
    if (!isMaximized) {
      setPrevPosition(position);
      setPrevSize(size);
      setPosition({ x: 0, y: 0 });
      setSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    } else {
      setPosition(prevPosition);
      setSize(prevSize);
    }
    setIsMaximized(!isMaximized);
  };

  const toggleMinimize = () => {
    setIsMinimized(!isMinimized);
  };

  const modalStyle: React.CSSProperties = {
    position: 'absolute',
    left: position.x,
    top: position.y,
    width: size.width,
    height: isMinimized ? 40 : size.height,
    zIndex,
    display: 'flex',
    flexDirection: 'column',
    backgroundColor: 'white',
    border: '1px solid #ccc',
    borderRadius: '4px',
    boxShadow: '0 2px 10px rgba(0,0,0,0.2)',
    overflow: 'hidden',
  };

  return (
    <div
      ref={modalRef}
      style={modalStyle}
      onMouseDown={() => setZIndex(zIndex + 1)}
    >
      <div
        style={{
          padding: '8px',
          cursor: 'move',
          backgroundColor: '#f0f0f0',
          borderBottom: '1px solid #ddd',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
        onMouseDown={handleMouseDown}
      >
        <div>{title}</div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button onClick={toggleMinimize}>{isMinimized ? '🗖' : '🗕'}</button>
          <button onClick={toggleMaximize}>{isMaximized ? '🗗' : '🗖'}</button>
          <button onClick={onClose}>🗙</button>
        </div>
      </div>

      {!isMinimized && (
        <div style={{ flex: 1, padding: '16px', overflow: 'auto' }}>
          {children}
        </div>
      )}

      {!isMinimized && !isMaximized && (
        <div
          style={{
            position: 'absolute',
            right: 0,
            bottom: 0,
            width: '16px',
            height: '16px',
            cursor: 'se-resize',
            backgroundColor: '#f0f0f0',
            borderTop: '1px solid #ddd',
            borderLeft: '1px solid #ddd',
          }}
          onMouseDown={handleResizeMouseDown}
        />
      )}
    </div>
  );
};

export default CustomModal;
