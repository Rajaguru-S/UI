import React, { useState } from 'react';
import CustomModal from './CustomModal';

const App: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div>
      <button onClick={() => setIsModalOpen(true)}>Open Modal</button>

      {isModalOpen && (
        <CustomModal
          onClose={() => setIsModalOpen(false)}
          title="My Custom Modal"
          initialWidth={600}
          initialHeight={400}
        >
          <div>
            <h2>Modal Content</h2>
            <p>Drag the header to move the modal</p>
            <p>Use the bottom-right corner to resize</p>
            <p>Use the control buttons to minimize/maximize/close</p>
          </div>
        </CustomModal>
      )}
    </div>
  );
};

export default App;
