# Bootstrap 4 Sidebar Menu To Top

A Pen created on CodePen.io. Original URL: [https://codepen.io/Serhii75/pen/OEQrgM](https://codepen.io/Serhii75/pen/OEQrgM).

