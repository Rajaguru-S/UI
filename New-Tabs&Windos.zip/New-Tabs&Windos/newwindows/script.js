// Get references to elements
const overlay = document.getElementById("overlay");
const openOverlayBtn = document.getElementById("open-overlay");
const closeOverlayBtn = document.getElementById("close-overlay");
const openNewWindowBtn = document.getElementById("open-new-window");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");

// Variable to hold reference to the new window
let newWindow = null;

// Function to handle the "Open Overlay" button
openOverlayBtn.addEventListener("click", (event) => {
  event.preventDefault(); // Prevent default link behavior

  // If the new window is open and not closed, redirect to that window
  if (newWindow && !newWindow.closed) {
    newWindow.focus(); // Bring the new window to focus
  } else {
    overlay.classList.remove("hidden"); // Show the overlay if no window is open
  }
});

// Function to close overlay
closeOverlayBtn.addEventListener("click", () => {
  overlay.classList.add("hidden"); // Hide the overlay
});

// Function to open a new window with form data
openNewWindowBtn.addEventListener("click", () => {
  const name = nameInput.value;
  const email = emailInput.value;

  // Open a new window with a specific size and features
  newWindow = window.open(
    "new-window.html",
    "_blank",
    "width=600,height=400,left=100,top=100"
  );

  // Wait for the new window to load and then pass the data
  newWindow.onload = function () {
    // Send the form data as URL parameters to the new window
    newWindow.location.href = `new-window.html?name=${encodeURIComponent(
      name
    )}&email=${encodeURIComponent(email)}`;
  };

  // Hide the overlay once the window opens
  overlay.classList.add("hidden");
});
