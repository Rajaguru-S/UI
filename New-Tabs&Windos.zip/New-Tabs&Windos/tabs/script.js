// Get references to elements
const overlay = document.getElementById("overlay");
const openOverlayBtn = document.getElementById("open-overlay");
const closeOverlayBtn = document.getElementById("close-overlay");
const openNewTabBtn = document.getElementById("open-new-tab");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");

// Variable to store the reference to the new tab
let newTabWindow = null;

// Function to handle the "Open Overlay" button
openOverlayBtn.addEventListener("click", (event) => {
  event.preventDefault(); // Prevent default link behavior

  if (newTabWindow && !newTabWindow.closed) {
    // If the new tab is open, redirect to it and bring it into focus
    newTabWindow.focus();
  } else {
    // Otherwise, open the overlay
    overlay.classList.remove("hidden");
  }
});

// Function to close overlay
closeOverlayBtn.addEventListener("click", () => {
  overlay.classList.add("hidden");
});

// Function to open external HTML file in a new tab with form data
openNewTabBtn.addEventListener("click", () => {
  const name = nameInput.value;
  const email = emailInput.value;

  // Pass form data via URL parameters
  const newTabUrl = `new-tab.html?name=${encodeURIComponent(
    name
  )}&email=${encodeURIComponent(email)}`;

  if (newTabWindow && !newTabWindow.closed) {
    // If the new tab is already open, update its location and focus it
    newTabWindow.location.href = newTabUrl;
    newTabWindow.focus();
  } else {
    // Open a new tab and store its reference
    newTabWindow = window.open(newTabUrl, "_blank");
  }

  // Hide the overlay after opening the new tab
  overlay.classList.add("hidden");
});
