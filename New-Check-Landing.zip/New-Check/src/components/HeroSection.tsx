import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import AuditCircleCTA from "./AuditCircleCTA";
import PipelineAnimation from "./PipelineAnimation";

type HeroPhase = "idle" | "loading" | "flow";

function HeroSection() {
  const [phase, setPhase] = useState<HeroPhase>("idle");
  const [rippleKey, setRippleKey] = useState(0);

  useEffect(() => {
    if (phase !== "loading") {
      return undefined;
    }

    const timer = window.setTimeout(() => {
      setPhase("flow");
    }, 920);

    return () => window.clearTimeout(timer);
  }, [phase]);

  const handleStart = () => {
    if (phase !== "idle") {
      return;
    }

    setRippleKey((currentKey) => currentKey + 1);
    setPhase("loading");
  };

  return (
    <section className={`hero-section hero-section--${phase}`}>
      <div className="hero-grid" aria-hidden="true" />

      <div className="container hero-section__container">
        <motion.div
          animate={phase === "flow" ? "compact" : "centered"}
          className="hero-copy"
          initial="centered"
          variants={{
            centered: {
              opacity: 1,
              y: 0,
              scale: 1,
              transition: { duration: 0.55, ease: "easeOut" },
            },
            compact: {
              opacity: 0.9,
              y: -22,
              scale: 0.92,
              transition: { duration: 0.55, ease: "easeInOut" },
            },
          }}
        >
          <span className="hero-copy__kicker">Autonomous audit orchestration</span>
          <h1>AI-Powered Audit Agents</h1>
          <p>Automate. Analyze. Act.</p>
        </motion.div>

        <AnimatePresence mode="wait">
          {phase !== "flow" ? (
            <AuditCircleCTA
              isLoading={phase === "loading"}
              key="audit-circle"
              onStart={handleStart}
              rippleKey={rippleKey}
            />
          ) : (
            <PipelineAnimation key="pipeline-flow" />
          )}
        </AnimatePresence>

        <AnimatePresence>
          {phase === "loading" && (
            <motion.div
              animate={{ opacity: 1, y: 0 }}
              className="audit-loader"
              exit={{ opacity: 0, y: -8 }}
              initial={{ opacity: 0, y: 10 }}
              transition={{ duration: 0.28, ease: "easeOut" }}
            >
              <span className="audit-loader__bar" />
              <span className="audit-loader__text">Priming triage stream</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}

export default HeroSection;
