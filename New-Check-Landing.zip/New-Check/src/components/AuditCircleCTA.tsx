import { motion } from "framer-motion";
import { Activity, Play } from "lucide-react";

const neuralDots = Array.from({ length: 8 }, (_, index) => index + 1);
const orbitSparks = Array.from({ length: 3 }, (_, index) => index + 1);

interface AuditCircleCTAProps {
  isLoading: boolean;
  onStart: () => void;
  rippleKey: number;
}

function AuditCircleCTA({ isLoading, onStart, rippleKey }: AuditCircleCTAProps) {
  return (
    <motion.div
      animate={{ opacity: 1, scale: 1 }}
      className="audit-cta"
      exit={{ opacity: 0, scale: 1.08, transition: { duration: 0.32 } }}
      initial={{ opacity: 0, scale: 0.92 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
    >
      <motion.button
        aria-label="Start Audit Flow"
        className={`audit-cta__button${isLoading ? " is-loading" : ""}`}
        disabled={isLoading}
        onClick={onStart}
        type="button"
        whileHover={isLoading ? undefined : { scale: 1.045 }}
        whileTap={isLoading ? undefined : { scale: 0.98 }}
      >
        <span className="audit-cta__halo" />
        <span className="audit-cta__neural-web" aria-hidden="true">
          {neuralDots.map((dot) => (
            <span className={`audit-cta__neural-dot audit-cta__neural-dot--${dot}`} key={dot} />
          ))}
        </span>
        {orbitSparks.map((spark) => (
          <span className={`audit-cta__spark audit-cta__spark--${spark}`} key={spark} />
        ))}
        <span className="audit-cta__ring audit-cta__ring--outer" />
        <span className="audit-cta__ring audit-cta__ring--middle" />
        <span className="audit-cta__ring audit-cta__ring--inner" />
        <span className="audit-cta__lens" />
        <span className="audit-cta__scan-line" />
        <span className="audit-cta__ripple" key={rippleKey} />
        <span className="audit-cta__content">
          <Activity className="audit-cta__signal" aria-hidden="true" />
          <span className="audit-cta__label">Start Audit Flow</span>
          <span className="audit-cta__launch">
            <Play aria-hidden="true" />
          </span>
        </span>
      </motion.button>
    </motion.div>
  );
}

export default AuditCircleCTA;
