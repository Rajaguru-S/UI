import { motion } from "framer-motion";
import type { Variants } from "framer-motion";
import { Code2, HeartPulse, Network, ShieldCheck } from "lucide-react";

const icons = {
  code: Code2,
  clinical: HeartPulse,
  insurance: ShieldCheck,
  flow: Network,
};

export type AgentIcon = keyof typeof icons;

export interface AgentCardProps {
  description: string;
  icon: AgentIcon;
  title: string;
}

const cardVariants: Variants = {
  hidden: {
    filter: "blur(10px)",
    opacity: 0,
    rotateX: 14,
    y: 54,
    scale: 0.88,
  },
  visible: {
    filter: "blur(0px)",
    opacity: 1,
    rotateX: 0,
    y: 0,
    scale: 1,
    transition: {
      damping: 18,
      stiffness: 120,
      type: "spring",
    },
  },
  hover: {
    y: -8,
    scale: 1.025,
    transition: {
      duration: 0.22,
      ease: "easeOut",
    },
  },
};

function AgentCard({ description, icon, title }: AgentCardProps) {
  const Icon = icons[icon];

  return (
    <motion.article
      className="agent-card h-100"
      variants={cardVariants}
      whileHover="hover"
    >
      <span className="agent-card__signal-grid" aria-hidden="true" />
      <span className="agent-card__icon">
        <Icon aria-hidden="true" className="agent-card__icon-svg" />
      </span>
      <div className="agent-card__body">
        <h2>{title}</h2>
        <p>{description}</p>
      </div>
    </motion.article>
  );
}

export default AgentCard;
