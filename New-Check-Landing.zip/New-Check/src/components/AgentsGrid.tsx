import { motion } from "framer-motion";
import type { Variants } from "framer-motion";
import AgentCard from "./AgentCard";
import type { AgentCardProps } from "./AgentCard";

const agents: AgentCardProps[] = [
  {
    description: "Automates code validation & logic checks",
    icon: "code",
    title: "Coding Agent",
  },
  {
    description: "Validates clinical data & compliance",
    icon: "clinical",
    title: "Clinical Agent",
  },
  {
    description: "Handles insurance-based audit rules",
    icon: "insurance",
    title: "IBR Audit Agent",
  },
  {
    description: "Orchestrates workflow intelligence",
    icon: "flow",
    title: "Drishti Flow Agent",
  },
];

const gridVariants: Variants = {
  hidden: {},
  visible: {
    transition: {
      delayChildren: 0.18,
      staggerChildren: 0.2,
    },
  },
};

function AgentsGrid() {
  return (
    <motion.div
      animate="visible"
      className="agents-grid row g-3 g-xl-4"
      initial="hidden"
      variants={gridVariants}
    >
      {agents.map((agent) => (
        <div className="col-6 col-md-6 col-xl-3" key={agent.title}>
          <AgentCard {...agent} />
        </div>
      ))}
    </motion.div>
  );
}

export default AgentsGrid;
