import { AnimatePresence, motion } from "framer-motion";
import { ClipboardList, GitBranch, ShieldCheck } from "lucide-react";
import { useEffect, useState } from "react";
import AgentsGrid from "./AgentsGrid";

const STAGE_DURATION_MS = 10_000;
const STAGE_DURATION_SECONDS = STAGE_DURATION_MS / 1000;

const pipelineNodes = [
  {
    className: "pipeline-node-slot--intake",
    detail: "Capturing scope, evidence packets, and engagement metadata.",
    Icon: ClipboardList,
    label: "Audit Intake",
    path: "M 40 156 C 76 120 116 122 150 156",
    visualClassName: "pipeline-stage-orbit--intake",
  },
  {
    className: "pipeline-node-slot--validation",
    detail: "Reconciling schemas, missing fields, and compliance signals.",
    Icon: ShieldCheck,
    label: "Data Validation",
    path: "M 150 156 C 260 212 360 96 470 156",
    visualClassName: "pipeline-stage-orbit--validation",
  },
  {
    className: "pipeline-node-slot--triage",
    detail: "Scoring exceptions and routing work to specialist agents.",
    Icon: GitBranch,
    label: "Triage Engine",
    path: "M 470 156 C 580 216 680 96 790 156",
    visualClassName: "pipeline-stage-orbit--triage",
  },
] as const;

const branchPaths = [
  "M 790 252 C 646 292 406 322 150 392",
  "M 790 252 C 706 308 548 336 385 392",
  "M 790 252 C 762 316 704 342 620 392",
  "M 790 252 C 852 306 898 342 855 392",
];

const basePipelinePath =
  "M 40 156 C 76 120 116 122 150 156 C 260 212 360 96 470 156 C 580 216 680 96 790 156";

const splitStemPath = "M 790 156 C 804 194 804 224 790 252";

function PipelineAnimation() {
  const [activeStage, setActiveStage] = useState(0);
  const [agentsVisible, setAgentsVisible] = useState(false);
  const stage = pipelineNodes[activeStage];

  useEffect(() => {
    const timers = [
      window.setTimeout(() => setActiveStage(1), STAGE_DURATION_MS),
      window.setTimeout(() => setActiveStage(2), STAGE_DURATION_MS * 2),
      window.setTimeout(() => setAgentsVisible(true), STAGE_DURATION_MS * 3),
    ];

    return () => {
      timers.forEach((timer) => window.clearTimeout(timer));
    };
  }, []);

  return (
    <motion.section
      animate={{ opacity: 1, y: 0 }}
      aria-label="Audit automation pipeline"
      className="pipeline-experience"
      exit={{ opacity: 0, y: 18 }}
      initial={{ opacity: 0, y: 22 }}
      transition={{ duration: 0.55, ease: "easeOut" }}
    >
      <div className="pipeline-shell">
        <div className={`pipeline-visual${agentsVisible ? " is-agent-ready" : ""}`}>
          <div
            aria-hidden="true"
            className={`pipeline-stage-orbit ${stage.visualClassName}`}
            key={stage.label}
          >
            <span className="pipeline-stage-orbit__ring pipeline-stage-orbit__ring--outer" />
            <span className="pipeline-stage-orbit__ring pipeline-stage-orbit__ring--middle" />
            <span className="pipeline-stage-orbit__ring pipeline-stage-orbit__ring--inner" />
            <span className="pipeline-stage-orbit__beam" />
          </div>

          <svg
            aria-hidden="true"
            className="pipeline-svg"
            preserveAspectRatio="none"
            viewBox="0 0 1000 520"
          >
            <defs>
              <linearGradient id="pipelineGradient" x1="0%" x2="100%" y1="0%" y2="0%">
                <stop offset="0%" stopColor="#1be7ff" />
                <stop offset="45%" stopColor="#8f7cff" />
                <stop offset="100%" stopColor="#37f3be" />
              </linearGradient>
              <filter id="pipelineGlow" x="-20%" y="-40%" width="140%" height="180%">
                <feGaussianBlur stdDeviation="5" result="coloredBlur" />
                <feMerge>
                  <feMergeNode in="coloredBlur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            <path
              className="pipeline-path pipeline-path--base"
              d={basePipelinePath}
            />
            <path
              className="pipeline-path pipeline-path--base pipeline-path--base-glow"
              d={basePipelinePath}
            />

            {pipelineNodes.map((node, index) => (
              <motion.path
                animate={{ pathLength: activeStage >= index ? 1 : 0 }}
                className={`pipeline-path pipeline-path--main pipeline-path--stage-${index + 1}`}
                d={node.path}
                initial={{ pathLength: 0 }}
                key={node.label}
                transition={{
                  duration: activeStage === index ? STAGE_DURATION_SECONDS : 0.45,
                  ease: "easeInOut",
                }}
              />
            ))}

            <motion.path
              animate={{ opacity: 1, pathLength: 1 }}
              className="pipeline-path pipeline-path--stream"
              d={stage.path}
              key={stage.label}
              initial={{ opacity: 0, pathLength: 0 }}
              transition={{ duration: STAGE_DURATION_SECONDS, ease: "easeInOut" }}
            />

            <AnimatePresence>
              {agentsVisible &&
                [splitStemPath].map((stemPath) => (
                  <motion.path
                    animate={{ opacity: 1, pathLength: 1 }}
                    className="pipeline-path pipeline-path--split-stem"
                    d={stemPath}
                    exit={{ opacity: 0, pathLength: 0 }}
                    initial={{ opacity: 0, pathLength: 0 }}
                    key={stemPath}
                    transition={{
                      duration: 0.56,
                      ease: "easeInOut",
                    }}
                  />
                ))}
            </AnimatePresence>

            <AnimatePresence>
              {agentsVisible &&
                branchPaths.map((branchPath, index) => (
                  <g className="pipeline-branch-group" key={branchPath}>
                    <motion.path
                      animate={{ opacity: 1, pathLength: 1 }}
                      className="pipeline-path pipeline-path--branch"
                      d={branchPath}
                      exit={{ opacity: 0, pathLength: 0 }}
                      initial={{ opacity: 0, pathLength: 0 }}
                      transition={{
                        delay: index * 0.12,
                        duration: 0.82,
                        ease: "easeInOut",
                      }}
                    />
                    <motion.path
                      animate={{ opacity: 1, pathLength: 1 }}
                      className="pipeline-path pipeline-path--branch-stream"
                      d={branchPath}
                      exit={{ opacity: 0, pathLength: 0 }}
                      initial={{ opacity: 0, pathLength: 0 }}
                      transition={{
                        delay: 0.35 + index * 0.12,
                        duration: 0.92,
                        ease: "easeInOut",
                      }}
                    />
                  </g>
                ))}
            </AnimatePresence>
          </svg>

          {pipelineNodes.map((node, index) => (
            <div className={`pipeline-node-slot ${node.className}`} key={node.label}>
              <motion.div
                animate={{
                  opacity: activeStage >= index || agentsVisible ? 1 : 0,
                  scale: activeStage >= index || agentsVisible ? 1 : 0.84,
                  y: activeStage >= index || agentsVisible ? 0 : 12,
                }}
                className={`pipeline-node pipeline-node--${
                  agentsVisible || activeStage > index
                    ? "complete"
                    : activeStage === index
                      ? "active"
                      : "pending"
                }`}
                initial={{ opacity: 0, scale: 0.84, y: 12 }}
                transition={{
                  delay: index === 0 ? 0.24 : 0,
                  duration: 0.5,
                  ease: "easeOut",
                }}
              >
                <span className="pipeline-node__dot" />
                <span className="pipeline-node__label">{node.label}</span>
                <span className="pipeline-node__icon">
                  <node.Icon aria-hidden="true" />
                </span>
              </motion.div>
            </div>
          ))}

          <AnimatePresence mode="wait">
            {!agentsVisible && (
              <motion.div
                animate={{ opacity: 1, y: 0 }}
                className="pipeline-stage-console"
                exit={{ opacity: 0, y: 12 }}
                initial={{ opacity: 0, y: 12 }}
                key={stage.label}
                transition={{ duration: 0.42, ease: "easeOut" }}
              >
                <span className="pipeline-stage-console__eyebrow">
                  Stage 0{activeStage + 1} / 03
                </span>
                <h2>{stage.label}</h2>
                <p>{stage.detail}</p>
                <div className="pipeline-stage-console__meter" aria-hidden="true">
                  <span key={stage.label} />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence>{agentsVisible && <AgentsGrid />}</AnimatePresence>
        </div>
      </div>
    </motion.section>
  );
}

export default PipelineAnimation;
