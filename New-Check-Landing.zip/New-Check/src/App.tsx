import HeroSection from "./components/HeroSection";

function App() {
  return (
    <main className="app-shell">
      <HeroSection />
    </main>
  );
}

export default App;
