# Bootstrap Accordion example with expand/collapse all

A Pen created on CodePen.io. Original URL: [https://codepen.io/AndreasFrontDev/pen/zBZZvq](https://codepen.io/AndreasFrontDev/pen/zBZZvq).

