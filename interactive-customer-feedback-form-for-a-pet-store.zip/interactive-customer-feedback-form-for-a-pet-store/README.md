# Interactive Customer Feedback Form (For a pet store)

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/pgRzEQ](https://codepen.io/jcoulterdesign/pen/pgRzEQ).

Takes the edge off those boring customer feedback forms :) Grab the smilies and move them up or down to reflect how happy you are!!