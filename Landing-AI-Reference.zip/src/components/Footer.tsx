import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-top py-4">
      <div className="container text-center">
        <span className="text-muted small">© 2024 AgentAI Inc. MIT Licensed. Built for the future of work.</span>
      </div>
    </footer>
  );
};

export default Footer;
