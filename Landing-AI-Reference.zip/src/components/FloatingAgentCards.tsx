import React from 'react';
import { motion } from 'framer-motion';
import { Code, Stethoscope, FileCheck, GitBranch, Activity, CheckCircle } from 'lucide-react';

interface Agent {
  id: string;
  title: string;
  desc: string;
  icon: React.ReactNode;
  color: string;
  pos: {
    top?: string;
    bottom?: string;
    left?: string;
    right?: string;
  };
  delay: number;
}

const agents: Agent[] = [
  {
    id: 'coding',
    title: 'Coding Agent',
    desc: 'Workflow Automation',
    icon: <Code size={24} />,
    color: '#2563EB',
    pos: { top: '0%', left: '10%' },
    delay: 0
  },
  {
    id: 'clinical',
    title: 'Clinical Agent',
    desc: 'Medical Intelligence',
    icon: <Stethoscope size={24} />,
    color: '#7C3AED',
    pos: { top: '20%', right: '0%' },
    delay: 0.2
  },
  {
    id: 'ibr',
    title: 'IBR Audit Agent',
    desc: 'Compliance Validation',
    icon: <FileCheck size={24} />,
    color: '#06B6D4',
    pos: { bottom: '10%', left: '0%' },
    delay: 0.4
  },
  {
    id: 'flow',
    title: 'Drishti Flow',
    desc: 'Process Orchestration',
    icon: <GitBranch size={24} />,
    color: '#10B981',
    pos: { bottom: '0%', right: '15%' },
    delay: 0.6
  }
];

interface AgentCardProps {
  agent: Agent;
  isTransitioning: boolean;
}

const AgentCard: React.FC<AgentCardProps> = ({ agent, isTransitioning }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8, y: 50 }}
      animate={isTransitioning ? { 
        opacity: 0.5, 
        scale: 1.2, 
        x: '50%', 
        y: '50%',
        filter: 'blur(10px)'
      } : { 
        opacity: 1, 
        scale: 1, 
        y: 0 
      }}
      transition={{ 
        duration: 0.8, 
        delay: agent.delay,
        ease: [0.16, 1, 0.3, 1] 
      }}
      style={{
        position: 'absolute',
        ...agent.pos,
        zIndex: 10
      }}
    >
      <motion.div
        animate={{ 
          y: [0, -15, 0],
          rotate: [0, 2, -2, 0]
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
          delay: agent.delay * 2
        }}
        className="glass-card p-4"
        style={{ width: '260px' }}
      >
        <div className="d-flex align-items-center gap-3 mb-3">
          <div className="p-3 rounded-4" style={{ backgroundColor: `${agent.color}15`, color: agent.color }}>
            {agent.icon}
          </div>
          <div>
            <h6 className="mb-0 fw-bold">{agent.title}</h6>
            <span className="text-muted small">{agent.desc}</span>
          </div>
        </div>
        
        <div className="processing-state p-3 rounded-4 bg-light mb-3">
          <div className="d-flex justify-content-between align-items-center mb-2">
            <span className="small fw-medium text-muted">Processing...</span>
            <motion.div 
              animate={{ opacity: [1, 0.4, 1] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="d-flex align-items-center gap-1"
            >
              <div className="rounded-circle" style={{ width: '6px', height: '6px', backgroundColor: agent.color }}></div>
              <span className="small fw-bold" style={{ color: agent.color }}>Active</span>
            </motion.div>
          </div>
          <div className="progress" style={{ height: '6px', borderRadius: '10px' }}>
            <motion.div 
              className="progress-bar progress-bar-animated" 
              initial={{ width: '0%' }}
              animate={{ width: ['20%', '85%', '60%', '95%'] } as any}
              transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              style={{ backgroundColor: agent.color, borderRadius: '10px' }}
            ></motion.div>
          </div>
        </div>
        
        <div className="d-flex justify-content-between align-items-center">
          <div className="d-flex align-items-center gap-2">
            <Activity size={14} className="text-muted" />
            <span className="small text-muted fw-medium">84.2 TPS</span>
          </div>
          <div className="d-flex align-items-center gap-1">
            <CheckCircle size={14} className="text-success" />
            <span className="small text-muted fw-medium">99%</span>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

interface FloatingAgentCardsProps {
  isTransitioning: boolean;
}

const FloatingAgentCards: React.FC<FloatingAgentCardsProps> = ({ isTransitioning }) => {
  return (
    <div className="position-relative w-100" style={{ height: '600px' }}>
      {agents.map((agent) => (
        <AgentCard key={agent.id} agent={agent} isTransitioning={isTransitioning} />
      ))}
      
      {/* Decorative center element - Pushed right to avoid text overlap */}
      <motion.div
        animate={isTransitioning ? { scale: 2, opacity: 0 } : { scale: 1, opacity: 1 }}
        className="position-absolute top-50 start-50 translate-middle"
        style={{ zIndex: 1, marginLeft: '50px' }}
      >
        <div className="rounded-circle border border-primary-glow p-5" style={{ borderStyle: 'dashed', opacity: 0.3 }}>
          <div className="rounded-circle border border-primary-glow p-5" style={{ borderStyle: 'dashed' }}>
            <div className="rounded-circle bg-primary-glow" style={{ width: '100px', height: '100px', filter: 'blur(30px)', opacity: 0.5 }}></div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default FloatingAgentCards;
