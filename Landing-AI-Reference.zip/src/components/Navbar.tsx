import React from 'react';
import { motion } from 'framer-motion';
import { Cpu, ChevronRight } from 'lucide-react';

interface NavbarProps {
  onLogoClick?: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onLogoClick }) => {
  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      className="navbar navbar-expand-lg fixed-top px-lg-5"
      style={{ 
        background: 'rgba(255, 255, 255, 0.8)', 
        backdropFilter: 'blur(10px)',
        borderBottom: '1px solid rgba(0, 0, 0, 0.05)'
      }}
    >
      <div className="container-fluid">
        <a 
          className="navbar-brand d-flex align-items-center gap-2" 
          href="#"
          onClick={(e) => {
            e.preventDefault();
            if (onLogoClick) onLogoClick();
          }}
        >
          <div className="p-2 bg-primary rounded-lg d-flex align-items-center justify-content-center" style={{ borderRadius: '12px' }}>
            <Cpu size={24} color="white" />
          </div>
          <span className="fw-bold fs-4 tracking-tight" style={{ color: 'var(--text-main)' }}>
            Agent<span className="text-primary">AI</span>
          </span>
        </a>
        
        <button className="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span className="navbar-toggler-icon"></span>
        </button>
        
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav mx-auto gap-lg-4">
            {['Solutions', 'Agents', 'Enterprise', 'Security', 'Pricing'].map((item) => (
              <li className="nav-item" key={item}>
                <a className="nav-link fw-medium text-muted hover-text-primary transition-all" href={`#${item.toLowerCase()}`}>
                  {item}
                </a>
              </li>
            ))}
          </ul>
          
          <div className="d-flex align-items-center gap-3">
            <button className="btn fw-semibold text-muted">Log in</button>
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="btn-premium-primary d-flex align-items-center gap-2"
            >
              Get Started <ChevronRight size={18} />
            </motion.button>
          </div>
        </div>
      </div>
    </motion.nav>
  );
};

export default Navbar;
