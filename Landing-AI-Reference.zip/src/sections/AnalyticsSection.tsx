import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, Filter, MoreHorizontal, 
  CheckCircle, Clock, TrendingUp,
  Code, Stethoscope, FileCheck, GitBranch
} from 'lucide-react';

interface AgentStat {
  id: string;
  title: string;
  icon: React.ReactNode;
  color: string;
  stats: {
    audits: number;
    success: string;
    speed: string;
  };
}

const agents: AgentStat[] = [
  { id: 'coding', title: 'Coding Agent', icon: <Code />, color: '#2563EB', stats: { audits: 1240, success: '99.2%', speed: '1.1s' } },
  { id: 'clinical', title: 'Clinical Agent', icon: <Stethoscope />, color: '#7C3AED', stats: { audits: 856, success: '98.5%', speed: '2.4s' } },
  { id: 'ibr', title: 'IBR Audit', icon: <FileCheck />, color: '#06B6D4', stats: { audits: 3120, success: '99.9%', speed: '0.8s' } },
  { id: 'flow', title: 'Drishti Flow', icon: <GitBranch />, color: '#10B981', stats: { audits: 450, success: '100%', speed: '0.5s' } },
];

interface Audit {
  id: string;
  title: string;
  status: string;
  confidence: number;
  time: string;
  risk: string;
  agent: string;
}

const mockAudits: Audit[] = [
  { id: 'AUD-8291', title: 'Smart Contract Security Audit', status: 'Completed', confidence: 98, time: '2.1s', risk: 'Low', agent: 'coding' },
  { id: 'AUD-8292', title: 'Clinical Trial Phase III Review', status: 'Completed', confidence: 96, time: '3.4s', risk: 'Medium', agent: 'clinical' },
  { id: 'AUD-8293', title: 'Annual Financial Compliance', status: 'Completed', confidence: 99, time: '1.2s', risk: 'Low', agent: 'ibr' },
  { id: 'AUD-8294', title: 'Cross-Border Transaction Flow', status: 'Processing', confidence: 85, time: 'Running', risk: 'N/A', agent: 'flow' },
  { id: 'AUD-8295', title: 'Legacy Monolith Refactoring', status: 'Completed', confidence: 94, time: '4.5s', risk: 'High', agent: 'coding' },
  { id: 'AUD-8296', title: 'Patient Data Privacy Check', status: 'Completed', confidence: 99, time: '0.9s', risk: 'Low', agent: 'clinical' },
  { id: 'AUD-8297', title: 'Infrastructure IaC Scan', status: 'Completed', confidence: 97, time: '1.5s', risk: 'Low', agent: 'coding' },
  { id: 'AUD-8298', title: 'Supply Chain Integrity Audit', status: 'Completed', confidence: 92, time: '2.8s', risk: 'Medium', agent: 'flow' },
  { id: 'AUD-8299', title: 'API Gateway Authentication', status: 'Completed', confidence: 99, time: '0.4s', risk: 'Low', agent: 'coding' },
];

const AnalyticsSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('coding');

  return (
    <section className="analytics-section bg-soft vh-100 d-flex flex-column overflow-hidden">
      {/* Top spacing for fixed Navbar clearance */}
      <div className="pt-5 mt-4"></div>

      <div className="container-fluid px-5 flex-grow-1 d-flex flex-column overflow-hidden">
        <div className="row mb-3 align-items-center">
          <div className="col-12">
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h2 className="fw-bold mb-1">Enterprise Command Center</h2>
              <p className="text-muted small mb-0">Monitor and optimize your AI agent fleet performance.</p>
            </motion.div>
          </div>
        </div>

        {/* Small Agent Cards Row */}
        <div className="row g-3 mb-4">
          {agents.map((agent) => (
            <div key={agent.id} className="col-md-3 col-xl-2">
              <motion.div
                whileHover={{ y: -3 }}
                onClick={() => setActiveTab(agent.id)}
                className={`glass-card p-3 cursor-pointer transition-all border-2 ${activeTab === agent.id ? 'border-primary shadow-sm' : 'border-transparent'}`}
                style={{ cursor: 'pointer' }}
              >
                <div className="d-flex align-items-center gap-3">
                  <div className="p-2 rounded-3" style={{ backgroundColor: `${agent.color}15`, color: agent.color }}>
                    {React.cloneElement(agent.icon as React.ReactElement, { size: 20 })}
                  </div>
                  <div className="overflow-hidden">
                    <h6 className="fw-bold mb-0 text-truncate" style={{ fontSize: '0.85rem' }}>{agent.title}</h6>
                    <div className="small text-muted" style={{ fontSize: '0.7rem' }}>{agent.stats.audits} Audits</div>
                  </div>
                </div>
              </motion.div>
            </div>
          ))}
        </div>

        {/* Dashboard Grid Content with Internal Scroll */}
        <motion.div 
          key={activeTab}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="glass-card p-0 flex-grow-1 d-flex flex-column overflow-hidden shadow-sm border-0 mb-4"
          style={{ minHeight: 0 }}
        >
          <div className="p-3 border-bottom d-flex flex-wrap justify-content-between align-items-center gap-3 bg-white">
            <div className="d-flex align-items-center gap-3 flex-grow-1" style={{ maxWidth: '350px' }}>
              <div className="input-group input-group-sm">
                <span className="input-group-text bg-white border-end-0"><Search size={16} className="text-muted" /></span>
                <input type="text" className="form-control border-start-0 ps-0" placeholder="Search audit stream..." />
              </div>
            </div>
            <div className="d-flex gap-2">
              <button className="btn btn-sm btn-light d-flex align-items-center gap-2"><Filter size={14} /> Filter</button>
              <button className="btn btn-sm btn-light"><TrendingUp size={14} /></button>
            </div>
          </div>

          <div className="table-responsive flex-grow-1 overflow-auto">
            <table className="table table-hover align-middle mb-0">
              <thead className="bg-light sticky-top" style={{ zIndex: 10 }}>
                <tr>
                  <th className="ps-4 py-2 text-muted fw-bold small text-uppercase">Audit ID</th>
                  <th className="py-2 text-muted fw-bold small text-uppercase">Intelligence Task</th>
                  <th className="py-2 text-muted fw-bold small text-uppercase">Status</th>
                  <th className="py-2 text-muted fw-bold small text-uppercase">AI Confidence</th>
                  <th className="py-2 text-muted fw-bold small text-uppercase">Latency</th>
                  <th className="py-2 text-muted fw-bold small text-uppercase">Risk</th>
                  <th className="pe-4 py-2"></th>
                </tr>
              </thead>
              <tbody>
                {/* Doubled audits for scroll demo */}
                {mockAudits.filter(a => a.agent === activeTab).concat(mockAudits.filter(a => a.agent === activeTab)).map((audit, index) => (
                  <motion.tr 
                    layout
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    key={`${audit.id}-${index}`}
                  >
                    <td className="ps-4 fw-bold text-primary small">{audit.id}</td>
                    <td>
                      <div className="fw-semibold small">{audit.title}</div>
                      <div className="text-muted" style={{ fontSize: '10px' }}>Branch: main • Commit: a8d2f1</div>
                    </td>
                    <td>
                      <div className={`d-flex align-items-center gap-2 small ${audit.status === 'Completed' ? 'text-success' : 'text-primary'}`}>
                        <div className="rounded-circle" style={{ width: '6px', height: '6px', backgroundColor: 'currentColor' }}></div>
                        <span className="fw-medium">{audit.status}</span>
                      </div>
                    </td>
                    <td>
                      <div className="d-flex align-items-center gap-2" style={{ maxWidth: '120px' }}>
                        <div className="flex-grow-1">
                          <div className="progress" style={{ height: '4px' }}>
                            <div className="progress-bar bg-primary" style={{ width: `${audit.confidence}%` }}></div>
                          </div>
                        </div>
                        <span className="fw-bold small">{audit.confidence}%</span>
                      </div>
                    </td>
                    <td><span className="badge bg-light text-dark fw-normal">{audit.time}</span></td>
                    <td>
                      <div className={`badge rounded-pill px-2 py-1 small fw-normal ${
                        audit.risk === 'Low' ? 'bg-success-subtle text-success' : 
                        audit.risk === 'Medium' ? 'bg-warning-subtle text-warning' : 
                        audit.risk === 'High' ? 'bg-danger-subtle text-danger' : 'bg-light text-muted'
                      }`}>
                        {audit.risk}
                      </div>
                    </td>
                    <td className="pe-4 text-end">
                      <button className="btn btn-link text-muted p-0"><MoreHorizontal size={16} /></button>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="p-3 border-top bg-white d-flex justify-content-between align-items-center">
            <span className="small text-muted">Showing live intelligence streams</span>
            <button className="btn btn-sm btn-premium-outline">System Activity Log</button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default AnalyticsSection;
