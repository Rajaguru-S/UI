import React from 'react';
import { motion } from 'framer-motion';
import { Play, ArrowRight, Shield, Zap, BarChart } from 'lucide-react';
import FloatingAgentCards from '../components/FloatingAgentCards';

interface HeroSectionProps {
  onGetStarted: () => void;
  isTransitioning: boolean;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onGetStarted, isTransitioning }) => {
  return (
    <section className="hero-section vh-100 d-flex align-items-center pt-5 overflow-hidden">
      <div className="container">
        <div className="row align-items-center g-5">
          {/* Left Content */}
          <motion.div 
            className="col-lg-6"
            animate={isTransitioning ? { opacity: 0, x: -100, scale: 0.95 } : { opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="badge bg-primary-glow text-primary px-3 py-2 rounded-pill mb-4 border border-primary-glow d-inline-flex align-items-center gap-2 fw-semibold"
            >
              <Zap size={16} /> Enterprise Intelligence Reimagined
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.8 }}
              className="display-3 fw-bold mb-4"
              style={{ lineHeight: 1.1 }}
            >
              AI Agents That <br />
              <span className="premium-gradient-text">Transform Enterprise</span> <br />
              Workflows
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="lead text-muted mb-5 pe-lg-5"
              style={{ fontSize: '1.25rem' }}
            >
              Automate audits, coding operations, clinical workflows, and intelligent enterprise processing using next-generation AI agents built for modern organizations.
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="d-flex flex-wrap gap-3 mb-5"
            >
              <motion.button 
                onClick={onGetStarted}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="btn-premium-primary btn-lg d-flex align-items-center gap-2 px-4 py-3"
              >
                Get Started <ArrowRight size={20} />
              </motion.button>
              
              
            </motion.div>
            
          </motion.div>
          
          {/* Right Content - Floating Cards */}
          <div className="col-lg-6 position-relative">
            <FloatingAgentCards isTransitioning={isTransitioning} />
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
