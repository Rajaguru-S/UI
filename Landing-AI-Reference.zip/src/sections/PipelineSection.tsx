import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileText, ShieldCheck, Layers, Database, BarChart3 } from 'lucide-react';

interface PipelineSectionProps {
  onComplete: () => void;
}

const PipelineSection: React.FC<PipelineSectionProps> = ({ onComplete }) => {
  const [processedCount, setProcessedCount] = useState<number>(0);
  const [activeAgent, setActiveAgent] = useState<number>(0);
  const agents: string[] = ['Coding Agent', 'Clinical Agent', 'IBR Audit Agent', 'Drishti Flow'];

  useEffect(() => {
    const interval = setInterval(() => {
      setProcessedCount(prev => (prev < 100 ? prev + 1 : 100));
    }, 150);
    
    const agentInterval = setInterval(() => {
      setActiveAgent(prev => (prev + 1) % agents.length);
    }, 800);

    const timer = setTimeout(() => {
      onComplete();
    }, 18000);

    return () => {
      clearInterval(interval);
      clearInterval(agentInterval);
      clearTimeout(timer);
    };
  }, [onComplete]);

  return (
    <section className="pipeline-section py-0 vh-100 d-flex flex-column justify-content-center bg-white overflow-hidden position-relative">
      <div className="pt-5 mt-5"></div>
      
      <div className="container text-center mb-4" style={{ zIndex: 50 }}>
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="display-5 fw-bold"
        >
          AI Pipeline in <span className="premium-gradient-text">Action</span>
        </motion.h2>
        <p className="text-muted">Transforming enterprise data into intelligence with multi-agent processing</p>
      </div>

      <div className="pipeline-container position-relative w-100" style={{ height: '450px' }}>
        {/* Background Connection Path */}
        <div 
          className="position-absolute top-50 start-0 w-100" 
          style={{ height: '2px', background: 'linear-gradient(90deg, transparent, rgba(37, 99, 235, 0.1), transparent)', zIndex: 1, transform: 'translateY(-50%)' }}
        ></div>

        {/* Dense Flowing Items Layer */}
        <div className="position-absolute top-0 left-0 w-100 h-100 overflow-hidden" style={{ zIndex: 10 }}>
          {Array.from({ length: 25 }).map((_, i) => (
            <UnifiedFlowItem 
              key={i} 
              delay={i * 0.8} 
              yOffset={(i % 5 - 2) * 45} 
            />
          ))}
        </div>

        {/* Central Core Box */}
        <div className="position-absolute top-50 start-50 translate-middle" style={{ zIndex: 30 }}>
          <div className="position-relative">
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              className="position-absolute top-50 start-50 translate-middle rounded-circle border border-primary-glow"
              style={{ width: '400px', height: '400px', borderStyle: 'dashed', opacity: 0.2, zIndex: -1 }}
            ></motion.div>
            
            <motion.div 
              className="glass-card d-flex flex-column align-items-center justify-content-center p-5 position-relative shadow-lg"
              style={{ width: '280px', height: '280px', border: '2px solid var(--primary-glow)', background: 'rgba(255, 255, 255, 0.98)' }}
            >
              <div className="core-glow position-absolute w-100 h-100 rounded-circle" style={{ background: 'var(--primary-glow)', filter: 'blur(50px)', zIndex: -1 }}></div>
              
              <motion.div 
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="mb-4 text-primary"
              >
                <Layers size={64} />
              </motion.div>

              <AnimatePresence mode="wait">
                <motion.div
                  key={activeAgent}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  transition={{ duration: 0.3 }}
                  className="text-center"
                >
                  <h4 className="fw-bold mb-1" style={{ fontSize: '1.25rem' }}>{agents[activeAgent]}</h4>
                  <span className="small text-muted fw-bold text-uppercase tracking-widest" style={{ fontSize: '9px' }}>Active Processing</span>
                </motion.div>
              </AnimatePresence>

              <div className="mt-4 w-100">
                <div className="d-flex justify-content-between small fw-bold mb-2">
                  <span className="text-muted">SYSTEM LOAD</span>
                  <span className="text-primary">{processedCount}%</span>
                </div>
                <div className="progress" style={{ height: '4px', background: '#f0f0f0' }}>
                  <motion.div 
                    className="progress-bar bg-primary"
                    animate={{ width: `${processedCount}%` }}
                    transition={{ type: "spring", stiffness: 100, damping: 20 }}
                  ></motion.div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Stats Dashboard */}
      <div className="container mt-2" style={{ zIndex: 50 }}>
        <div className="row g-4 justify-content-center text-center">
          <div className="col-6 col-md-3">
            <div className="glass-card p-3 border-0 bg-light-subtle">
              <h2 className="fw-bold mb-0" style={{ fontSize: '1.75rem' }}>
                <motion.span
                  key={processedCount}
                  initial={{ opacity: 0.5, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.1 }}
                >
                  {processedCount}
                </motion.span>
                +
              </h2>
              <p className="text-muted fw-bold small text-uppercase tracking-wider mb-0 mt-2" style={{ fontSize: '0.7rem' }}>Audits Processed</p>
            </div>
          </div>

          {[
            { label: 'AI Accuracy', value: 99.8, suffix: '%', isInteger: false },
            { label: 'Active Agents', value: 4, suffix: '', isInteger: true },
            { label: 'Processing Speed', value: 1.2, suffix: 's', isInteger: false }
          ].map((stat, idx) => (
            <div key={idx} className="col-6 col-md-3">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.2 + (idx * 0.1) }}
                className="glass-card p-3 border-0 bg-light-subtle"
              >
                <h2 className="fw-bold mb-0" style={{ fontSize: '1.75rem' }}>
                  <Counter from={0} to={stat.value} duration={1} isInteger={stat.isInteger} />{stat.suffix}
                </h2>
                <p className="text-muted fw-bold small text-uppercase tracking-wider mb-0 mt-2" style={{ fontSize: '0.7rem' }}>{stat.label}</p>
              </motion.div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const UnifiedFlowItem: React.FC<{ delay: number, yOffset: number }> = ({ delay, yOffset }) => {
  const [phase, setPhase] = useState<'input' | 'output'>('input');

  return (
    <motion.div
      initial={{ left: '-10%', opacity: 0 }}
      animate={{ 
        left: ['-10%', '50%', '110%'],
        opacity: [0, 1, 1, 0]
      }}
      transition={{ 
        duration: 8, 
        repeat: Infinity, 
        delay,
        ease: "linear",
        times: [0, 0.5, 1]
      }}
      onUpdate={(latest) => {
        const leftStr = typeof latest.left === 'string' ? latest.left : '';
        const xVal = parseFloat(leftStr);
        
        if (!isNaN(xVal)) {
          if (xVal >= 50 && phase === 'input') {
            setPhase('output');
          } else if (xVal < 50 && phase === 'output') {
            setPhase('input');
          }
        }
      }}
      className="position-absolute top-50"
      style={{ y: yOffset }}
    >
      <div 
        className={`p-3 glass-card d-flex align-items-center gap-3 transition-all ${phase === 'output' ? 'border-success shadow-lg' : ''}`}
        style={{ 
          width: '230px', 
          backgroundColor: 'rgba(255, 255, 255, 0.98)',
          transform: 'translate(-50%, -50%)',
          border: phase === 'output' ? '2.5px solid #10B981' : '1px solid rgba(0,0,0,0.1)',
        }}
      >
        <div className={`p-2 rounded-3 transition-all ${phase === 'output' ? 'bg-success text-white' : 'bg-primary-glow text-primary'}`}>
          {phase === 'output' ? <BarChart3 size={20} /> : <Database size={20} />}
        </div>
        <div className="flex-grow-1 overflow-hidden">
          <div className={`small fw-bold mb-0 text-truncate ${phase === 'output' ? 'text-success' : ''}`}>
            {phase === 'output' ? 'Analyzed Data' : 'Analyzing Data'}
          </div>
          <div className={`text-muted transition-all ${phase === 'output' ? 'text-success opacity-75' : ''}`} style={{ fontSize: '9px' }}>
            {phase === 'output' ? 'Status: Intelligence' : 'ID: #8329-BX'}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

interface CounterProps {
  from: number;
  to: number;
  duration: number;
  isInteger?: boolean;
}

const Counter: React.FC<CounterProps> = ({ from, to, duration, isInteger = false }) => {
  const [count, setCount] = useState<number>(from);

  useEffect(() => {
    let start = from;
    const end = to;
    const range = end - start;
    if (range === 0 && start === end) return;

    const increment = range / (duration * 60);
    
    const timer = setInterval(() => {
      start += increment;
      if ((range > 0 && start >= end) || (range < 0 && start <= end)) {
        setCount(end);
        clearInterval(timer);
      } else {
        setCount(isInteger ? Math.floor(start) : Math.floor(start * 10) / 10);
      }
    }, 1000 / 60);

    return () => clearInterval(timer);
  }, [from, to, duration, isInteger]);

  return <>{count}</>;
};

export default PipelineSection;
