import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import 'bootstrap/dist/css/bootstrap.min.css';
import './index.scss';

// Components
import Navbar from './components/Navbar';
import HeroSection from './sections/HeroSection';
import PipelineSection from './sections/PipelineSection';
import AnalyticsSection from './sections/AnalyticsSection';
import Footer from './components/Footer';

const App: React.FC = () => {
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);
  const [showPipeline, setShowPipeline] = useState<boolean>(false);
  const [showDashboard, setShowDashboard] = useState<boolean>(false);

  useEffect(() => {
    if (showDashboard) {
      document.body.style.overflow = 'auto';
      document.body.style.height = 'auto';
    } else {
      document.body.style.overflow = 'hidden';
      document.body.style.height = '100vh';
    }
  }, [showDashboard]);

  const handleGetStarted = (): void => {
    setIsTransitioning(true);
    setTimeout(() => {
      setShowPipeline(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 800);
  };

  const handlePipelineComplete = (): void => {
    setShowDashboard(true);
  };

  const handleReset = (): void => {
    setShowPipeline(false);
    setShowDashboard(false);
    setIsTransitioning(false);
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  return (
    <div className="app-container">
      <Navbar onLogoClick={handleReset} />
      
      <main>
        {!showPipeline ? (
          <HeroSection 
            onGetStarted={handleGetStarted} 
            isTransitioning={isTransitioning} 
          />
        ) : (
          <div className="pipeline-experience">
            <AnimatePresence>
              {!showDashboard && (
                <PipelineSection onComplete={handlePipelineComplete} />
              )}
            </AnimatePresence>
            
            {showDashboard && (
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
              >
                <AnalyticsSection />
              </motion.div>
            )}
          </div>
        )}
      </main>

      {(!isTransitioning || showDashboard) && <Footer />}
      
      {/* Global Background Elements */}
      <div className="fixed-top w-100 h-100 grid-bg" style={{ zIndex: -2, opacity: 0.4 }}></div>
      <div className="glow-blob" style={{ top: '10%', right: '5%', width: '400px', height: '400px', background: 'var(--primary-glow)' }}></div>
      <div className="glow-blob" style={{ bottom: '20%', left: '10%', width: '300px', height: '300px', background: 'var(--secondary)', opacity: 0.1 }}></div>
    </div>
  );
}

export default App;
