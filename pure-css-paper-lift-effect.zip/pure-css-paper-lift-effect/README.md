# Pure CSS Paper Lift Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/Fairytale/pen/KKKJNbG](https://codepen.io/Fairytale/pen/KKKJNbG).

