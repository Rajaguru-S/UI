// types.ts
export type Client = {
  id: string;
  label: string;
  value: number;
  color?: string;
};

export type Program = {
  id: string;
  name: string;
  clientId: string;
  value: number;
};

export type DocumentStatus = {
  programId: string;
  status: 'success' | 'failure' | 'inprogress' | 'not_started';
  count: number;
};

export type ChartData = {
  clients: Client[];
  programs: Program[];
  documentStatuses: DocumentStatus[];
};
