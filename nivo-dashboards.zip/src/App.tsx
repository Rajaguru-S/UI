// App.tsx
import React from 'react';
import ClientProgramCharts from './ClientProgramCharts';
import { ChartData } from './types';

const sampleData: ChartData = {
  clients: [
    { id: 'client1', label: 'Client A', value: 35 },
    { id: 'client2', label: 'Client B', value: 25 },
    { id: 'client3', label: 'Client C', value: 20 },
    { id: 'client4', label: 'Client D', value: 20 },
  ],
  programs: [
    { id: 'program1', name: 'Program 1', clientId: 'client1', value: 10 },
    { id: 'program2', name: 'Program 2', clientId: 'client1', value: 15 },
    { id: 'program3', name: 'Program 3', clientId: 'client1', value: 10 },
    { id: 'program4', name: 'Program 4', clientId: 'client2', value: 8 },
    { id: 'program5', name: 'Program 5', clientId: 'client2', value: 7 },
    { id: 'program6', name: 'Program 6', clientId: 'client2', value: 10 },
    { id: 'program7', name: 'Program 7', clientId: 'client3', value: 5 },
    { id: 'program8', name: 'Program 8', clientId: 'client3', value: 15 },
    { id: 'program9', name: 'Program 9', clientId: 'client4', value: 10 },
    { id: 'program10', name: 'Program 10', clientId: 'client4', value: 10 },
  ],
  documentStatuses: [
    { programId: 'program1', status: 'success', count: 5 },
    { programId: 'program1', status: 'failure', count: 2 },
    { programId: 'program1', status: 'inprogress', count: 3 },
    { programId: 'program1', status: 'not_started', count: 0 },
    { programId: 'program2', status: 'success', count: 10 },
    { programId: 'program2', status: 'failure', count: 1 },
    { programId: 'program2', status: 'inprogress', count: 4 },
    { programId: 'program2', status: 'not_started', count: 0 },
    // Add more document statuses for other programs...
  ],
};

const App: React.FC = () => {
  return (
    <div style={{ height: '100vh' }}>
      <ClientProgramCharts data={sampleData} />
    </div>
  );
};

export default App;
