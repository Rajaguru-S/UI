# Pure CSS Click Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/doggard/pen/dXYzjW](https://codepen.io/doggard/pen/dXYzjW).

