import './App.css';
import DocumentList from './DocumentList';

function App() {
  return (
    <>
      <DocumentList />
    </>
  );
}

export default App;
