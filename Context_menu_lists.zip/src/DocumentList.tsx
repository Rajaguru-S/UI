import React, { useState, useEffect } from 'react';

interface Document {
  id: number;
  name: string;
  isPrimary: boolean;
}

interface ContextMenu {
  visible: boolean;
  x: number;
  y: number;
  documentId: number | null;
}

const initialDocuments: Document[] = Array.from({ length: 50 }, (_, i) => ({
  id: i + 1,
  name: `Document ${i + 1}`,
  isPrimary: i === 0,
}));

const DocumentList: React.FC = () => {
  const [documents, setDocuments] = useState<Document[]>(initialDocuments);
  const [contextMenu, setContextMenu] = useState<ContextMenu>({
    visible: false,
    x: 0,
    y: 0,
    documentId: null,
  });

  const makePrimary = (id: number) => {
    const newDocs = documents.map((doc) => ({
      ...doc,
      isPrimary: doc.id === id,
    }));

    const primaryDoc = newDocs.find((doc) => doc.id === id)!;
    const secondaryDocs = newDocs.filter((doc) => doc.id !== id);

    setDocuments([primaryDoc, ...secondaryDocs]);
    closeContextMenu();
  };

  const openContextMenu = (
    e: React.MouseEvent<HTMLDivElement>,
    doc: Document
  ) => {
    e.preventDefault();
    if (!doc.isPrimary) {
      setContextMenu({
        visible: true,
        x: e.pageX,
        y: e.pageY,
        documentId: doc.id,
      });
    }
  };

  const closeContextMenu = () => {
    setContextMenu({ visible: false, x: 0, y: 0, documentId: null });
  };

  useEffect(() => {
    const handleClick = () => closeContextMenu();
    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  return (
    <div
      style={{
        maxHeight: '400px',
        overflowY: 'auto',
        border: '1px solid #ccc',
        padding: 8,
      }}
    >
      {documents.map((doc) => (
        <div
          key={doc.id}
          onContextMenu={(e) => openContextMenu(e, doc)}
          style={{
            padding: '10px',
            marginBottom: '5px',
            backgroundColor: doc.isPrimary ? '#e0ffe0' : '#f0f0f0',
            cursor: doc.isPrimary ? 'default' : 'context-menu',
          }}
        >
          {doc.name} {doc.isPrimary && '(Primary)'}
        </div>
      ))}

      {contextMenu.visible && (
        <ul
          style={{
            position: 'absolute',
            top: contextMenu.y,
            left: contextMenu.x,
            listStyle: 'none',
            margin: 0,
            padding: '6px 0',
            backgroundColor: 'white',
            boxShadow: '0 2px 10px rgba(0,0,0,0.2)',
            borderRadius: '4px',
            zIndex: 1000,
            minWidth: '140px',
          }}
        >
          <li
            onClick={() =>
              contextMenu.documentId && makePrimary(contextMenu.documentId)
            }
            style={{
              padding: '8px 16px',
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              userSelect: 'none',
            }}
          >
            Make Primary
          </li>
        </ul>
      )}
    </div>
  );
};

export default DocumentList;
