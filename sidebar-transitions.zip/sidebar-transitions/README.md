# Sidebar Transitions

A Pen created on CodePen.io. Original URL: [https://codepen.io/kyunwang/pen/zNOoxb](https://codepen.io/kyunwang/pen/zNOoxb).

Found an beautiful demo from Tympanus.com(Codrops). But  honestly I didn't fully understand the Js they used. So I attempted to simplify it a bit.

HTML & CSS 100% from Tympanus
Only the JS has been made/modified by me.

Source: https://tympanus.net/codrops/2013/08/28/transitions-for-off-canvas-navigations/