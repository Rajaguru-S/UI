# Angled Border / Background CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/daviddarnes/pen/BazQJd](https://codepen.io/daviddarnes/pen/BazQJd).

