# Elastic Tabs

A Pen created on CodePen.io. Original URL: [https://codepen.io/nenadkaevik/pen/odyrGm](https://codepen.io/nenadkaevik/pen/odyrGm).

