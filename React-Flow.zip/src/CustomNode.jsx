import React, { memo } from "react";
import { Handle, Position } from "@xyflow/react";

function CustomNode({ data }) {
  return (
    <div className="custom__nodes">
      <div className="custom__nodes__status">{data.status}</div>
      <div>
        <div>{data.substatus}</div>
      </div>

      <Handle
        type="target"
        position={Position.Top}
        className="custom__handle"
      />
      <Handle
        type="source"
        position={Position.Bottom}
        className="custom__handle"
      />
    </div>
  );
}

export default memo(CustomNode);
