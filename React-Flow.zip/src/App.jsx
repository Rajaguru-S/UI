import React, { useCallback } from "react";
import {
  ReactFlow,
  useNodesState,
  useEdgesState,
  addEdge,
  MiniMap,
  Controls,
  Background,
  BackgroundVariant,
  MarkerType,
} from "@xyflow/react";

import "@xyflow/react/dist/base.css";

import "./tailwind-config.js";
import CustomNode from "./CustomNode";

const nodeTypes = {
  custom: CustomNode,
};

const initNodes = [
  {
    id: "1",
    type: "custom",
    sourcePosition: "right",
    data: { status: "Select", substatus: "Selection Loaded" },
    position: { x: 0, y: 50 },
  },
  {
    id: "2",
    type: "custom",
    sourcePosition: "right",
    targetPosition: "left",
    data: { status: "Request", substatus: "Request Records 1 Client" },
    position: { x: -200, y: 200 },
  },
  {
    id: "3",
    type: "custom",
    sourcePosition: "right",
    targetPosition: "left",
    data: {
      status: "Prepare Audit",
      substatus: "Received Records from Client",
    },
    position: { x: 200, y: 200 },
  },
];

const initEdges = [
  {
    id: "e1-2",
    source: "1",
    target: "2",
    type: "smoothstep",
    animated: true,
    label: "Selection to Request",
    markerEnd: {
      type: MarkerType.ArrowClosed,
    },
  },
  {
    id: "e1-3",
    source: "1",
    target: "3",
    type: "smoothstep",
    animated: true,
    markerEnd: {
      type: MarkerType.ArrowClosed,
    },
  },

  {
    id: "e3-1",
    source: "3",
    target: "1",
    animated: true,
    type: "smoothstep",
    label: "Audit Failed return to Selection",
    markerEnd: {
      type: MarkerType.ArrowClosed,
    },
  },
];

const Flow = () => {
  const [nodes, setNodes, onNodesChange] = useNodesState(initNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initEdges);

  const onConnect = useCallback(
    (params) => setEdges((eds) => addEdge(params, eds)),
    []
  );

  return (
    <div style={{ width: "100vw", height: "100vh" }}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        nodeTypes={nodeTypes}
        fitView
        fitViewOptions={{ maxZoom: 1 }}
      >
        <MiniMap />
        <Controls />
        <Background variant={BackgroundVariant.Dots} />
      </ReactFlow>
    </div>
  );
};

export default Flow;

// import React, { useCallback } from "react";
// import {
//   ReactFlow,
//   addEdge,
//   ConnectionLineType,
//   Panel,
//   useNodesState,
//   useEdgesState,
// } from "@xyflow/react";
// import dagre from "dagre";

// import { initialNodes, initialEdges } from "./nodes-edges.js";

// import "@xyflow/react/dist/style.css";

// const dagreGraph = new dagre.graphlib.Graph();
// dagreGraph.setDefaultEdgeLabel(() => ({}));

// const nodeWidth = 172;
// const nodeHeight = 36;

// const getLayoutedElements = (nodes, edges, direction = "TB") => {
//   const isHorizontal = direction === "LR";
//   dagreGraph.setGraph({ rankdir: direction });

//   nodes.forEach((node) => {
//     dagreGraph.setNode(node.id, { width: nodeWidth, height: nodeHeight });
//   });

//   edges.forEach((edge) => {
//     dagreGraph.setEdge(edge.source, edge.target);
//   });

//   dagre.layout(dagreGraph);

//   const newNodes = nodes.map((node) => {
//     const nodeWithPosition = dagreGraph.node(node.id);
//     const newNode = {
//       ...node,
//       targetPosition: isHorizontal ? "left" : "top",
//       sourcePosition: isHorizontal ? "right" : "bottom",
//       // We are shifting the dagre node position (anchor=center center) to the top left
//       // so it matches the React Flow node anchor point (top left).
//       position: {
//         x: nodeWithPosition.x - nodeWidth / 2,
//         y: nodeWithPosition.y - nodeHeight / 2,
//       },
//     };

//     return newNode;
//   });

//   return { nodes: newNodes, edges };
// };

// const { nodes: layoutedNodes, edges: layoutedEdges } = getLayoutedElements(
//   initialNodes,
//   initialEdges
// );

// const LayoutFlow = () => {
//   const [nodes, setNodes, onNodesChange] = useNodesState(layoutedNodes);
//   const [edges, setEdges, onEdgesChange] = useEdgesState(layoutedEdges);

//   const onConnect = useCallback(
//     (params) =>
//       setEdges((eds) =>
//         addEdge(
//           { ...params, type: ConnectionLineType.SmoothStep, animated: true },
//           eds
//         )
//       ),
//     []
//   );
//   const onLayout = useCallback(
//     (direction) => {
//       const { nodes: layoutedNodes, edges: layoutedEdges } =
//         getLayoutedElements(nodes, edges, direction);

//       setNodes([...layoutedNodes]);
//       setEdges([...layoutedEdges]);
//     },
//     [nodes, edges]
//   );

//   return (
//     <div style={{ width: "100vw", height: "100vh" }}>
//       <ReactFlow
//         nodes={nodes}
//         edges={edges}
//         onNodesChange={onNodesChange}
//         onEdgesChange={onEdgesChange}
//         onConnect={onConnect}
//         connectionLineType={ConnectionLineType.SmoothStep}
//         fitView
//       >
//         <Panel position="top-right">
//           <button onClick={() => onLayout("TB")}>vertical layout</button>
//           <button onClick={() => onLayout("LR")}>horizontal layout</button>
//         </Panel>
//       </ReactFlow>
//     </div>
//   );
// };

// export default LayoutFlow;
