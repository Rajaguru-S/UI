tailwind.config = {
  important: true,
};
