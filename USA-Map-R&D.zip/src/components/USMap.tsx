// import React, { useState } from "react";
// import {
//   ComposableMap,
//   Geographies,
//   Geography,
//   Marker,
// } from "react-simple-maps";
// import { geoAlbersUsa, geoCentroid } from "d3-geo";
// import usMapData from "../data/us-topo.json";

// interface Geo {
//   id: string;
//   properties: {
//     name: string;
//   };
//   rsmKey: string;
// }

// const USMap: React.FC = () => {
//   const [activeState, setActiveState] = useState<string | null>(null);
//   const [hoveredState, setHoveredState] = useState<Geo | null>(null);

//   const handleClick = (geo: Geo) => {
//     setActiveState(geo.id);
//   };

//   const handleHover = (geo: Geo) => {
//     setHoveredState(geo);
//   };

//   const handleLeave = () => {
//     setHoveredState(null);
//   };

//   // Create the projection function
//   const projection = geoAlbersUsa();

//   return (
//     <ComposableMap
//       projection={projection}
//       projectionConfig={{ scale: 800 }}
//       width={900}
//       height={500}
//     >
//       <Geographies geography={usMapData}>
//         {({ geographies }) => {
//           // Check if geographies is an array
//           if (!Array.isArray(geographies)) {
//             console.error("Geographies data is not in the expected format.");
//             return null;
//           }

//           return geographies.map((geo: Geo) => {
//             // Calculate the centroid of the state
//             const centroid = geoCentroid(geo);

//             return (
//               <React.Fragment key={geo.rsmKey}>
//                 <Geography
//                   geography={geo}
//                   onClick={() => handleClick(geo)}
//                   onMouseEnter={() => handleHover(geo)}
//                   onMouseLeave={handleLeave}
//                   style={{
//                     default: {
//                       fill: activeState === geo.id ? "#FF5722" : "#ECEFF1",
//                       stroke: "#607D8B",
//                       strokeWidth: 0.75,
//                       outline: "none",
//                       boxShadow:
//                         activeState === geo.id
//                           ? "0 4px 8px rgba(0,0,0,0.2)"
//                           : "none",
//                     },
//                     hover: {
//                       fill: "#FFC107",
//                       stroke: "#607D8B",
//                       strokeWidth: 0.75,
//                       outline: "none",
//                     },
//                     pressed: {
//                       fill: "#FF5722",
//                       stroke: "#607D8B",
//                       strokeWidth: 0.75,
//                       outline: "none",
//                     },
//                   }}
//                 />
//                 {hoveredState && hoveredState.rsmKey === geo.rsmKey && (
//                   <Marker coordinates={centroid}>
//                     <text
//                       textAnchor="middle"
//                       y={-10}
//                       style={{
//                         fill: "#000",
//                         fontSize: "12px",
//                         fontWeight: "bold",
//                         backgroundColor: "#FFF",
//                         padding: "2px 5px",
//                         borderRadius: "4px",
//                         boxShadow: "0 2px 4px rgba(0,0,0,0.2)",
//                       }}
//                     >
//                       {hoveredState.properties.name}
//                     </text>
//                   </Marker>
//                 )}
//               </React.Fragment>
//             );
//           });
//         }}
//       </Geographies>
//     </ComposableMap>
//   );
// };

// export default USMap;

// // src/components/Map.js
// import {
//   ComposableMap,
//   Geographies,
//   Geography,
//   Marker,
// } from "react-simple-maps";
// import { stateCentroids } from "../data/states";

// const geoUrl = "https://cdn.jsdelivr.net/npm/us-atlas@3/states-10m.json";

// const Map = () => {
//   return (
//     <ComposableMap
//       projection="geoAlbersUsa"
//       width={1200}
//       height={800}
//       projectionConfig={{ scale: 1000 }}
//     >
//       <Geographies geography={geoUrl}>
//         {({ geographies }) =>
//           geographies.map((geo) => (
//             <Geography
//               key={geo.rsmKey}
//               geography={geo}
//               fill="#EAEAEC"
//               stroke="#D6D6DA"
//               strokeWidth={0.5}
//             />
//           ))
//         }
//       </Geographies>

//       {stateCentroids.map(({ name, coordinates, abbrev }) => (
//         <Marker key={abbrev} coordinates={coordinates}>
//           <g transform="translate(-30 -8)">
//             <rect
//               width={name.length * 6.5} // Dynamic width based on name length
//               height="16"
//               fill="white"
//               opacity="0.9"
//               rx="4"
//             />
//             <text
//               x={name.length * 3.25} // Center text in dynamic width
//               y="12"
//               fontSize="10"
//               fontFamily="Arial"
//               textAnchor="middle"
//               fill="#333"
//             >
//               {name}
//             </text>
//           </g>
//         </Marker>
//       ))}
//     </ComposableMap>
//   );
// };

// export default Map;

// src/components/Map.js
import { useState } from "react";
import {
  ComposableMap,
  Geographies,
  Geography,
  Marker,
  Annotation,
} from "react-simple-maps";
import { stateCentroids } from "../data/states";

const geoUrl = "https://cdn.jsdelivr.net/npm/us-atlas@3/states-10m.json";

const Map = () => {
  const [highlightedState, setHighlightedState] = useState(null);

  // States needing special annotation placement
  const problematicStates = ["RI", "MA", "CT", "NJ", "MD", "DE", "VT", "NH"];

  return (
    <ComposableMap
      projection="geoAlbersUsa"
      width={1200}
      height={800}
      projectionConfig={{ scale: 1000 }}
    >
      <Geographies geography={geoUrl}>
        {({ geographies }) =>
          geographies.map((geo) => (
            <Geography
              key={geo.rsmKey}
              geography={geo}
              fill={
                geo.properties.name === highlightedState ? "#FFD700" : "#EAEAEC"
              }
              stroke="#D6D6DA"
              strokeWidth={0.5}
              onMouseEnter={() => setHighlightedState(geo.properties.name)}
              onMouseLeave={() => setHighlightedState(null)}
              style={{
                default: { outline: "none" },
                hover: { fill: "#F53" },
                pressed: { fill: "#E42" },
              }}
            />
          ))
        }
      </Geographies>

      {stateCentroids.map((state) => {
        if (problematicStates.includes(state.abbrev)) {
          return (
            <Annotation
              key={state.abbrev}
              subject={state.coordinates}
              dx={state.dx || -50}
              dy={state.dy || -30}
              connectorProps={{
                stroke: "#333",
                strokeWidth: 1,
                strokeLinecap: "round",
              }}
            >
              <g
                transform={`translate(${state.textDx || 0} ${
                  state.textDy || 0
                })`}
              >
                <rect
                  width={state.name.length * 6.5}
                  height="16"
                  fill="white"
                  opacity="0.9"
                  rx="4"
                />
                <text
                  x={state.name.length * 3.25}
                  y="12"
                  fontSize="10"
                  fontFamily="Arial"
                  textAnchor="middle"
                  fill={highlightedState === state.name ? "#F53" : "#333"}
                  fontWeight={
                    highlightedState === state.name ? "bold" : "normal"
                  }
                >
                  {state.name}
                </text>
              </g>
            </Annotation>
          );
        }

        return (
          <Marker key={state.abbrev} coordinates={state.coordinates}>
            <g transform="translate(-30 -8)">
              <rect
                width={state.name.length * 6.5}
                height="16"
                fill="white"
                opacity="0.9"
                rx="4"
              />
              <text
                x={state.name.length * 3.25}
                y="12"
                fontSize="10"
                fontFamily="Arial"
                textAnchor="middle"
                fill={highlightedState === state.name ? "#F53" : "#333"}
                fontWeight={highlightedState === state.name ? "bold" : "normal"}
              >
                {state.name}
              </text>
            </g>
          </Marker>
        );
      })}

      {/* Highlight Annotation */}
      {highlightedState && (
        <Annotation
          subject={
            stateCentroids.find((s) => s.name === highlightedState)?.coordinates
          }
          dx={50}
          dy={-50}
          connectorProps={{
            stroke: "#F53",
            strokeWidth: 2,
            strokeLinecap: "round",
          }}
        >
          <rect width="140" height="40" fill="white" rx="4" />
          <text
            x="70"
            y="20"
            fontSize="12"
            fontFamily="Arial"
            textAnchor="middle"
            fill="#F53"
            fontWeight="bold"
          >
            {highlightedState}
          </text>
        </Annotation>
      )}
    </ComposableMap>
  );
};

export default Map;
