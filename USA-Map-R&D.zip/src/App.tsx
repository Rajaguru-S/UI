import React from "react";
import USMap from "./components/USMap";
import "./App.css";

const App: React.FC = () => {
  return (
    <div className="App">
      <h1>US Map with Hover and Click Interactions</h1>
      <USMap />
    </div>
  );
};

export default App;
