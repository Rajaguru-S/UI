# Timeline of HTML

A Pen created on CodePen.io. Original URL: [https://codepen.io/vcurd/pen/rNBPQWr](https://codepen.io/vcurd/pen/rNBPQWr).

Take an ordered list and make it a responsive timeline. All the data is from https://en.wikipedia.org/wiki/HTML