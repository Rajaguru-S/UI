# CSS Only Dark Mode Toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/justin-schroeder/pen/zYyVvxQ](https://codepen.io/justin-schroeder/pen/zYyVvxQ).

A simple CSS only darkmode selector, including sun and moon icons in CSS only.