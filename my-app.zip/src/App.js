import React, { useEffect, useState } from 'react';
import { ContextMenuTrigger, ContextMenu, ContextMenuItem } from 'rctx-contextmenu';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import "./App.css"

function App() {
  // Function to get the Selected Text
  const [copy, setCopy] = useState(true)
  const [selectText, setSelectText] = useState("");


  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleSelection = () => {
    const text = document.getSelection().toString();
    if (text) {
      setCopy(false)
      setSelectText(text)

    }else{
      setCopy(true)
      setSelectText("")
    }
  }

      
   useEffect(() => {
     document.addEventListener('selectionchange', handleSelection);
     return () => {
       document.removeEventListener('selectionchange', handleSelection);
     };
    });
  const copyText = () => {



if(selectText){
  
    if(navigator.clipboard) {
        navigator.clipboard.writeText(selectText).then(() => {
          copyToast("Copied...! To Paste Use (Ctrl+V)")
        })
    } else {
     
     copyToast("Browser Not compatible")
    }
  }else{
   copyToast("No text copied")
  }
    
}

const pageRefresh = ()=>{
  window.location.reload(true);
}
const pagePrint = ()=>{
  window.print();
}
const copyToast = (msg) => {
  var x = document.getElementById("snackbar");
  x.className = "show";
  x.innerHTML = msg;
  setTimeout(function(){ x.className = x.className.replace("show", ""); }, 5000);
}
  return (
    <div className="app">
      

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>Woohoo, you are reading this text in a modal!

          <p>
          <iframe style={{width:"100%", height:"250px"}} src="https://www.youtube.com/embed/5IWPOKlpqBQ?si=_wIvp5SDmso3LYLF" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
          </p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
      <ContextMenuTrigger
        id="my-context-menu-1"
      >
        <div className="box">
          Right Click On Me
        </div>
        <div className="box">
          Right Click On Me 2
        </div>
        <div className="box">
          Right Click On Me 3
        </div>
        <div className="box">
          Right Click On Me 4
        </div>
        <div className="box">
        <input type='text'  id="textbox"/>
        </div>
      </ContextMenuTrigger>

      <ContextMenu id="my-context-menu-1">
      <ContextMenuItem  onClick={handleShow}>Get Info</ContextMenuItem>
      <ContextMenuItem  onClick={handleShow}>Video tutorial</ContextMenuItem>
        <ContextMenuItem onClick={copyText} disabled={copy}><div className='d-flex justify-content-between'><div>Copy</div> <div>Ctrl+C</div></div></ContextMenuItem>
        <ContextMenuItem  disabled={true}><div className='d-flex justify-content-between'><div>Paste Use</div> <div>Ctrl+V</div></div> </ContextMenuItem>
        <ContextMenuItem onClick={pageRefresh}><div className='d-flex justify-content-between'><div>Reload</div> <div>Ctrl+R</div></div></ContextMenuItem>
        <ContextMenuItem onClick={pagePrint}><div className='d-flex justify-content-between'><div>Print</div> <div>Ctrl+P</div></div></ContextMenuItem>
   
      </ContextMenu>

      <div id="snackbar">Some text some message..</div>
    </div>
  );
}

export default App;