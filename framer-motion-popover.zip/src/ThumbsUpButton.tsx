import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import './ThumbsUpButton.css';

interface Props {
  id: number;
}

const balloonVariants = {
  initial: {
    opacity: 0,
    scale: 0.6,
    y: -10,
  },
  animate: {
    opacity: 1,
    scale: 1,
    y: -20,
    transition: {
      type: 'spring',
      stiffness: 260,
      damping: 20,
    },
  },
  exit: {
    opacity: 0,
    scale: 0.6,
    y: -10,
    transition: {
      duration: 0.2,
      ease: 'easeInOut',
    },
  },
};

export const ThumbsUpButton: React.FC<Props> = ({ id }) => {
  const [checked, setChecked] = useState(true);
  const [showPopover, setShowPopover] = useState(false);
  const popoverRef = useRef<HTMLDivElement | null>(null);

  const handleClick = () => {
    if (checked) {
      setChecked(false);
      setShowPopover(true);
    } else {
      setChecked(true);
    }
  };

  const handleAction = (action: string) => {
    console.log(`Action clicked: ${action}`);
    setShowPopover(false);
  };

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (
        popoverRef.current &&
        !popoverRef.current.contains(e.target as Node)
      ) {
        setShowPopover(false);
      }
    };

    if (showPopover) {
      document.addEventListener('mousedown', handleOutsideClick);
    }
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [showPopover]);

  return (
    <div className="thumb-wrapper">
      <button
        className={`thumb-button ${checked ? 'checked' : ''}`}
        onClick={handleClick}
      >
        👍 {checked ? 'Liked' : 'Unliked'}
      </button>

      <AnimatePresence>
        {showPopover && (
          <motion.div
            ref={popoverRef}
            className="thumb-popover"
            variants={balloonVariants}
            initial="initial"
            animate="animate"
            exit="exit"
          >
            <div className="popover-arrow" />
            <div className="popover-content">
              <p className="popover-title">What would you like to do?</p>
              <div className="popover-actions">
                <button onClick={() => handleAction('Undo')}>Undo</button>
                <button onClick={() => handleAction('Feedback')}>
                  Feedback
                </button>
                <button onClick={() => handleAction('Dismiss')}>Dismiss</button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
