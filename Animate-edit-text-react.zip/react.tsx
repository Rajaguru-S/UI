import React, { useState } from "react";
import "./App.css";

const App = () => {
  const [editableText, setEditableText] = useState(""); // For the textarea content
  const [movingItems, setMovingItems] = useState([]); // For tracking items being animated
  const [hiddenItems, setHiddenItems] = useState([]); // For tracking items that should disappear

  const textItems = [
    { id: 1, content: "This is the first text to edit." },
    { id: 2, content: "This is the second text to edit." },
    { id: 3, content: "This is the third text to edit." },
  ];

  const handleEdit = (id, content) => {
    // Start the animation
    setMovingItems((prev) => [...prev, id]);

    // After animation duration (500ms), update the textarea and hide the item
    setTimeout(() => {
      setEditableText(content);
      setHiddenItems((prev) => [...prev, id]);
      setMovingItems((prev) => prev.filter((itemId) => itemId !== id)); // Remove from moving list
    }, 500); // Matches the CSS animation duration
  };

  return (
    <div className="container">
      {/* Fixed Text Area */}
      <div className="text-area">
        <textarea
          id="editable-text"
          value={editableText}
          placeholder="Edit text here..."
          readOnly
        />
      </div>

      {/* List of Editable Text Items */}
      <div className="text-items">
        {textItems.map((item) => (
          <div
            key={item.id}
            className={`text-item ${
              movingItems.includes(item.id) ? "moving" : ""
            } ${hiddenItems.includes(item.id) ? "hidden" : ""}`}
          >
            <span className="text-content">{item.content}</span>
            <button
              className="edit-btn"
              onClick={() => handleEdit(item.id, item.content)}
            >
              Edit
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;

<style>
    /* General Styles */
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  height: 100vh;
  justify-content: flex-start;
  align-items: center;
}

.container {
  width: 100%;
  max-width: 600px;
}

/* Text Area */
.text-area {
  width: 100%;
  position: fixed;
  top: 20px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  justify-content: center;
}

textarea {
  width: 90%;
  height: 100px;
  font-size: 16px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

/* Text Items */
.text-items {
  margin-top: 150px;
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.text-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 5px;
  background-color: #f9f9f9;
  transition: transform 0.5s ease-in-out, opacity 0.5s ease-in-out;
}

.text-item.moving {
  transform: translateY(-120px);
  opacity: 0;
  pointer-events: none; /* Prevent interaction during animation */
}

.text-item.hidden {
  display: none; /* Hide completely after the animation */
}

.text-item span {
  font-size: 16px;
}

button {
  margin-left: 10px;
  padding: 5px 10px;
  font-size: 14px;
  cursor: pointer;
  border: none;
  background-color: #007bff;
  color: #fff;
  border-radius: 5px;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #0056b3;
}

</style>