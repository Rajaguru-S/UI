import React, { useRef, useEffect, useState } from 'react';

const GalaxyPage: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mouse, setMouse] = useState({ x: 0.5, y: 0.5 }); // Normalized mouse pos (0-1)
  const starsRef = useRef<Star[]>([]);
  const circleDone = useRef(false);
  const targetMouse = useRef({ x: 0.5, y: 0.5 }); // For smooth animation

  interface Star {
    baseX: number;
    baseY: number;
    x: number;
    y: number;
    radius: number;
    baseAlpha: number;
    alpha: number;
    blinkSpeed: number;
    blinkOffset: number;
    scale: number;
    visible: boolean;
    appearTime: number;
    depth: number;
  }

  const createStars = (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number
  ) => {
    const stars: Star[] = [];
    for (let i = 0; i < 100; i++) {
      const baseX = width / 2 + (Math.random() - 0.5) * 400;
      const baseY = height / 2 + (Math.random() - 0.5) * 300;
      const radius = Math.random() * 1.5 + 0.5;
      const baseAlpha = Math.random() * 0.5 + 0.4;
      const blinkSpeed = Math.random() * 0.005 + 0.002;
      const blinkOffset = Math.random() * Math.PI * 2;
      const appearTime = i * 30;
      const depth = Math.random() * 2 + 1;
      stars.push({
        baseX,
        baseY,
        x: baseX,
        y: baseY,
        radius,
        baseAlpha,
        alpha: 0,
        blinkSpeed,
        blinkOffset,
        scale: 1,
        visible: false,
        appearTime,
        depth,
      });
    }
    starsRef.current = stars;
  };

  const drawHalfCircle = (
    ctx: CanvasRenderingContext2D,
    progress: number,
    width: number,
    height: number
  ) => {
    const radius = width / 3;
    ctx.strokeStyle = 'rgba(255,255,255,0.6)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    const startAngle = Math.PI;
    const endAngle = Math.PI + Math.PI * progress;
    ctx.arc(width / 2, height, radius, startAngle, endAngle);
    ctx.stroke();
  };

  const drawStars = (
    ctx: CanvasRenderingContext2D,
    time: number,
    elapsedSinceCircle: number
  ) => {
    const stars = starsRef.current;

    stars.forEach((star) => {
      if (!star.visible && elapsedSinceCircle * 1000 >= star.appearTime) {
        star.visible = true;
      }

      if (!star.visible) return;

      if (star.alpha < star.baseAlpha) {
        star.alpha += 0.01;
      }

      const blink = Math.sin(time * star.blinkSpeed + star.blinkOffset) * 0.3;
      const blinkingAlpha = star.baseAlpha + blink;
      star.alpha += (blinkingAlpha - star.alpha) * 0.05;

      // Calculate target parallax offset
      const offsetX = ((mouse.x - 0.5) * 50) / star.depth;
      const offsetY = ((mouse.y - 0.5) * 30) / star.depth;

      // Smoothly interpolate star.x/y toward target position
      star.x += (star.baseX + offsetX - star.x) * 0.05;
      star.y += (star.baseY + offsetY - star.y) * 0.05;

      ctx.save();
      ctx.beginPath();
      ctx.globalAlpha = star.alpha;
      ctx.fillStyle = '#ffffff';
      ctx.arc(star.x, star.y, star.radius * star.scale, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let startTime: number | null = null;
    let circleEndTime: number | null = null;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      createStars(ctx, canvas.width, canvas.height);
    };

    resize();
    window.addEventListener('resize', resize);

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const elapsed = (timestamp - startTime) / 1000;
      const progress = Math.min(elapsed / 2, 1);

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      drawHalfCircle(ctx, progress, canvas.width, canvas.height);

      if (progress === 1 && !circleDone.current) {
        circleDone.current = true;
        circleEndTime = timestamp;
      }

      // Smoothly interpolate mouse value toward targetMouse (for parallax easing)
      mouse.x += (targetMouse.current.x - mouse.x) * 0.05;
      mouse.y += (targetMouse.current.y - mouse.y) * 0.05;

      if (circleDone.current && circleEndTime) {
        drawHalfCircle(ctx, 1, canvas.width, canvas.height);
        const elapsedSinceCircle = (timestamp - circleEndTime) / 1000;
        drawStars(ctx, timestamp, elapsedSinceCircle);
      }

      animationFrameId = requestAnimationFrame(animate);
    };

    animationFrameId = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []); // ✅ only run once

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const x = e.clientX / window.innerWidth;
    const y = e.clientY / window.innerHeight;
    targetMouse.current = { x, y };
  };

  return (
    <canvas
      ref={canvasRef}
      onMouseMove={handleMouseMove}
      style={{
        display: 'block',
        width: '100vw',
        height: '100vh',
        background: 'radial-gradient(ellipse at center, #000015, #000000)',
        cursor: 'none',
      }}
    />
  );
};

export default GalaxyPage;
