// App.tsx
import React from 'react';
import GalaxyPage from './GalaxyPage';

const App: React.FC = () => {
  return <GalaxyPage />;
};

export default App;
