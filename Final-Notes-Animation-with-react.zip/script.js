// Get elements
const editButtons = document.querySelectorAll(".edit-btn");
const textArea = document.getElementById("editable-text");

// Add event listener to each edit button
editButtons.forEach((button) => {
  button.addEventListener("click", (event) => {
    // Get the parent text item and content
    const textItem = event.target.closest(".text-item");
    const textContent = textItem.querySelector(".text-content").textContent;

    // Animate the text item
    textItem.classList.add("moving");

    // Fill the textarea after the animation completes
    setTimeout(() => {
      textArea.value = textContent;

      // After animation completes, hide the text item
      textItem.classList.add("hidden");
    }, 500); // Match this duration to the CSS transition
  });
});
