import React, { useRef, useState, useEffect } from 'react';

type MenuPosition = {
  x: number;
  y: number;
};

const ContextMenu: React.FC<{
  position: MenuPosition;
  visible: boolean;
  onClose: () => void;
  containerRef: React.RefObject<HTMLDivElement>;
}> = ({ position, visible, onClose, containerRef }) => {
  const menuRef = useRef<HTMLDivElement>(null);
  const [adjustedPosition, setAdjustedPosition] =
    useState<MenuPosition>(position);

  useEffect(() => {
    if (visible && containerRef.current && menuRef.current) {
      const containerRect = containerRef.current.getBoundingClientRect();
      const menuRect = menuRef.current.getBoundingClientRect();

      const menuWidth = menuRect.width;
      const menuHeight = menuRect.height;

      const containerWidth = containerRect.width;
      const containerHeight = containerRect.height;

      let x = position.x;
      let y = position.y;

      // Adjust right overflow
      if (x + menuWidth > containerWidth) {
        x = containerWidth - menuWidth;
      }

      // Adjust bottom overflow
      if (y + menuHeight > containerHeight) {
        y = containerHeight - menuHeight;
      }

      // Ensure not negative
      x = Math.max(0, x);
      y = Math.max(0, y);

      setAdjustedPosition({ x, y });
    }
  }, [position, visible, containerRef]);

  if (!visible) return null;

  return (
    <div
      ref={menuRef}
      className="context-menu"
      style={{
        position: 'absolute',
        top: adjustedPosition.y,
        left: adjustedPosition.x,
        backgroundColor: '#fff',
        border: '1px solid #ccc',
        boxShadow: '0px 0px 5px rgba(0,0,0,0.2)',
        zIndex: 1000,
      }}
      onClick={onClose}
    >
      <div className="menu-item">Add</div>
      <div className="menu-item">Delete</div>
      <div className="menu-item">Update</div>
    </div>
  );
};

const App: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [menuPosition, setMenuPosition] = useState<MenuPosition>({
    x: 0,
    y: 0,
  });
  const [menuVisible, setMenuVisible] = useState(false);

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    if (containerRef.current) {
      const containerRect = containerRef.current.getBoundingClientRect();
      const relativeX = e.clientX - containerRect.left;
      const relativeY = e.clientY - containerRect.top;

      setMenuPosition({ x: relativeX, y: relativeY });
      setMenuVisible(true);
    }
  };

  const handleClick = () => {
    setMenuVisible(false);
  };

  return (
    <div
      ref={containerRef}
      onContextMenu={handleContextMenu}
      onClick={handleClick}
      style={{
        width: '600px',
        height: '400px',
        border: '2px solid #000',
        position: 'relative',
        margin: '50px auto',
        userSelect: 'none',
      }}
    >
      <p>Right-click inside this box to show the context menu.</p>

      <ContextMenu
        position={menuPosition}
        visible={menuVisible}
        onClose={() => setMenuVisible(false)}
        containerRef={containerRef}
      />
    </div>
  );
};

export default App;
