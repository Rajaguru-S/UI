
 $('.expand').click(function(){
            $('.expand').toggleClass('active');
            $('.model').toggleClass('active');
        });
    