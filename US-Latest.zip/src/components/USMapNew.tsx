// src/components/USMap.tsx
import { useState, useEffect } from "react";
import {
  ComposableMap,
  Geographies,
  Geography,
  Marker,
  Annotation,
} from "react-simple-maps";
import { stateCentroids, StateCentroid } from "../data/states";

const geoUrl = "https://cdn.jsdelivr.net/npm/us-atlas@3/states-10m.json";

type RiskLevel = "high" | "medium" | "low";

type RiskLevelStyles = {
  [key in RiskLevel]: {
    fill: string;
    stroke: string;
  };
};

const riskLevelStyles: RiskLevelStyles = {
  high: { fill: "url(#high-risk-pattern)", stroke: "#FFFFFF" },
  medium: { fill: "url(#medium-risk-pattern)", stroke: "#FFFFFF" },
  low: { fill: "url(#low-risk-pattern)", stroke: "#FFFFFF" },
};

const problematicStates = ["RI", "MA", "CT", "NJ", "MD", "DE", "VT", "NH"];

const Map = () => {
  const [activeStates, setActiveStates] = useState<Set<string>>(new Set());
  const [dimensions, setDimensions] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });

  useEffect(() => {
    const handleResize = () => {
      setDimensions({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const handleStateClick = (stateName: string) => {
    setActiveStates((prev) => {
      const newSet = new Set(prev);
      newSet.has(stateName) ? newSet.delete(stateName) : newSet.add(stateName);
      return new Set([...newSet]);
    });
  };

  return (
    <div
      style={{
        width: "100vw",
        height: "100vh",
        overflow: "hidden",
        position: "relative",
      }}
    >
      <ComposableMap
        projection="geoAlbersUsa"
        width={dimensions.width}
        height={dimensions.height}
        projectionConfig={{
          scale: dimensions.width * 1,
          translate: [dimensions.width / 2, dimensions.height / 2],
        }}
      >
        <defs>
          {/* Pattern definitions */}
          <pattern
            id="high-risk-pattern"
            width="300"
            height="168"
            patternUnits="userSpaceOnUse"
          >
            <image href="../../high.png" width="300" height="168" />
          </pattern>
          <pattern
            id="medium-risk-pattern"
            width="189"
            height="267"
            patternUnits="userSpaceOnUse"
          >
            <image href="../../medium.png" width="189" height="267" />
          </pattern>
          <pattern
            id="low-risk-pattern"
            width="1000"
            height="562"
            patternUnits="userSpaceOnUse"
          >
            <image href="../../green.png" width="1000" height="562" />
          </pattern>

          <filter id="state-shadow">
            <feDropShadow
              dx="0"
              dy="0"
              stdDeviation="4"
              floodColor="rgba(0,0,0,0.6)"
            />
          </filter>
        </defs>

        <Geographies geography={geoUrl}>
          {({ geographies }) =>
            geographies.map((geo) => {
              const state = stateCentroids.find(
                (s) => s.name === geo.properties.name
              );
              const riskLevel = state?.riskLevel || "low";
              const isActive = activeStates.has(geo.properties.name);

              return (
                <Geography
                  key={geo.rsmKey}
                  geography={geo}
                  fill={riskLevelStyles[riskLevel].fill}
                  stroke={riskLevelStyles[riskLevel].stroke}
                  strokeWidth={0.5}
                  style={{
                    default: {
                      cursor: "pointer",
                      filter: isActive ? "url(#state-shadow)" : "none",
                    },
                    hover: { filter: isActive ? "url(#state-shadow)" : "none" },
                    pressed: { filter: "url(#state-shadow)" },
                  }}
                  onClick={() => handleStateClick(geo.properties.name)}
                  pointerEvents="all"
                />
              );
            })
          }
        </Geographies>

        {stateCentroids.map((state) => {
          if (problematicStates.includes(state.abbrev)) {
            const mobileScale = dimensions.width < 600 ? 0.6 : 1;

            return (
              <Annotation
                key={state.abbrev}
                subject={state.coordinates}
                dx={(state.dx || 0) * mobileScale}
                dy={(state.dy || 0) * mobileScale}
                connectorProps={{
                  stroke: "#333",
                  strokeWidth: 1,
                  strokeLinecap: "round",
                }}
              >
                <g
                  transform={`translate(${state.textDx || 0} ${
                    state.textDy || 0
                  })`}
                >
                  <text
                    x={state.name.length * 2.8}
                    y="12"
                    fontSize={dimensions.width < 600 ? 8 : 9}
                    fontFamily="Arial"
                    textAnchor="middle"
                    fill="#333"
                  >
                    {state.name}
                  </text>
                </g>
              </Annotation>
            );
          }

          return (
            <Marker key={state.abbrev} coordinates={state.coordinates}>
              <g transform="translate(-30 -8)">
                <text
                  x={state.name.length * 3.25}
                  y="12"
                  fontSize={dimensions.width < 600 ? 8 : 10}
                  fontFamily="Arial"
                  textAnchor="middle"
                  fill="#333"
                >
                  {state.name}
                </text>
              </g>
            </Marker>
          );
        })}
      </ComposableMap>
    </div>
  );
};

export default Map;
