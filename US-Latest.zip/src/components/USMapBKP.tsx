import { useState, useEffect } from "react";
import {
  ComposableMap,
  Geographies,
  Geography,
  Marker,
  Annotation,
} from "react-simple-maps";
import { stateCentroids, StateCentroid } from "../data/states";

const geoUrl = "https://cdn.jsdelivr.net/npm/us-atlas@3/states-10m.json";

type RiskLevel = "high" | "medium" | "low";

type RiskLevelStyles = {
  [key in RiskLevel]: {
    fill: string;
    stroke: string;
  };
};

//Bg Image
const riskLevelStyles: RiskLevelStyles = {
  high: {
    fill: "url(#high-risk-pattern)", // Use a pattern or solid color
    stroke: "#FFFFFF", // Red border for high risk
  },
  medium: {
    fill: "url(#medium-risk-pattern)", // Use a pattern or solid color
    stroke: "#FFFFFF", // Orange border for medium risk
  },
  low: {
    fill: "url(#low-risk-pattern)", // Use a pattern or solid color
    stroke: "#FFFFFF", // Green border for low risk
  },
};

const Map = () => {
  const [highlightedState, setHighlightedState] = useState(null);
  const [activeStates, setActiveStates] = useState<Set<string>>(new Set());

  const allStateNames = stateCentroids.map((state: any) => state.name);
  const isAllSelected = activeStates.size === allStateNames.length;

  const toggleAllStates = () => {
    if (isAllSelected) {
      setActiveStates(new Set());
    } else {
      setActiveStates(new Set(allStateNames));
    }
  };

  const handleStateClick = (stateName: string) => {
    setActiveStates((prev) => {
      const newActiveStates = new Set(prev);
      if (newActiveStates.has(stateName)) {
        newActiveStates.delete(stateName);
      } else {
        newActiveStates.add(stateName);
      }
      return new Set([...newActiveStates]); // Force update
    });
  };

  const [dimensions, setDimensions] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });

  useEffect(() => {
    const handleResize = () => {
      setDimensions({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const problematicStates = ["RI", "MA", "CT", "NJ", "MD", "DE", "VT", "NH"];

  return (
    <div
      style={{
        width: "100vw",
        height: "100vh",
        overflow: "hidden",
        position: "relative",
      }}
    >
      <button
        onClick={toggleAllStates}
        style={{
          position: "absolute",
          top: "20px",
          left: "20px",
          zIndex: 1000,
          padding: "8px 16px",
          backgroundColor: isAllSelected ? "#ff4444" : "#4CAF50",
          color: "white",
          border: "none",
          borderRadius: "4px",
          cursor: "pointer",
        }}
      >
        {isAllSelected ? "Deselect All" : "Select All"}
      </button>
      <ComposableMap
        projection="geoAlbersUsa"
        width={dimensions.width}
        height={dimensions.height}
        projectionConfig={{
          scale: dimensions.width * 1,
          translate: [dimensions.width / 2, dimensions.height / 2],
        }}
      >
        {/* Define SVG patterns for risk levels */}
        <defs>
          <pattern
            id="high-risk-pattern"
            x="0"
            y="0"
            width="300"
            height="168"
            patternUnits="userSpaceOnUse"
            patternContentUnits="userSpaceOnUse"
          >
            <image href="../../high.png" x="0" y="0" width="300" height="168" />
          </pattern>
          <pattern
            id="medium-risk-pattern"
            x="0"
            y="0"
            width="189"
            height="267"
            patternUnits="userSpaceOnUse"
            patternContentUnits="userSpaceOnUse"
          >
            <image
              href="../../medium.png"
              x="0"
              y="0"
              width="189"
              height="267"
            />
          </pattern>
          <pattern
            id="low-risk-pattern"
            x="0"
            y="0"
            width="1000"
            height="562"
            patternUnits="userSpaceOnUse"
            patternContentUnits="userSpaceOnUse"
          >
            <image
              href="../../green.png"
              x="0"
              y="0"
              width="1000"
              height="562"
            />
          </pattern>
        </defs>

        <defs>
          <filter id="state-shadow" height="130%" width="130%">
            <feDropShadow
              dx="0"
              dy="0"
              stdDeviation="4"
              floodColor="rgba(0,0,0,0.6)"
            />
          </filter>
        </defs>

        <Geographies geography={geoUrl}>
          {({ geographies }: any) =>
            geographies.map((geo: any) => {
              const state = stateCentroids.find(
                (s: any) => s.name === geo.properties.name
              );
              const riskLevel: RiskLevel = state ? state.riskLevel : "low"; // Explicitly typed
              const style = riskLevelStyles[riskLevel]; // No error now

              return (
                <Geography
                  key={geo.rsmKey}
                  geography={geo}
                  fill={style.fill}
                  stroke={style.stroke}
                  strokeWidth={0.5}
                  style={{
                    default: {
                      // fill: activeStates === geo.id ? "#FF5722" : "#ECEFF1",
                      // stroke: "#607D8B",
                      strokeWidth: 0.75,
                      outline: "none",
                      cursor: "pointer",
                      filter: activeStates.has(geo.properties.name)
                        ? "url(#state-shadow)"
                        : "none",
                    },
                    hover: {
                      // fill: "#FFC107",
                      // stroke: "#607D8B",
                      strokeWidth: 0.75,
                      outline: "none",
                      cursor: "pointer",
                      filter: activeStates.has(geo.properties.name)
                        ? "url(#state-shadow)"
                        : "none",
                    },
                    pressed: {
                      // fill: "#FF5722",
                      // stroke: "#607D8B",
                      strokeWidth: 0.75,
                      outline: "none",
                      cursor: "pointer",
                      filter: activeStates.has(geo.properties.name)
                        ? "url(#state-shadow)"
                        : "none",
                    },
                  }}
                  onClick={() => handleStateClick(geo.properties.name)}
                  pointerEvents="all"
                />
              );
            })
          }
        </Geographies>

        {stateCentroids.map((state: any) => {
          if (problematicStates.includes(state.abbrev)) {
            return (
              <Annotation
                key={state.abbrev}
                subject={state.coordinates}
                dx={dimensions.width < 600 ? -30 : -50}
                dy={dimensions.width < 600 ? -20 : -30}
                connectorProps={{
                  stroke: "#333",
                  strokeWidth: 1,
                  strokeLinecap: "round",
                }}
              >
                <g
                  transform={`translate(${state.textDx || 0} ${
                    state.textDy || 0
                  })`}
                >
                  <text
                    x={state.name.length * 3.25}
                    y="12"
                    fontSize={dimensions.width < 600 ? 8 : 10}
                    fontFamily="Arial"
                    textAnchor="middle"
                    fill={highlightedState === state.name ? "#333" : "#333"}
                  >
                    {state.name}
                  </text>
                </g>
              </Annotation>
            );
          }

          return (
            <Marker key={state.abbrev} coordinates={state.coordinates}>
              <g transform="translate(-30 -8)">
                <text
                  x={state.name.length * 3.25}
                  y="12"
                  fontSize={dimensions.width < 600 ? 8 : 10}
                  fontFamily="Arial"
                  textAnchor="middle"
                  fill={highlightedState === state.name ? "#333" : "#333"}
                >
                  {state.name}
                </text>
              </g>
            </Marker>
          );
        })}
      </ComposableMap>
    </div>
  );
};

export default Map;
