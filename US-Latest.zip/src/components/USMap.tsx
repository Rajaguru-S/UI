// import React, { useState } from "react";
// import {
//   ComposableMap,
//   Geographies,
//   Geography,
//   Marker,
// } from "react-simple-maps";
// import { geoAlbersUsa, geoCentroid } from "d3-geo";
// import usMapData from "../data/us-topo.json";

// interface Geo {
//   id: string;
//   properties: {
//     name: string;
//   };
//   rsmKey: string;
// }

// const USMap: React.FC = () => {
//   const [activeState, setActiveState] = useState<string | null>(null);
//   const [hoveredState, setHoveredState] = useState<Geo | null>(null);

//   const handleClick = (geo: Geo) => {
//     setActiveState(geo.id);
//   };

//   const handleHover = (geo: Geo) => {
//     setHoveredState(geo);
//   };

//   const handleLeave = () => {
//     setHoveredState(null);
//   };

//   // Create the projection function
//   const projection = geoAlbersUsa();

//   return (
//     <ComposableMap
//       projection={projection}
//       projectionConfig={{ scale: 800 }}
//       width={900}
//       height={500}
//     >
//       <Geographies geography={usMapData}>
//         {({ geographies }) => {
//           // Check if geographies is an array
//           if (!Array.isArray(geographies)) {
//             console.error("Geographies data is not in the expected format.");
//             return null;
//           }

//           return geographies.map((geo: Geo) => {
//             // Calculate the centroid of the state
//             const centroid = geoCentroid(geo);

//             return (
//               <React.Fragment key={geo.rsmKey}>
//                 <Geography
//                   geography={geo}
//                   onClick={() => handleClick(geo)}
//                   onMouseEnter={() => handleHover(geo)}
//                   onMouseLeave={handleLeave}
//                   style={{
//                     default: {
//                       fill: activeState === geo.id ? "#FF5722" : "#ECEFF1",
//                       stroke: "#607D8B",
//                       strokeWidth: 0.75,
//                       outline: "none",
//                       boxShadow:
//                         activeState === geo.id
//                           ? "0 4px 8px rgba(0,0,0,0.2)"
//                           : "none",
//                     },
//                     hover: {
//                       fill: "#FFC107",
//                       stroke: "#607D8B",
//                       strokeWidth: 0.75,
//                       outline: "none",
//                     },
//                     pressed: {
//                       fill: "#FF5722",
//                       stroke: "#607D8B",
//                       strokeWidth: 0.75,
//                       outline: "none",
//                     },
//                   }}
//                 />
//                 {hoveredState && hoveredState.rsmKey === geo.rsmKey && (
//                   <Marker coordinates={centroid}>
//                     <text
//                       textAnchor="middle"
//                       y={-10}
//                       style={{
//                         fill: "#000",
//                         fontSize: "12px",
//                         fontWeight: "bold",
//                         backgroundColor: "#FFF",
//                         padding: "2px 5px",
//                         borderRadius: "4px",
//                         boxShadow: "0 2px 4px rgba(0,0,0,0.2)",
//                       }}
//                     >
//                       {hoveredState.properties.name}
//                     </text>
//                   </Marker>
//                 )}
//               </React.Fragment>
//             );
//           });
//         }}
//       </Geographies>
//     </ComposableMap>
//   );
// };

// export default USMap;

// // src/components/Map.js
// import {
//   ComposableMap,
//   Geographies,
//   Geography,
//   Marker,
// } from "react-simple-maps";
// import { stateCentroids } from "../data/states";

// const geoUrl = "https://cdn.jsdelivr.net/npm/us-atlas@3/states-10m.json";

// const Map = () => {
//   return (
//     <ComposableMap
//       projection="geoAlbersUsa"
//       width={1200}
//       height={800}
//       projectionConfig={{ scale: 1000 }}
//     >
//       <Geographies geography={geoUrl}>
//         {({ geographies }) =>
//           geographies.map((geo) => (
//             <Geography
//               key={geo.rsmKey}
//               geography={geo}
//               fill="#EAEAEC"
//               stroke="#D6D6DA"
//               strokeWidth={0.5}
//             />
//           ))
//         }
//       </Geographies>

//       {stateCentroids.map(({ name, coordinates, abbrev }) => (
//         <Marker key={abbrev} coordinates={coordinates}>
//           <g transform="translate(-30 -8)">
//             <rect
//               width={name.length * 6.5} // Dynamic width based on name length
//               height="16"
//               fill="white"
//               opacity="0.9"
//               rx="4"
//             />
//             <text
//               x={name.length * 3.25} // Center text in dynamic width
//               y="12"
//               fontSize="10"
//               fontFamily="Arial"
//               textAnchor="middle"
//               fill="#333"
//             >
//               {name}
//             </text>
//           </g>
//         </Marker>
//       ))}
//     </ComposableMap>
//   );
// };

// export default Map;

// src/components/Map.js
// import { useState } from "react";
// import {
//   ComposableMap,
//   Geographies,
//   Geography,
//   Marker,
//   Annotation,
// } from "react-simple-maps";
// // @ts-ignore
// import { stateCentroids } from "../data/states";

// const geoUrl = "https://cdn.jsdelivr.net/npm/us-atlas@3/states-10m.json";

// const Map = () => {
//   const [highlightedState, setHighlightedState] = useState(null);

//   // States needing special annotation placement
//   const problematicStates = ["RI", "MA", "CT", "NJ", "MD", "DE", "VT", "NH"];

//   return (
//     <ComposableMap
//       projection="geoAlbersUsa"
//       width={1000}
//       height={500}
//       projectionConfig={{
//         scale: 1000,
//         translate: [500, 250],
//       }}
//     >
//       <Geographies geography={geoUrl}>
//         {({ geographies }: any) =>
//           geographies.map((geo: any) => (
//             <Geography
//               key={geo.rsmKey}
//               geography={geo}
//               fill={
//                 geo.properties.name === highlightedState ? "#FFD700" : "#EAEAEC"
//               }
//               stroke="#D6D6DA"
//               strokeWidth={0.5}
//               onMouseEnter={() => setHighlightedState(geo.properties.name)}
//               onMouseLeave={() => setHighlightedState(null)}
//               style={{
//                 default: { outline: "none" },
//                 hover: { fill: "#F53" },
//                 pressed: { fill: "#E42" },
//               }}
//             />
//           ))
//         }
//       </Geographies>

//       {stateCentroids.map((state: any) => {
//         if (problematicStates.includes(state.abbrev)) {
//           return (
//             <Annotation
//               key={state.abbrev}
//               subject={state.coordinates}
//               dx={state.dx || -50}
//               dy={state.dy || -30}
//               connectorProps={{
//                 stroke: "#333",
//                 strokeWidth: 1,
//                 strokeLinecap: "round",
//               }}
//             >
//               <g
//                 transform={`translate(${state.textDx || 0} ${
//                   state.textDy || 0
//                 })`}
//               >
//                 {/* <rect
//                   width={state.name.length * 6.5}
//                   height="16"
//                   fill="white"
//                   opacity="0.9"
//                   rx="4"
//                 /> */}
//                 <text
//                   x={state.name.length * 3.25}
//                   y="12"
//                   fontSize="10"
//                   fontFamily="Arial"
//                   textAnchor="middle"
//                   fill={highlightedState === state.name ? "#333" : "#333"}
//                   fontWeight={
//                     highlightedState === state.name ? "normal" : "normal"
//                   }
//                 >
//                   {state.name}
//                 </text>
//               </g>
//             </Annotation>
//           );
//         }

//         return (
//           <Marker key={state.abbrev} coordinates={state.coordinates}>
//             <g transform="translate(-30 -8)">
//               {/* <rect
//                 width={state.name.length * 6.5}
//                 height="16"
//                 fill="white"
//                 opacity="0.9"
//                 rx="4"
//               /> */}
//               <text
//                 x={state.name.length * 3.25}
//                 y="12"
//                 fontSize="10"
//                 fontFamily="Arial"
//                 textAnchor="middle"
//                 fill={highlightedState === state.name ? "#333" : "#333"}
//                 fontWeight={
//                   highlightedState === state.name ? "normal" : "normal"
//                 }
//               >
//                 {state.name}
//               </text>
//             </g>
//           </Marker>
//         );
//       })}
//     </ComposableMap>
//   );
// };

// export default Map;

import { useState, useEffect } from "react";
import {
  ComposableMap,
  Geographies,
  Geography,
  Marker,
  Annotation,
} from "react-simple-maps";
import { stateCentroids, StateCentroid } from "../data/states";

const geoUrl = "https://cdn.jsdelivr.net/npm/us-atlas@3/states-10m.json";

type RiskLevel = "high" | "medium" | "low";

type RiskLevelStyles = {
  [key in RiskLevel]: {
    fill: string;
    stroke: string;
  };
};

//Colors
// const riskLevelStyles: RiskLevelStyles = {
//   high: {
//     fill: "#FF0000", // Red for high risk
//     stroke: "#FFFFFF",
//   },
//   medium: {
//     fill: "#FFA500", // Orange for medium risk
//     stroke: "#FFFFFF",
//   },
//   low: {
//     fill: "#00FF00", // Green for low risk
//     stroke: "#FFFFFF",
//   },
// };

//Bg Image
const riskLevelStyles: RiskLevelStyles = {
  high: {
    fill: "url(#high-risk-pattern)", // Use a pattern or solid color
    stroke: "#FFFFFF", // Red border for high risk
  },
  medium: {
    fill: "url(#medium-risk-pattern)", // Use a pattern or solid color
    stroke: "#FFFFFF", // Orange border for medium risk
  },
  low: {
    fill: "url(#low-risk-pattern)", // Use a pattern or solid color
    stroke: "#FFFFFF", // Green border for low risk
  },
};

const Map = () => {
  const [highlightedState, setHighlightedState] = useState(null);
  const [activeStates, setActiveStates] = useState<Set<string>>(new Set());

  const allStateNames = stateCentroids.map((state: any) => state.name);
  const isAllSelected = activeStates.size === allStateNames.length;

  const toggleAllStates = () => {
    if (isAllSelected) {
      setActiveStates(new Set());
    } else {
      setActiveStates(new Set(allStateNames));
    }
  };

  const handleStateClick = (stateName: string) => {
    setActiveStates((prev) => {
      const newActiveStates = new Set(prev);
      if (newActiveStates.has(stateName)) {
        newActiveStates.delete(stateName);
      } else {
        newActiveStates.add(stateName);
      }
      return new Set([...newActiveStates]); // Force update
    });
  };

  const [dimensions, setDimensions] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });

  useEffect(() => {
    const handleResize = () => {
      setDimensions({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const problematicStates = ["RI", "MA", "CT", "NJ", "MD", "DE", "VT", "NH"];

  return (
    <div
      style={{
        width: "100vw",
        height: "100vh",
        overflow: "hidden",
        position: "relative",
      }}
    >
      <button
        onClick={toggleAllStates}
        style={{
          position: "absolute",
          top: "20px",
          left: "20px",
          zIndex: 1000,
          padding: "8px 16px",
          backgroundColor: isAllSelected ? "#ff4444" : "#4CAF50",
          color: "white",
          border: "none",
          borderRadius: "4px",
          cursor: "pointer",
        }}
      >
        {isAllSelected ? "Deselect All" : "Select All"}
      </button>
      <ComposableMap
        projection="geoAlbersUsa"
        width={dimensions.width}
        height={dimensions.height}
        projectionConfig={{
          scale: dimensions.width * 1,
          translate: [dimensions.width / 2, dimensions.height / 2],
        }}
      >
        {/* <Geographies geography={geoUrl}>
          {({ geographies }: any) =>
            geographies.map((geo: any) => (
              <Geography
                key={geo.rsmKey}
                geography={geo}
                fill={
                  geo.properties.name === highlightedState
                    ? "#FFD700"
                    : "#EAEAEC"
                }
                stroke="#D6D6DA"
                strokeWidth={0.5}
                onMouseEnter={() => setHighlightedState(geo.properties.name)}
                onMouseLeave={() => setHighlightedState(null)}
                style={{
                  default: { outline: "none" },
                  hover: { fill: "#F53" },
                  pressed: { fill: "#E42" },
                }}
              />
            ))
          }
        </Geographies> */}

        {/* Define SVG patterns for risk levels */}
        <defs>
          <pattern
            id="high-risk-pattern"
            x="0"
            y="0"
            width="300"
            height="168"
            patternUnits="userSpaceOnUse"
            patternContentUnits="userSpaceOnUse"
          >
            <image href="../../high.png" x="0" y="0" width="300" height="168" />
          </pattern>
          <pattern
            id="medium-risk-pattern"
            x="0"
            y="0"
            width="189"
            height="267"
            patternUnits="userSpaceOnUse"
            patternContentUnits="userSpaceOnUse"
          >
            <image
              href="../../medium.png"
              x="0"
              y="0"
              width="189"
              height="267"
            />
          </pattern>
          <pattern
            id="low-risk-pattern"
            x="0"
            y="0"
            width="1000"
            height="562"
            patternUnits="userSpaceOnUse"
            patternContentUnits="userSpaceOnUse"
          >
            <image
              href="../../green.png"
              x="0"
              y="0"
              width="1000"
              height="562"
            />
          </pattern>
        </defs>

        <defs>
          <filter id="state-shadow" height="130%" width="130%">
            <feDropShadow
              dx="0"
              dy="0"
              stdDeviation="4"
              floodColor="rgba(0,0,0,0.6)"
            />
          </filter>
        </defs>

        <Geographies geography={geoUrl}>
          {({ geographies }: any) =>
            geographies.map((geo: any) => {
              const state = stateCentroids.find(
                (s: any) => s.name === geo.properties.name
              );
              const riskLevel: RiskLevel = state ? state.riskLevel : "low"; // Explicitly typed
              const style = riskLevelStyles[riskLevel]; // No error now

              return (
                <Geography
                  key={geo.rsmKey}
                  geography={geo}
                  fill={style.fill}
                  stroke={style.stroke}
                  strokeWidth={0.5}
                  // style={{
                  //   default: { outline: "none" },
                  //   // hover: { fill: "#F53" },
                  //   pressed: { outline: "none", fill: "#E42" },
                  //   active: activeStates.has(geo.properties.name)
                  //     ? { filter: "drop-shadow(0 0 8px rgba(0, 0, 0, 0.6))" }
                  //     : {},
                  // }}
                  style={{
                    default: {
                      // fill: activeStates === geo.id ? "#FF5722" : "#ECEFF1",
                      // stroke: "#607D8B",
                      strokeWidth: 0.75,
                      outline: "none",
                      cursor: "pointer",
                      filter: activeStates.has(geo.properties.name)
                        ? "url(#state-shadow)"
                        : "none",
                    },
                    hover: {
                      // fill: "#FFC107",
                      // stroke: "#607D8B",
                      strokeWidth: 0.75,
                      outline: "none",
                      cursor: "pointer",
                      filter: activeStates.has(geo.properties.name)
                        ? "url(#state-shadow)"
                        : "none",
                    },
                    pressed: {
                      // fill: "#FF5722",
                      // stroke: "#607D8B",
                      strokeWidth: 0.75,
                      outline: "none",
                      cursor: "pointer",
                      filter: activeStates.has(geo.properties.name)
                        ? "url(#state-shadow)"
                        : "none",
                    },
                  }}
                  onClick={() => handleStateClick(geo.properties.name)}
                  pointerEvents="all"
                />
              );
            })
          }
        </Geographies>

        {stateCentroids.map((state: any) => {
          if (problematicStates.includes(state.abbrev)) {
            return (
              <Annotation
                key={state.abbrev}
                subject={state.coordinates}
                dx={dimensions.width < 600 ? -30 : -50}
                dy={dimensions.width < 600 ? -20 : -30}
                connectorProps={{
                  stroke: "#333",
                  strokeWidth: 1,
                  strokeLinecap: "round",
                }}
              >
                <g
                  transform={`translate(${state.textDx || 0} ${
                    state.textDy || 0
                  })`}
                >
                  <text
                    x={state.name.length * 3.25}
                    y="12"
                    fontSize={dimensions.width < 600 ? 8 : 10}
                    fontFamily="Arial"
                    textAnchor="middle"
                    fill={highlightedState === state.name ? "#333" : "#333"}
                  >
                    {state.name}
                  </text>
                </g>
              </Annotation>
            );
          }

          return (
            <Marker key={state.abbrev} coordinates={state.coordinates}>
              <g transform="translate(-30 -8)">
                <text
                  x={state.name.length * 3.25}
                  y="12"
                  fontSize={dimensions.width < 600 ? 8 : 10}
                  fontFamily="Arial"
                  textAnchor="middle"
                  fill={highlightedState === state.name ? "#333" : "#333"}
                >
                  {state.name}
                </text>
              </g>
            </Marker>
          );
        })}
      </ComposableMap>
    </div>
  );
};

export default Map;
