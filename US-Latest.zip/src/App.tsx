import React from "react";
import USMap from "./components/USMap";
import "./App.css";
import Map from "./components/USMapNew";

const App: React.FC = () => {
  return (
    <div className="App">
      <USMap />
      <Map />
    </div>
  );
};

export default App;
