# HTML/CSS Range Slider (with Progress)

A Pen created on CodePen.io. Original URL: [https://codepen.io/jjjrmy/pen/GRpqLEZ](https://codepen.io/jjjrmy/pen/GRpqLEZ).

Created HTML5 range slider with custom UI using jQuery for all devices. 